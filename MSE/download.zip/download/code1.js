gdjs.startCode = {};
gdjs.startCode.localVariables = [];


gdjs.startCode.eventsList0 = function(runtimeScene) {

};

gdjs.startCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.startCode.eventsList0(runtimeScene);


return;

}

gdjs['startCode'] = gdjs.startCode;
