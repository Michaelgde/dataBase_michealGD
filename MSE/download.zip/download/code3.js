gdjs.external_32lvlCode = {};
gdjs.external_32lvlCode.localVariables = [];


gdjs.external_32lvlCode.eventsList0 = function(runtimeScene) {

};

gdjs.external_32lvlCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.external_32lvlCode.eventsList0(runtimeScene);


return;

}

gdjs['external_32lvlCode'] = gdjs.external_32lvlCode;
