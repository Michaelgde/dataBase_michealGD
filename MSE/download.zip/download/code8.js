gdjs.scene2Code = {};
gdjs.scene2Code.localVariables = [];
gdjs.scene2Code.forEachIndex2 = 0;

gdjs.scene2Code.forEachIndex3 = 0;

gdjs.scene2Code.forEachObjects2 = [];

gdjs.scene2Code.forEachObjects3 = [];

gdjs.scene2Code.forEachTemporary2 = null;

gdjs.scene2Code.forEachTemporary3 = null;

gdjs.scene2Code.forEachTotalCount2 = 0;

gdjs.scene2Code.forEachTotalCount3 = 0;

gdjs.scene2Code.GDspriteObjects1= [];
gdjs.scene2Code.GDspriteObjects2= [];
gdjs.scene2Code.GDspriteObjects3= [];
gdjs.scene2Code.GDspriteObjects4= [];
gdjs.scene2Code.GDspriteObjects5= [];
gdjs.scene2Code.GDspriteObjects6= [];
gdjs.scene2Code.GDspriteObjects7= [];
gdjs.scene2Code.GDspriteObjects8= [];
gdjs.scene2Code.GDspriteObjects9= [];
gdjs.scene2Code.GDdebugObjects1= [];
gdjs.scene2Code.GDdebugObjects2= [];
gdjs.scene2Code.GDdebugObjects3= [];
gdjs.scene2Code.GDdebugObjects4= [];
gdjs.scene2Code.GDdebugObjects5= [];
gdjs.scene2Code.GDdebugObjects6= [];
gdjs.scene2Code.GDdebugObjects7= [];
gdjs.scene2Code.GDdebugObjects8= [];
gdjs.scene2Code.GDdebugObjects9= [];
gdjs.scene2Code.GDdialougObjects1= [];
gdjs.scene2Code.GDdialougObjects2= [];
gdjs.scene2Code.GDdialougObjects3= [];
gdjs.scene2Code.GDdialougObjects4= [];
gdjs.scene2Code.GDdialougObjects5= [];
gdjs.scene2Code.GDdialougObjects6= [];
gdjs.scene2Code.GDdialougObjects7= [];
gdjs.scene2Code.GDdialougObjects8= [];
gdjs.scene2Code.GDdialougObjects9= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects1= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects2= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects3= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects4= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects5= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects6= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects7= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects8= [];
gdjs.scene2Code.GDobject_9595var_9595inputObjects9= [];
gdjs.scene2Code.GDobjectNamesObjects1= [];
gdjs.scene2Code.GDobjectNamesObjects2= [];
gdjs.scene2Code.GDobjectNamesObjects3= [];
gdjs.scene2Code.GDobjectNamesObjects4= [];
gdjs.scene2Code.GDobjectNamesObjects5= [];
gdjs.scene2Code.GDobjectNamesObjects6= [];
gdjs.scene2Code.GDobjectNamesObjects7= [];
gdjs.scene2Code.GDobjectNamesObjects8= [];
gdjs.scene2Code.GDobjectNamesObjects9= [];
gdjs.scene2Code.GDobjectNameObjects1= [];
gdjs.scene2Code.GDobjectNameObjects2= [];
gdjs.scene2Code.GDobjectNameObjects3= [];
gdjs.scene2Code.GDobjectNameObjects4= [];
gdjs.scene2Code.GDobjectNameObjects5= [];
gdjs.scene2Code.GDobjectNameObjects6= [];
gdjs.scene2Code.GDobjectNameObjects7= [];
gdjs.scene2Code.GDobjectNameObjects8= [];
gdjs.scene2Code.GDobjectNameObjects9= [];
gdjs.scene2Code.GDdragNdropObjects1= [];
gdjs.scene2Code.GDdragNdropObjects2= [];
gdjs.scene2Code.GDdragNdropObjects3= [];
gdjs.scene2Code.GDdragNdropObjects4= [];
gdjs.scene2Code.GDdragNdropObjects5= [];
gdjs.scene2Code.GDdragNdropObjects6= [];
gdjs.scene2Code.GDdragNdropObjects7= [];
gdjs.scene2Code.GDdragNdropObjects8= [];
gdjs.scene2Code.GDdragNdropObjects9= [];
gdjs.scene2Code.GDobj_9595scpObjects1= [];
gdjs.scene2Code.GDobj_9595scpObjects2= [];
gdjs.scene2Code.GDobj_9595scpObjects3= [];
gdjs.scene2Code.GDobj_9595scpObjects4= [];
gdjs.scene2Code.GDobj_9595scpObjects5= [];
gdjs.scene2Code.GDobj_9595scpObjects6= [];
gdjs.scene2Code.GDobj_9595scpObjects7= [];
gdjs.scene2Code.GDobj_9595scpObjects8= [];
gdjs.scene2Code.GDobj_9595scpObjects9= [];
gdjs.scene2Code.GDobjectName2Objects1= [];
gdjs.scene2Code.GDobjectName2Objects2= [];
gdjs.scene2Code.GDobjectName2Objects3= [];
gdjs.scene2Code.GDobjectName2Objects4= [];
gdjs.scene2Code.GDobjectName2Objects5= [];
gdjs.scene2Code.GDobjectName2Objects6= [];
gdjs.scene2Code.GDobjectName2Objects7= [];
gdjs.scene2Code.GDobjectName2Objects8= [];
gdjs.scene2Code.GDobjectName2Objects9= [];
gdjs.scene2Code.GDfake_9595cuObjects1= [];
gdjs.scene2Code.GDfake_9595cuObjects2= [];
gdjs.scene2Code.GDfake_9595cuObjects3= [];
gdjs.scene2Code.GDfake_9595cuObjects4= [];
gdjs.scene2Code.GDfake_9595cuObjects5= [];
gdjs.scene2Code.GDfake_9595cuObjects6= [];
gdjs.scene2Code.GDfake_9595cuObjects7= [];
gdjs.scene2Code.GDfake_9595cuObjects8= [];
gdjs.scene2Code.GDfake_9595cuObjects9= [];
gdjs.scene2Code.GDijObjects1= [];
gdjs.scene2Code.GDijObjects2= [];
gdjs.scene2Code.GDijObjects3= [];
gdjs.scene2Code.GDijObjects4= [];
gdjs.scene2Code.GDijObjects5= [];
gdjs.scene2Code.GDijObjects6= [];
gdjs.scene2Code.GDijObjects7= [];
gdjs.scene2Code.GDijObjects8= [];
gdjs.scene2Code.GDijObjects9= [];
gdjs.scene2Code.GDscrObjects1= [];
gdjs.scene2Code.GDscrObjects2= [];
gdjs.scene2Code.GDscrObjects3= [];
gdjs.scene2Code.GDscrObjects4= [];
gdjs.scene2Code.GDscrObjects5= [];
gdjs.scene2Code.GDscrObjects6= [];
gdjs.scene2Code.GDscrObjects7= [];
gdjs.scene2Code.GDscrObjects8= [];
gdjs.scene2Code.GDscrObjects9= [];
gdjs.scene2Code.GDwidthObjects1= [];
gdjs.scene2Code.GDwidthObjects2= [];
gdjs.scene2Code.GDwidthObjects3= [];
gdjs.scene2Code.GDwidthObjects4= [];
gdjs.scene2Code.GDwidthObjects5= [];
gdjs.scene2Code.GDwidthObjects6= [];
gdjs.scene2Code.GDwidthObjects7= [];
gdjs.scene2Code.GDwidthObjects8= [];
gdjs.scene2Code.GDwidthObjects9= [];
gdjs.scene2Code.GDheightObjects1= [];
gdjs.scene2Code.GDheightObjects2= [];
gdjs.scene2Code.GDheightObjects3= [];
gdjs.scene2Code.GDheightObjects4= [];
gdjs.scene2Code.GDheightObjects5= [];
gdjs.scene2Code.GDheightObjects6= [];
gdjs.scene2Code.GDheightObjects7= [];
gdjs.scene2Code.GDheightObjects8= [];
gdjs.scene2Code.GDheightObjects9= [];
gdjs.scene2Code.GDxObjects1= [];
gdjs.scene2Code.GDxObjects2= [];
gdjs.scene2Code.GDxObjects3= [];
gdjs.scene2Code.GDxObjects4= [];
gdjs.scene2Code.GDxObjects5= [];
gdjs.scene2Code.GDxObjects6= [];
gdjs.scene2Code.GDxObjects7= [];
gdjs.scene2Code.GDxObjects8= [];
gdjs.scene2Code.GDxObjects9= [];
gdjs.scene2Code.GDyObjects1= [];
gdjs.scene2Code.GDyObjects2= [];
gdjs.scene2Code.GDyObjects3= [];
gdjs.scene2Code.GDyObjects4= [];
gdjs.scene2Code.GDyObjects5= [];
gdjs.scene2Code.GDyObjects6= [];
gdjs.scene2Code.GDyObjects7= [];
gdjs.scene2Code.GDyObjects8= [];
gdjs.scene2Code.GDyObjects9= [];
gdjs.scene2Code.GDNewTextObjects1= [];
gdjs.scene2Code.GDNewTextObjects2= [];
gdjs.scene2Code.GDNewTextObjects3= [];
gdjs.scene2Code.GDNewTextObjects4= [];
gdjs.scene2Code.GDNewTextObjects5= [];
gdjs.scene2Code.GDNewTextObjects6= [];
gdjs.scene2Code.GDNewTextObjects7= [];
gdjs.scene2Code.GDNewTextObjects8= [];
gdjs.scene2Code.GDNewTextObjects9= [];
gdjs.scene2Code.GDstateObjects1= [];
gdjs.scene2Code.GDstateObjects2= [];
gdjs.scene2Code.GDstateObjects3= [];
gdjs.scene2Code.GDstateObjects4= [];
gdjs.scene2Code.GDstateObjects5= [];
gdjs.scene2Code.GDstateObjects6= [];
gdjs.scene2Code.GDstateObjects7= [];
gdjs.scene2Code.GDstateObjects8= [];
gdjs.scene2Code.GDstateObjects9= [];
gdjs.scene2Code.GDboxObjects1= [];
gdjs.scene2Code.GDboxObjects2= [];
gdjs.scene2Code.GDboxObjects3= [];
gdjs.scene2Code.GDboxObjects4= [];
gdjs.scene2Code.GDboxObjects5= [];
gdjs.scene2Code.GDboxObjects6= [];
gdjs.scene2Code.GDboxObjects7= [];
gdjs.scene2Code.GDboxObjects8= [];
gdjs.scene2Code.GDboxObjects9= [];
gdjs.scene2Code.GDaddObjects1= [];
gdjs.scene2Code.GDaddObjects2= [];
gdjs.scene2Code.GDaddObjects3= [];
gdjs.scene2Code.GDaddObjects4= [];
gdjs.scene2Code.GDaddObjects5= [];
gdjs.scene2Code.GDaddObjects6= [];
gdjs.scene2Code.GDaddObjects7= [];
gdjs.scene2Code.GDaddObjects8= [];
gdjs.scene2Code.GDaddObjects9= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects1= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects2= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects3= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects4= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects5= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects6= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects7= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects8= [];
gdjs.scene2Code.GDobj_9595name_9595giverObjects9= [];
gdjs.scene2Code.GDcreateObjects1= [];
gdjs.scene2Code.GDcreateObjects2= [];
gdjs.scene2Code.GDcreateObjects3= [];
gdjs.scene2Code.GDcreateObjects4= [];
gdjs.scene2Code.GDcreateObjects5= [];
gdjs.scene2Code.GDcreateObjects6= [];
gdjs.scene2Code.GDcreateObjects7= [];
gdjs.scene2Code.GDcreateObjects8= [];
gdjs.scene2Code.GDcreateObjects9= [];
gdjs.scene2Code.GDreObjects1= [];
gdjs.scene2Code.GDreObjects2= [];
gdjs.scene2Code.GDreObjects3= [];
gdjs.scene2Code.GDreObjects4= [];
gdjs.scene2Code.GDreObjects5= [];
gdjs.scene2Code.GDreObjects6= [];
gdjs.scene2Code.GDreObjects7= [];
gdjs.scene2Code.GDreObjects8= [];
gdjs.scene2Code.GDreObjects9= [];
gdjs.scene2Code.GDscriptIDEObjects1= [];
gdjs.scene2Code.GDscriptIDEObjects2= [];
gdjs.scene2Code.GDscriptIDEObjects3= [];
gdjs.scene2Code.GDscriptIDEObjects4= [];
gdjs.scene2Code.GDscriptIDEObjects5= [];
gdjs.scene2Code.GDscriptIDEObjects6= [];
gdjs.scene2Code.GDscriptIDEObjects7= [];
gdjs.scene2Code.GDscriptIDEObjects8= [];
gdjs.scene2Code.GDscriptIDEObjects9= [];


gdjs.scene2Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.scene2Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.scene2Code.mapOfEmptyGDspriteObjects = Hashtable.newFrom({"sprite": []});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects2});
gdjs.scene2Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.scene2Code.localVariables[1].getFromIndex(0)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects);
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.scene2Code.GDstateObjects1, gdjs.scene2Code.GDstateObjects3);

{runtimeScene.getScene().getVariables().getFromIndex(10).setBoolean(false);
}{for(var i = 0, len = gdjs.scene2Code.GDstateObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDstateObjects3[i].getBehavior("Text").setText("just started ide");
}
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "g");
}}

}


};gdjs.scene2Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects1);

for (gdjs.scene2Code.forEachIndex2 = 0;gdjs.scene2Code.forEachIndex2 < gdjs.scene2Code.GDspriteObjects1.length;++gdjs.scene2Code.forEachIndex2) {
gdjs.scene2Code.GDspriteObjects2.length = 0;


gdjs.scene2Code.forEachTemporary2 = gdjs.scene2Code.GDspriteObjects1[gdjs.scene2Code.forEachIndex2];
gdjs.scene2Code.GDspriteObjects2.push(gdjs.scene2Code.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("name").setString(((gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects2[0].getVariables()).get("name").getAsString());
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("type").setString((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? "" :gdjs.scene2Code.GDspriteObjects2[0].getName()));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("x").setNumber((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getPointX("")));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("y").setNumber((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getPointY("")));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("width").setNumber((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getWidth()));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("height").setNumber((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getHeight()));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("image").setString(runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild(((gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects2[0].getVariables()).get("name").getAsString()).getAsString());
}{gdjs.scene2Code.localVariables[0].getFromIndex(0).add(1);
}{gdjs.scene2Code.localVariables[1].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.scene2Code.eventsList2(runtimeScene);} //Subevents end.
}
}

}


};gdjs.scene2Code.eventsList4 = function(runtimeScene) {

{



}


{



}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.scene2Code.eventsList3(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


};gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects7Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects7});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects7Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects7});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects7Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects7});
gdjs.scene2Code.eventsList5 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.scene2Code.localVariables[1].getFromIndex(0)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects7Objects);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setString("h");
}}

}


};gdjs.scene2Code.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


const repeatCount7 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(1));
for (let repeatIndex7 = 0;repeatIndex7 < repeatCount7;++repeatIndex7) {
gdjs.scene2Code.GDspriteObjects7.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects7Objects, runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("type").getAsString(), runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("x").getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("y").getAsNumber(), "");
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects7.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects7[i].returnVariable(gdjs.scene2Code.GDspriteObjects7[i].getVariables().get("name")).setString(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("name").getAsString());
}
}{gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild(((gdjs.scene2Code.GDspriteObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects7[0].getVariables()).get("name").getAsString()).getAsString(), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects7Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects7.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects7[i].getBehavior("Resizable").setSize(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("width").getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[1].getFromIndex(0).getAsNumber()).getChild("height").getAsNumber());
}
}{gdjs.scene2Code.localVariables[1].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.scene2Code.eventsList5(runtimeScene, asyncObjectsList);} //Subevents end.
}
}

}


};gdjs.scene2Code.userFunc0x8ffad8 = function GDJSInlineCode(runtimeScene, objects) {
"use strict";
console.log(objects[0])

};
gdjs.scene2Code.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.scene2Code.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("x"), gdjs.scene2Code.GDxObjects5);

var objects = [];
objects.push.apply(objects,gdjs.scene2Code.GDxObjects5);
gdjs.scene2Code.userFunc0x8ffad8(runtimeScene, objects);

}


};gdjs.scene2Code.asyncCallback15561532 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scene2Code.localVariables);

{ //Subevents
gdjs.scene2Code.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.scene2Code.localVariables.length = 0;
}
gdjs.scene2Code.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.scene2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.scene2Code.asyncCallback15561532(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scene2Code.asyncCallback15560980 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scene2Code.localVariables);
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.scene2Code.localVariables[0].getFromIndex(2).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(6));
}
{ //Subevents
gdjs.scene2Code.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.scene2Code.localVariables.length = 0;
}
gdjs.scene2Code.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.scene2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.scene2Code.asyncCallback15560980(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scene2Code.asyncCallback15560492 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scene2Code.localVariables);
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.scene2Code.localVariables[0].getFromIndex(3).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(1));
}
{ //Subevents
gdjs.scene2Code.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.scene2Code.localVariables.length = 0;
}
gdjs.scene2Code.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.scene2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.scene2Code.asyncCallback15560492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scene2Code.asyncCallback15560164 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scene2Code.localVariables);
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.scene2Code.localVariables[0].getFromIndex(1).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(8));
}
{ //Subevents
gdjs.scene2Code.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.scene2Code.localVariables.length = 0;
}
gdjs.scene2Code.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.scene2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.scene2Code.asyncCallback15560164(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects2});
gdjs.scene2Code.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.scene2Code.localVariables[0].getFromIndex(0)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setString("p");
}}

}


};gdjs.scene2Code.asyncCallback15570092 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.scene2Code.localVariables);

{ //Subevents
gdjs.scene2Code.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.scene2Code.localVariables.length = 0;
}
gdjs.scene2Code.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.scene2Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.scene2Code.asyncCallback15570092(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.scene2Code.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects1);

for (gdjs.scene2Code.forEachIndex2 = 0;gdjs.scene2Code.forEachIndex2 < gdjs.scene2Code.GDspriteObjects1.length;++gdjs.scene2Code.forEachIndex2) {
gdjs.scene2Code.GDspriteObjects2.length = 0;


gdjs.scene2Code.forEachTemporary2 = gdjs.scene2Code.GDspriteObjects1[gdjs.scene2Code.forEachIndex2];
gdjs.scene2Code.GDspriteObjects2.push(gdjs.scene2Code.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects2[i].getBehavior("Resizable").setSize(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("width").getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("height").getAsNumber());
}
}{gdjs.scene2Code.localVariables[0].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.scene2Code.eventsList13(runtimeScene);} //Subevents end.
}
}

}


};gdjs.scene2Code.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.scene2Code.GDstateObjects4);
{gdjs.evtTools.storage.writeStringInJSONFile("MGDproject", "ObjInstaceData", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(1)));
}{for(var i = 0, len = gdjs.scene2Code.GDstateObjects4.length ;i < len;++i) {
    gdjs.scene2Code.GDstateObjects4[i].getBehavior("Text").setText("saving...");
}
}}

}


};gdjs.scene2Code.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects2);

for (gdjs.scene2Code.forEachIndex3 = 0;gdjs.scene2Code.forEachIndex3 < gdjs.scene2Code.GDspriteObjects2.length;++gdjs.scene2Code.forEachIndex3) {
gdjs.scene2Code.GDspriteObjects3.length = 0;


gdjs.scene2Code.forEachTemporary3 = gdjs.scene2Code.GDspriteObjects2[gdjs.scene2Code.forEachIndex3];
gdjs.scene2Code.GDspriteObjects3.push(gdjs.scene2Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("name").setString(((gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects3[0].getVariables()).get("name").getAsString());
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("type").setString((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? "" :gdjs.scene2Code.GDspriteObjects3[0].getName()));
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("x").setNumber((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getPointX("")));
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("y").setNumber((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getPointY("")));
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("width").setNumber((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getWidth()));
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("height").setNumber((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getHeight()));
}{gdjs.scene2Code.localVariables[0].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.scene2Code.eventsList15(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.scene2Code.GDstateObjects1);
{for(var i = 0, len = gdjs.scene2Code.GDstateObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDstateObjects1[i].getBehavior("Text").setText("saved");
}
}}

}


};gdjs.scene2Code.eventsList17 = function(runtimeScene) {

{



}


{



}


{



}


};gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects2});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects2});
gdjs.scene2Code.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("height"), gdjs.scene2Code.GDheightObjects2);
gdjs.copyArray(runtimeScene.getObjects("objectName2"), gdjs.scene2Code.GDobjectName2Objects2);
/* Reuse gdjs.scene2Code.GDspriteObjects2 */
gdjs.copyArray(runtimeScene.getObjects("width"), gdjs.scene2Code.GDwidthObjects2);
gdjs.copyArray(runtimeScene.getObjects("x"), gdjs.scene2Code.GDxObjects2);
gdjs.copyArray(runtimeScene.getObjects("y"), gdjs.scene2Code.GDyObjects2);
{gdjs.scene2Code.localVariables[0].getFromIndex(0).setString(((gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects2[0].getVariables()).get("name").getAsString());
}{for(var i = 0, len = gdjs.scene2Code.GDobjectName2Objects2.length ;i < len;++i) {
    gdjs.scene2Code.GDobjectName2Objects2[i].getBehavior("Text").setText(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsString());
}
}{for(var i = 0, len = gdjs.scene2Code.GDwidthObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDwidthObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getWidth())));
}
}{for(var i = 0, len = gdjs.scene2Code.GDheightObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDheightObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getHeight())));
}
}{for(var i = 0, len = gdjs.scene2Code.GDyObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDyObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getPointY(""))));
}
}{for(var i = 0, len = gdjs.scene2Code.GDxObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDxObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.scene2Code.GDspriteObjects2.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects2[0].getPointX(""))));
}
}{for(var i = 0, len = gdjs.scene2Code.GDobjectName2Objects2.length ;i < len;++i) {
    gdjs.scene2Code.GDobjectName2Objects2[i].setColor("255;255;255");
}
}{runtimeScene.getScene().getVariables().getFromIndex(13).add(1);
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects2[i].returnVariable(gdjs.scene2Code.GDspriteObjects2[i].getVariables().get("id")).setNumber(runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.scene2Code.GDspriteObjects2 */
{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects2[i].returnVariable(gdjs.scene2Code.GDspriteObjects2[i].getVariables().get("id")).setNumber(0);
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.scene2Code.eventsList19 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.scene2Code.GDspriteObjects3, gdjs.scene2Code.GDspriteObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.scene2Code.GDspriteObjects4.length;i<l;++i) {
    if ( gdjs.scene2Code.GDspriteObjects4[i].getBehavior("Resizable").getHeight() < 4 ) {
        isConditionTrue_0 = true;
        gdjs.scene2Code.GDspriteObjects4[k] = gdjs.scene2Code.GDspriteObjects4[i];
        ++k;
    }
}
gdjs.scene2Code.GDspriteObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.scene2Code.GDspriteObjects4 */
{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects4.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects4[i].getBehavior("Resizable").setHeight(4);
}
}}

}


{

/* Reuse gdjs.scene2Code.GDspriteObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.scene2Code.GDspriteObjects3.length;i<l;++i) {
    if ( gdjs.scene2Code.GDspriteObjects3[i].getBehavior("Resizable").getWidth() < 4 ) {
        isConditionTrue_0 = true;
        gdjs.scene2Code.GDspriteObjects3[k] = gdjs.scene2Code.GDspriteObjects3[i];
        ++k;
    }
}
gdjs.scene2Code.GDspriteObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.scene2Code.GDspriteObjects3 */
{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects3[i].getBehavior("Resizable").setWidth(4);
}
}}

}


};gdjs.scene2Code.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.scene2Code.GDspriteObjects2, gdjs.scene2Code.GDspriteObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14717700);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.scene2Code.GDspriteObjects3.length;i<l;++i) {
    if ( gdjs.scene2Code.GDspriteObjects3[i].getVariableNumber(gdjs.scene2Code.GDspriteObjects3[i].getVariables().getFromIndex(0)) == runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.scene2Code.GDspriteObjects3[k] = gdjs.scene2Code.GDspriteObjects3[i];
        ++k;
    }
}
gdjs.scene2Code.GDspriteObjects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("height"), gdjs.scene2Code.GDheightObjects3);
/* Reuse gdjs.scene2Code.GDspriteObjects3 */
gdjs.copyArray(runtimeScene.getObjects("width"), gdjs.scene2Code.GDwidthObjects3);
{for(var i = 0, len = gdjs.scene2Code.GDwidthObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDwidthObjects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getWidth())));
}
}{for(var i = 0, len = gdjs.scene2Code.GDheightObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDheightObjects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? 0 :gdjs.scene2Code.GDspriteObjects3[0].getHeight())));
}
}}

}


{

gdjs.copyArray(gdjs.scene2Code.GDspriteObjects2, gdjs.scene2Code.GDspriteObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.scene2Code.GDspriteObjects3.length;i<l;++i) {
    if ( gdjs.scene2Code.GDspriteObjects3[i].getVariableNumber(gdjs.scene2Code.GDspriteObjects3[i].getVariables().getFromIndex(0)) == runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.scene2Code.GDspriteObjects3[k] = gdjs.scene2Code.GDspriteObjects3[i];
        ++k;
    }
}
gdjs.scene2Code.GDspriteObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("height"), gdjs.scene2Code.GDheightObjects3);
gdjs.copyArray(runtimeScene.getObjects("objectName2"), gdjs.scene2Code.GDobjectName2Objects3);
/* Reuse gdjs.scene2Code.GDspriteObjects3 */
gdjs.copyArray(runtimeScene.getObjects("width"), gdjs.scene2Code.GDwidthObjects3);
gdjs.copyArray(runtimeScene.getObjects("x"), gdjs.scene2Code.GDxObjects3);
gdjs.copyArray(runtimeScene.getObjects("y"), gdjs.scene2Code.GDyObjects3);
{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects3[i].setX(gdjs.evtTools.common.toNumber((( gdjs.scene2Code.GDxObjects3.length === 0 ) ? "" :gdjs.scene2Code.GDxObjects3[0].getBehavior("Text").getText())));
}
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects3[i].setY(gdjs.evtTools.common.toNumber((( gdjs.scene2Code.GDyObjects3.length === 0 ) ? "" :gdjs.scene2Code.GDyObjects3[0].getBehavior("Text").getText())));
}
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects3[i].getBehavior("Resizable").setWidth(gdjs.evtTools.common.toNumber((( gdjs.scene2Code.GDwidthObjects3.length === 0 ) ? "" :gdjs.scene2Code.GDwidthObjects3[0].getBehavior("Text").getText())));
}
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects3[i].getBehavior("Resizable").setHeight(gdjs.evtTools.common.toNumber((( gdjs.scene2Code.GDheightObjects3.length === 0 ) ? "" :gdjs.scene2Code.GDheightObjects3[0].getBehavior("Text").getText())));
}
}{for(var i = 0, len = gdjs.scene2Code.GDobjectName2Objects3.length ;i < len;++i) {
    gdjs.scene2Code.GDobjectName2Objects3[i].getBehavior("Text").setText(((gdjs.scene2Code.GDspriteObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects3[0].getVariables()).get("name").getAsString());
}
}
{ //Subevents
gdjs.scene2Code.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.scene2Code.mapOfEmptyGDspriteObjects = Hashtable.newFrom({"sprite": []});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects1Objects = Hashtable.newFrom({"objectName": gdjs.scene2Code.GDobjectNameObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDaddObjects1Objects = Hashtable.newFrom({"add": gdjs.scene2Code.GDaddObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects1Objects = Hashtable.newFrom({"objectName": gdjs.scene2Code.GDobjectNameObjects1});
gdjs.scene2Code.eventsList21 = function(runtimeScene) {

};gdjs.scene2Code.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects2);

for (gdjs.scene2Code.forEachIndex3 = 0;gdjs.scene2Code.forEachIndex3 < gdjs.scene2Code.GDspriteObjects2.length;++gdjs.scene2Code.forEachIndex3) {
gdjs.copyArray(gdjs.scene2Code.GDobjectNameObjects1, gdjs.scene2Code.GDobjectNameObjects3);

gdjs.scene2Code.GDspriteObjects3.length = 0;


gdjs.scene2Code.forEachTemporary3 = gdjs.scene2Code.GDspriteObjects2[gdjs.scene2Code.forEachIndex3];
gdjs.scene2Code.GDspriteObjects3.push(gdjs.scene2Code.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.scene2Code.GDspriteObjects3.length;i<l;++i) {
    if ( gdjs.scene2Code.GDspriteObjects3[i].getVariableString(gdjs.scene2Code.GDspriteObjects3[i].getVariables().get("name")) == (( gdjs.scene2Code.GDobjectNameObjects3.length === 0 ) ? "" :gdjs.scene2Code.GDobjectNameObjects3[0].getBehavior("Text").getText()) ) {
        isConditionTrue_0 = true;
        gdjs.scene2Code.GDspriteObjects3[k] = gdjs.scene2Code.GDspriteObjects3[i];
        ++k;
    }
}
gdjs.scene2Code.GDspriteObjects3.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects3.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.hideLayer(runtimeScene, "co");
}}

}


};gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDcreateObjects1Objects = Hashtable.newFrom({"create": gdjs.scene2Code.GDcreateObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDreObjects1Objects = Hashtable.newFrom({"re": gdjs.scene2Code.GDreObjects1});
gdjs.scene2Code.eventsList23 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.hideLayer(runtimeScene, "co");
}}

}


};gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDcreateObjects1Objects = Hashtable.newFrom({"create": gdjs.scene2Code.GDcreateObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDreObjects1Objects = Hashtable.newFrom({"re": gdjs.scene2Code.GDreObjects1});
gdjs.scene2Code.eventsList24 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.hideLayer(runtimeScene, "co");
}}

}


};gdjs.scene2Code.mapOfEmptyGDdragNdropObjects = Hashtable.newFrom({"dragNdrop": []});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects = Hashtable.newFrom({"sprite": gdjs.scene2Code.GDspriteObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects1Objects = Hashtable.newFrom({"objectName": gdjs.scene2Code.GDobjectNameObjects1});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDdragNdropObjects1Objects = Hashtable.newFrom({"dragNdrop": gdjs.scene2Code.GDdragNdropObjects1});
gdjs.scene2Code.userFunc0x1031f60 = function GDJSInlineCode(runtimeScene) {
"use strict";
const ar = []
for (let childName in runtimeScene.getVariables().get("objects").getAllChildren()){
    ar.push(childName)
}
runtimeScene.getVariables().get("list").fromJSON(JSON.stringify(ar))
runtimeScene.getGame().getVariables().get("objectList").fromJSON(JSON.stringify(ar))
console.log(ar)
};
gdjs.scene2Code.eventsList25 = function(runtimeScene) {

{


gdjs.scene2Code.userFunc0x1031f60(runtimeScene);

}


};gdjs.scene2Code.mapOfEmptyGDobjectNameObjects = Hashtable.newFrom({"objectName": []});
gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects2Objects = Hashtable.newFrom({"objectName": gdjs.scene2Code.GDobjectNameObjects2});
gdjs.scene2Code.eventsList26 = function(runtimeScene) {

};gdjs.scene2Code.eventsList27 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(2));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(gdjs.scene2Code.GDobjectNameObjects1, gdjs.scene2Code.GDobjectNameObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects2Objects, 1080, gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsNumber(), "object_select");
}{for(var i = 0, len = gdjs.scene2Code.GDobjectNameObjects2.length ;i < len;++i) {
    gdjs.scene2Code.GDobjectNameObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getChild(gdjs.scene2Code.localVariables[0].getFromIndex(1).getAsNumber()).getAsString());
}
}{gdjs.scene2Code.localVariables[0].getFromIndex(1).add(1);
}{gdjs.scene2Code.localVariables[0].getFromIndex(0).add(32);
}}
}

}


};gdjs.scene2Code.eventsList28 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
if (isConditionTrue_0) {
{gdjs.fileSystem.makeDirectory(gdjs.fileSystem.getDesktopPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "hack", gdjs.VariablesContainer.badVariable);
}
{ //Subevents
gdjs.scene2Code.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "c");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(10), false, false);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(10).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(0);
}
{ //Subevents
gdjs.scene2Code.eventsList1(runtimeScene);} //End of subevents
}

}


{



}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("countr", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(10), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfEmptyGDspriteObjects) > 0;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.scene2Code.GDstateObjects1);
{for(var i = 0, len = gdjs.scene2Code.GDstateObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDstateObjects1[i].getBehavior("Text").setText("collecting object position....");
}
}{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(1));
}
{ //Subevents
gdjs.scene2Code.eventsList4(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) == "u";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(6), false, false);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setString("p");
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(false);
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("Ojson", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("Rjson", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("DataJson", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("TOjsom", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("MGDproject", "object", runtimeScene, gdjs.scene2Code.localVariables[0].getFromIndex(0));
}{gdjs.evtTools.storage.readStringFromJSONFile("MGDproject", "resources", runtimeScene, gdjs.scene2Code.localVariables[0].getFromIndex(1));
}{gdjs.evtTools.storage.readStringFromJSONFile("MGDproject", "ObjInstaceData", runtimeScene, gdjs.scene2Code.localVariables[0].getFromIndex(3));
}{gdjs.evtTools.storage.readStringFromJSONFile("MGDproject", "data", runtimeScene, gdjs.scene2Code.localVariables[0].getFromIndex(2));
}{gdjs.evtTools.storage.readStringFromJSONFile("MGDproject", "script", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(0));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(0));
}
{ //Subevents
gdjs.scene2Code.eventsList11(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.scene2Code.GDdebugObjects1);
gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects1);
{for(var i = 0, len = gdjs.scene2Code.GDdebugObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDdebugObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(3).getAsString() + gdjs.evtTools.string.newLine() + runtimeScene.getScene().getVariables().getFromIndex(5).getAsString() + gdjs.evtTools.string.newLine() + ((gdjs.scene2Code.GDspriteObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects1[0].getVariables()).getFromIndex(0).getAsString() + " instance of sprites: " + gdjs.evtTools.common.toString(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects)));
}
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)) == "h";
if (isConditionTrue_0) {
{gdjs.scene2Code.localVariables[0].getFromIndex(0).setNumber(0);
}
{ //Subevents
gdjs.scene2Code.eventsList14(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeStringInJSONFile("MGDproject", "object", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{gdjs.evtTools.storage.writeStringInJSONFile("MGDproject", "resources", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(8)));
}{gdjs.evtTools.storage.writeStringInJSONFile("MGDproject", "script", runtimeScene.getGame().getVariables().getFromIndex(0).getAsString());
}{gdjs.evtTools.storage.writeStringInJSONFile("MGDproject", "data", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(6)));
}{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getScene().getVariables().getFromIndex(1));
}
{ //Subevents
gdjs.scene2Code.eventsList16(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setBoolean(false);
variables._declare("stop", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(gdjs.scene2Code.localVariables[0].getFromIndex(0), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15553604);
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "ide");
}}
gdjs.scene2Code.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustResumed(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.scene2Code.eventsList17(runtimeScene);} //End of subevents
}

}


{



}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("0");
variables._declare("objN", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.scene2Code.eventsList18(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects1);

for (gdjs.scene2Code.forEachIndex2 = 0;gdjs.scene2Code.forEachIndex2 < gdjs.scene2Code.GDspriteObjects1.length;++gdjs.scene2Code.forEachIndex2) {
gdjs.scene2Code.GDspriteObjects2.length = 0;


gdjs.scene2Code.forEachTemporary2 = gdjs.scene2Code.GDspriteObjects1[gdjs.scene2Code.forEachIndex2];
gdjs.scene2Code.GDspriteObjects2.push(gdjs.scene2Code.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.scene2Code.eventsList20(runtimeScene);} //Subevents end.
}
}

}


{



}


{



}


{


let isConditionTrue_0 = false;
{
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("obj_scp"), gdjs.scene2Code.GDobj_9595scpObjects1);
{for(var i = 0, len = gdjs.scene2Code.GDobj_9595scpObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDobj_9595scpObjects1[i].getBehavior("Resizable").setHeight((gdjs.evtsExt__InputValidation__CountNewLines.func(runtimeScene, (gdjs.scene2Code.GDobj_9595scpObjects1[i].getBehavior("Text").getText()), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) * 23) + 23);
}
}{runtimeScene.getScene().getVariables().getFromIndex(11).setNumber(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfEmptyGDspriteObjects) - 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objectName"), gdjs.scene2Code.GDobjectNameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Right");
}
if (isConditionTrue_0) {
/* Reuse gdjs.scene2Code.GDobjectNameObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(3).setString(runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild((( gdjs.scene2Code.GDobjectNameObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobjectNameObjects1[0].getBehavior("Text").getText())).getAsString());
}{runtimeScene.getGame().getVariables().getFromIndex(5).setString((( gdjs.scene2Code.GDobjectNameObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobjectNameObjects1[0].getBehavior("Text").getText()));
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "collEditor");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("add"), gdjs.scene2Code.GDaddObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDaddObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "co");
}{runtimeScene.getScene().getVariables().getFromIndex(7).setString(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(4)));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.scene2Code.GDspriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14735660);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.scene2Code.GDspriteObjects1 */
{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objectName"), gdjs.scene2Code.GDobjectNameObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("\"");
variables._declare("json1", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("name", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("\":{\"animated\":false,\"animation\":[],\"image\":0,\"name\":\"sprite\",\"script\":\"0\"}}");
variables._declare("json2", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(15), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14736884);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.scene2Code.GDobjectNameObjects1 */
{gdjs.evtTools.variable.variableRemoveChild(runtimeScene.getScene().getVariables().getFromIndex(0), (( gdjs.scene2Code.GDobjectNameObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobjectNameObjects1[0].getBehavior("Text").getText()));
}
{ //Subevents
gdjs.scene2Code.eventsList22(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("create"), gdjs.scene2Code.GDcreateObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("\"");
variables._declare("json1", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("name", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("\":{\"animated\":false,\"animation\":[],\"image\":0,\"name\":\"sprite\",\"script\":\"0\"}}");
variables._declare("json2", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "co");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDcreateObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(15), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0)) > 0;
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("obj_name_giver"), gdjs.scene2Code.GDobj_9595name_9595giverObjects1);
gdjs.copyArray(runtimeScene.getObjects("re"), gdjs.scene2Code.GDreObjects1);
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.string.subStr(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0)), 0, gdjs.evtTools.string.strLen(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0))) - 1) + "," + gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsString() + (( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText()) + gdjs.scene2Code.localVariables[0].getFromIndex(2).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(0));
}{gdjs.evtsExt__UploadDownloadImageFile__UploadImageFile.func(runtimeScene, gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDreObjects1Objects, false, runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild((( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText())), gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild((( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText())).getChild("width").setNumber(32);
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild((( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText())).getChild("height").setNumber(32);
}
{ //Subevents
gdjs.scene2Code.eventsList23(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("create"), gdjs.scene2Code.GDcreateObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("\"");
variables._declare("json1", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("name", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("\":{\"animated\":false,\"animation\":[],\"image\":0,\"name\":\"sprite\",\"script\":\"0\"}}");
variables._declare("json2", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "co");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDcreateObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(15), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("obj_name_giver"), gdjs.scene2Code.GDobj_9595name_9595giverObjects1);
gdjs.copyArray(runtimeScene.getObjects("re"), gdjs.scene2Code.GDreObjects1);
{gdjs.evtTools.network.jsonToVariableStructure("{" + gdjs.scene2Code.localVariables[0].getFromIndex(0).getAsString() + (( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText()) + gdjs.scene2Code.localVariables[0].getFromIndex(2).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(0));
}{gdjs.evtsExt__UploadDownloadImageFile__UploadImageFile.func(runtimeScene, gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDreObjects1Objects, false, runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild((( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText())), gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild((( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText())).getChild("width").setNumber(32);
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild((( gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobj_9595name_9595giverObjects1[0].getBehavior("Text").getText())).getChild("height").setNumber(32);
}
{ //Subevents
gdjs.scene2Code.eventsList24(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("0");
variables._declare("cn", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{
}
gdjs.scene2Code.localVariables.pop();

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dragNdrop"), gdjs.scene2Code.GDdragNdropObjects1);
{for(var i = 0, len = gdjs.scene2Code.GDdragNdropObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDdragNdropObjects1[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfEmptyGDdragNdropObjects) > 0;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dragNdrop"), gdjs.scene2Code.GDdragNdropObjects1);
gdjs.scene2Code.GDspriteObjects1.length = 0;

{for(var i = 0, len = gdjs.scene2Code.GDdragNdropObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDdragNdropObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}{for(var i = 0, len = gdjs.scene2Code.GDspriteObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDspriteObjects1[i].returnVariable(gdjs.scene2Code.GDspriteObjects1[i].getVariables().getFromIndex(1)).setString(runtimeScene.getScene().getVariables().getFromIndex(16).getAsString());
}
}{gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(8).getChild("images").getChild(((gdjs.scene2Code.GDspriteObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.scene2Code.GDspriteObjects1[0].getVariables()).get("name").getAsString()).getAsString(), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDspriteObjects1Objects, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objectName"), gdjs.scene2Code.GDobjectNameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDobjectNameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14751892);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.scene2Code.GDobjectNameObjects1 */
gdjs.scene2Code.GDdragNdropObjects1.length = 0;

{runtimeScene.getScene().getVariables().getFromIndex(16).setString((( gdjs.scene2Code.GDobjectNameObjects1.length === 0 ) ? "" :gdjs.scene2Code.GDobjectNameObjects1[0].getBehavior("Text").getText()));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfGDgdjs_9546scene2Code_9546GDdragNdropObjects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0)) != gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(2));
if (isConditionTrue_0) {

{ //Subevents
gdjs.scene2Code.eventsList25(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + (1), "", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - (1), "", 0);
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(50);
variables._declare("count", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.scene2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(2)) != gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.scene2Code.mapOfEmptyGDobjectNameObjects);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("objectName"), gdjs.scene2Code.GDobjectNameObjects1);
{for(var i = 0, len = gdjs.scene2Code.GDobjectNameObjects1.length ;i < len;++i) {
    gdjs.scene2Code.GDobjectNameObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.scene2Code.eventsList27(runtimeScene);} //End of subevents
}
gdjs.scene2Code.localVariables.pop();

}


};

gdjs.scene2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.scene2Code.GDspriteObjects1.length = 0;
gdjs.scene2Code.GDspriteObjects2.length = 0;
gdjs.scene2Code.GDspriteObjects3.length = 0;
gdjs.scene2Code.GDspriteObjects4.length = 0;
gdjs.scene2Code.GDspriteObjects5.length = 0;
gdjs.scene2Code.GDspriteObjects6.length = 0;
gdjs.scene2Code.GDspriteObjects7.length = 0;
gdjs.scene2Code.GDspriteObjects8.length = 0;
gdjs.scene2Code.GDspriteObjects9.length = 0;
gdjs.scene2Code.GDdebugObjects1.length = 0;
gdjs.scene2Code.GDdebugObjects2.length = 0;
gdjs.scene2Code.GDdebugObjects3.length = 0;
gdjs.scene2Code.GDdebugObjects4.length = 0;
gdjs.scene2Code.GDdebugObjects5.length = 0;
gdjs.scene2Code.GDdebugObjects6.length = 0;
gdjs.scene2Code.GDdebugObjects7.length = 0;
gdjs.scene2Code.GDdebugObjects8.length = 0;
gdjs.scene2Code.GDdebugObjects9.length = 0;
gdjs.scene2Code.GDdialougObjects1.length = 0;
gdjs.scene2Code.GDdialougObjects2.length = 0;
gdjs.scene2Code.GDdialougObjects3.length = 0;
gdjs.scene2Code.GDdialougObjects4.length = 0;
gdjs.scene2Code.GDdialougObjects5.length = 0;
gdjs.scene2Code.GDdialougObjects6.length = 0;
gdjs.scene2Code.GDdialougObjects7.length = 0;
gdjs.scene2Code.GDdialougObjects8.length = 0;
gdjs.scene2Code.GDdialougObjects9.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects1.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects2.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects3.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects4.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects5.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects6.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects7.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects8.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects9.length = 0;
gdjs.scene2Code.GDobjectNamesObjects1.length = 0;
gdjs.scene2Code.GDobjectNamesObjects2.length = 0;
gdjs.scene2Code.GDobjectNamesObjects3.length = 0;
gdjs.scene2Code.GDobjectNamesObjects4.length = 0;
gdjs.scene2Code.GDobjectNamesObjects5.length = 0;
gdjs.scene2Code.GDobjectNamesObjects6.length = 0;
gdjs.scene2Code.GDobjectNamesObjects7.length = 0;
gdjs.scene2Code.GDobjectNamesObjects8.length = 0;
gdjs.scene2Code.GDobjectNamesObjects9.length = 0;
gdjs.scene2Code.GDobjectNameObjects1.length = 0;
gdjs.scene2Code.GDobjectNameObjects2.length = 0;
gdjs.scene2Code.GDobjectNameObjects3.length = 0;
gdjs.scene2Code.GDobjectNameObjects4.length = 0;
gdjs.scene2Code.GDobjectNameObjects5.length = 0;
gdjs.scene2Code.GDobjectNameObjects6.length = 0;
gdjs.scene2Code.GDobjectNameObjects7.length = 0;
gdjs.scene2Code.GDobjectNameObjects8.length = 0;
gdjs.scene2Code.GDobjectNameObjects9.length = 0;
gdjs.scene2Code.GDdragNdropObjects1.length = 0;
gdjs.scene2Code.GDdragNdropObjects2.length = 0;
gdjs.scene2Code.GDdragNdropObjects3.length = 0;
gdjs.scene2Code.GDdragNdropObjects4.length = 0;
gdjs.scene2Code.GDdragNdropObjects5.length = 0;
gdjs.scene2Code.GDdragNdropObjects6.length = 0;
gdjs.scene2Code.GDdragNdropObjects7.length = 0;
gdjs.scene2Code.GDdragNdropObjects8.length = 0;
gdjs.scene2Code.GDdragNdropObjects9.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects1.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects2.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects3.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects4.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects5.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects6.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects7.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects8.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects9.length = 0;
gdjs.scene2Code.GDobjectName2Objects1.length = 0;
gdjs.scene2Code.GDobjectName2Objects2.length = 0;
gdjs.scene2Code.GDobjectName2Objects3.length = 0;
gdjs.scene2Code.GDobjectName2Objects4.length = 0;
gdjs.scene2Code.GDobjectName2Objects5.length = 0;
gdjs.scene2Code.GDobjectName2Objects6.length = 0;
gdjs.scene2Code.GDobjectName2Objects7.length = 0;
gdjs.scene2Code.GDobjectName2Objects8.length = 0;
gdjs.scene2Code.GDobjectName2Objects9.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects1.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects2.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects3.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects4.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects5.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects6.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects7.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects8.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects9.length = 0;
gdjs.scene2Code.GDijObjects1.length = 0;
gdjs.scene2Code.GDijObjects2.length = 0;
gdjs.scene2Code.GDijObjects3.length = 0;
gdjs.scene2Code.GDijObjects4.length = 0;
gdjs.scene2Code.GDijObjects5.length = 0;
gdjs.scene2Code.GDijObjects6.length = 0;
gdjs.scene2Code.GDijObjects7.length = 0;
gdjs.scene2Code.GDijObjects8.length = 0;
gdjs.scene2Code.GDijObjects9.length = 0;
gdjs.scene2Code.GDscrObjects1.length = 0;
gdjs.scene2Code.GDscrObjects2.length = 0;
gdjs.scene2Code.GDscrObjects3.length = 0;
gdjs.scene2Code.GDscrObjects4.length = 0;
gdjs.scene2Code.GDscrObjects5.length = 0;
gdjs.scene2Code.GDscrObjects6.length = 0;
gdjs.scene2Code.GDscrObjects7.length = 0;
gdjs.scene2Code.GDscrObjects8.length = 0;
gdjs.scene2Code.GDscrObjects9.length = 0;
gdjs.scene2Code.GDwidthObjects1.length = 0;
gdjs.scene2Code.GDwidthObjects2.length = 0;
gdjs.scene2Code.GDwidthObjects3.length = 0;
gdjs.scene2Code.GDwidthObjects4.length = 0;
gdjs.scene2Code.GDwidthObjects5.length = 0;
gdjs.scene2Code.GDwidthObjects6.length = 0;
gdjs.scene2Code.GDwidthObjects7.length = 0;
gdjs.scene2Code.GDwidthObjects8.length = 0;
gdjs.scene2Code.GDwidthObjects9.length = 0;
gdjs.scene2Code.GDheightObjects1.length = 0;
gdjs.scene2Code.GDheightObjects2.length = 0;
gdjs.scene2Code.GDheightObjects3.length = 0;
gdjs.scene2Code.GDheightObjects4.length = 0;
gdjs.scene2Code.GDheightObjects5.length = 0;
gdjs.scene2Code.GDheightObjects6.length = 0;
gdjs.scene2Code.GDheightObjects7.length = 0;
gdjs.scene2Code.GDheightObjects8.length = 0;
gdjs.scene2Code.GDheightObjects9.length = 0;
gdjs.scene2Code.GDxObjects1.length = 0;
gdjs.scene2Code.GDxObjects2.length = 0;
gdjs.scene2Code.GDxObjects3.length = 0;
gdjs.scene2Code.GDxObjects4.length = 0;
gdjs.scene2Code.GDxObjects5.length = 0;
gdjs.scene2Code.GDxObjects6.length = 0;
gdjs.scene2Code.GDxObjects7.length = 0;
gdjs.scene2Code.GDxObjects8.length = 0;
gdjs.scene2Code.GDxObjects9.length = 0;
gdjs.scene2Code.GDyObjects1.length = 0;
gdjs.scene2Code.GDyObjects2.length = 0;
gdjs.scene2Code.GDyObjects3.length = 0;
gdjs.scene2Code.GDyObjects4.length = 0;
gdjs.scene2Code.GDyObjects5.length = 0;
gdjs.scene2Code.GDyObjects6.length = 0;
gdjs.scene2Code.GDyObjects7.length = 0;
gdjs.scene2Code.GDyObjects8.length = 0;
gdjs.scene2Code.GDyObjects9.length = 0;
gdjs.scene2Code.GDNewTextObjects1.length = 0;
gdjs.scene2Code.GDNewTextObjects2.length = 0;
gdjs.scene2Code.GDNewTextObjects3.length = 0;
gdjs.scene2Code.GDNewTextObjects4.length = 0;
gdjs.scene2Code.GDNewTextObjects5.length = 0;
gdjs.scene2Code.GDNewTextObjects6.length = 0;
gdjs.scene2Code.GDNewTextObjects7.length = 0;
gdjs.scene2Code.GDNewTextObjects8.length = 0;
gdjs.scene2Code.GDNewTextObjects9.length = 0;
gdjs.scene2Code.GDstateObjects1.length = 0;
gdjs.scene2Code.GDstateObjects2.length = 0;
gdjs.scene2Code.GDstateObjects3.length = 0;
gdjs.scene2Code.GDstateObjects4.length = 0;
gdjs.scene2Code.GDstateObjects5.length = 0;
gdjs.scene2Code.GDstateObjects6.length = 0;
gdjs.scene2Code.GDstateObjects7.length = 0;
gdjs.scene2Code.GDstateObjects8.length = 0;
gdjs.scene2Code.GDstateObjects9.length = 0;
gdjs.scene2Code.GDboxObjects1.length = 0;
gdjs.scene2Code.GDboxObjects2.length = 0;
gdjs.scene2Code.GDboxObjects3.length = 0;
gdjs.scene2Code.GDboxObjects4.length = 0;
gdjs.scene2Code.GDboxObjects5.length = 0;
gdjs.scene2Code.GDboxObjects6.length = 0;
gdjs.scene2Code.GDboxObjects7.length = 0;
gdjs.scene2Code.GDboxObjects8.length = 0;
gdjs.scene2Code.GDboxObjects9.length = 0;
gdjs.scene2Code.GDaddObjects1.length = 0;
gdjs.scene2Code.GDaddObjects2.length = 0;
gdjs.scene2Code.GDaddObjects3.length = 0;
gdjs.scene2Code.GDaddObjects4.length = 0;
gdjs.scene2Code.GDaddObjects5.length = 0;
gdjs.scene2Code.GDaddObjects6.length = 0;
gdjs.scene2Code.GDaddObjects7.length = 0;
gdjs.scene2Code.GDaddObjects8.length = 0;
gdjs.scene2Code.GDaddObjects9.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects2.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects3.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects4.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects5.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects6.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects7.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects8.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects9.length = 0;
gdjs.scene2Code.GDcreateObjects1.length = 0;
gdjs.scene2Code.GDcreateObjects2.length = 0;
gdjs.scene2Code.GDcreateObjects3.length = 0;
gdjs.scene2Code.GDcreateObjects4.length = 0;
gdjs.scene2Code.GDcreateObjects5.length = 0;
gdjs.scene2Code.GDcreateObjects6.length = 0;
gdjs.scene2Code.GDcreateObjects7.length = 0;
gdjs.scene2Code.GDcreateObjects8.length = 0;
gdjs.scene2Code.GDcreateObjects9.length = 0;
gdjs.scene2Code.GDreObjects1.length = 0;
gdjs.scene2Code.GDreObjects2.length = 0;
gdjs.scene2Code.GDreObjects3.length = 0;
gdjs.scene2Code.GDreObjects4.length = 0;
gdjs.scene2Code.GDreObjects5.length = 0;
gdjs.scene2Code.GDreObjects6.length = 0;
gdjs.scene2Code.GDreObjects7.length = 0;
gdjs.scene2Code.GDreObjects8.length = 0;
gdjs.scene2Code.GDreObjects9.length = 0;
gdjs.scene2Code.GDscriptIDEObjects1.length = 0;
gdjs.scene2Code.GDscriptIDEObjects2.length = 0;
gdjs.scene2Code.GDscriptIDEObjects3.length = 0;
gdjs.scene2Code.GDscriptIDEObjects4.length = 0;
gdjs.scene2Code.GDscriptIDEObjects5.length = 0;
gdjs.scene2Code.GDscriptIDEObjects6.length = 0;
gdjs.scene2Code.GDscriptIDEObjects7.length = 0;
gdjs.scene2Code.GDscriptIDEObjects8.length = 0;
gdjs.scene2Code.GDscriptIDEObjects9.length = 0;

gdjs.scene2Code.eventsList28(runtimeScene);
gdjs.scene2Code.GDspriteObjects1.length = 0;
gdjs.scene2Code.GDspriteObjects2.length = 0;
gdjs.scene2Code.GDspriteObjects3.length = 0;
gdjs.scene2Code.GDspriteObjects4.length = 0;
gdjs.scene2Code.GDspriteObjects5.length = 0;
gdjs.scene2Code.GDspriteObjects6.length = 0;
gdjs.scene2Code.GDspriteObjects7.length = 0;
gdjs.scene2Code.GDspriteObjects8.length = 0;
gdjs.scene2Code.GDspriteObjects9.length = 0;
gdjs.scene2Code.GDdebugObjects1.length = 0;
gdjs.scene2Code.GDdebugObjects2.length = 0;
gdjs.scene2Code.GDdebugObjects3.length = 0;
gdjs.scene2Code.GDdebugObjects4.length = 0;
gdjs.scene2Code.GDdebugObjects5.length = 0;
gdjs.scene2Code.GDdebugObjects6.length = 0;
gdjs.scene2Code.GDdebugObjects7.length = 0;
gdjs.scene2Code.GDdebugObjects8.length = 0;
gdjs.scene2Code.GDdebugObjects9.length = 0;
gdjs.scene2Code.GDdialougObjects1.length = 0;
gdjs.scene2Code.GDdialougObjects2.length = 0;
gdjs.scene2Code.GDdialougObjects3.length = 0;
gdjs.scene2Code.GDdialougObjects4.length = 0;
gdjs.scene2Code.GDdialougObjects5.length = 0;
gdjs.scene2Code.GDdialougObjects6.length = 0;
gdjs.scene2Code.GDdialougObjects7.length = 0;
gdjs.scene2Code.GDdialougObjects8.length = 0;
gdjs.scene2Code.GDdialougObjects9.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects1.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects2.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects3.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects4.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects5.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects6.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects7.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects8.length = 0;
gdjs.scene2Code.GDobject_9595var_9595inputObjects9.length = 0;
gdjs.scene2Code.GDobjectNamesObjects1.length = 0;
gdjs.scene2Code.GDobjectNamesObjects2.length = 0;
gdjs.scene2Code.GDobjectNamesObjects3.length = 0;
gdjs.scene2Code.GDobjectNamesObjects4.length = 0;
gdjs.scene2Code.GDobjectNamesObjects5.length = 0;
gdjs.scene2Code.GDobjectNamesObjects6.length = 0;
gdjs.scene2Code.GDobjectNamesObjects7.length = 0;
gdjs.scene2Code.GDobjectNamesObjects8.length = 0;
gdjs.scene2Code.GDobjectNamesObjects9.length = 0;
gdjs.scene2Code.GDobjectNameObjects1.length = 0;
gdjs.scene2Code.GDobjectNameObjects2.length = 0;
gdjs.scene2Code.GDobjectNameObjects3.length = 0;
gdjs.scene2Code.GDobjectNameObjects4.length = 0;
gdjs.scene2Code.GDobjectNameObjects5.length = 0;
gdjs.scene2Code.GDobjectNameObjects6.length = 0;
gdjs.scene2Code.GDobjectNameObjects7.length = 0;
gdjs.scene2Code.GDobjectNameObjects8.length = 0;
gdjs.scene2Code.GDobjectNameObjects9.length = 0;
gdjs.scene2Code.GDdragNdropObjects1.length = 0;
gdjs.scene2Code.GDdragNdropObjects2.length = 0;
gdjs.scene2Code.GDdragNdropObjects3.length = 0;
gdjs.scene2Code.GDdragNdropObjects4.length = 0;
gdjs.scene2Code.GDdragNdropObjects5.length = 0;
gdjs.scene2Code.GDdragNdropObjects6.length = 0;
gdjs.scene2Code.GDdragNdropObjects7.length = 0;
gdjs.scene2Code.GDdragNdropObjects8.length = 0;
gdjs.scene2Code.GDdragNdropObjects9.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects1.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects2.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects3.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects4.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects5.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects6.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects7.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects8.length = 0;
gdjs.scene2Code.GDobj_9595scpObjects9.length = 0;
gdjs.scene2Code.GDobjectName2Objects1.length = 0;
gdjs.scene2Code.GDobjectName2Objects2.length = 0;
gdjs.scene2Code.GDobjectName2Objects3.length = 0;
gdjs.scene2Code.GDobjectName2Objects4.length = 0;
gdjs.scene2Code.GDobjectName2Objects5.length = 0;
gdjs.scene2Code.GDobjectName2Objects6.length = 0;
gdjs.scene2Code.GDobjectName2Objects7.length = 0;
gdjs.scene2Code.GDobjectName2Objects8.length = 0;
gdjs.scene2Code.GDobjectName2Objects9.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects1.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects2.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects3.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects4.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects5.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects6.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects7.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects8.length = 0;
gdjs.scene2Code.GDfake_9595cuObjects9.length = 0;
gdjs.scene2Code.GDijObjects1.length = 0;
gdjs.scene2Code.GDijObjects2.length = 0;
gdjs.scene2Code.GDijObjects3.length = 0;
gdjs.scene2Code.GDijObjects4.length = 0;
gdjs.scene2Code.GDijObjects5.length = 0;
gdjs.scene2Code.GDijObjects6.length = 0;
gdjs.scene2Code.GDijObjects7.length = 0;
gdjs.scene2Code.GDijObjects8.length = 0;
gdjs.scene2Code.GDijObjects9.length = 0;
gdjs.scene2Code.GDscrObjects1.length = 0;
gdjs.scene2Code.GDscrObjects2.length = 0;
gdjs.scene2Code.GDscrObjects3.length = 0;
gdjs.scene2Code.GDscrObjects4.length = 0;
gdjs.scene2Code.GDscrObjects5.length = 0;
gdjs.scene2Code.GDscrObjects6.length = 0;
gdjs.scene2Code.GDscrObjects7.length = 0;
gdjs.scene2Code.GDscrObjects8.length = 0;
gdjs.scene2Code.GDscrObjects9.length = 0;
gdjs.scene2Code.GDwidthObjects1.length = 0;
gdjs.scene2Code.GDwidthObjects2.length = 0;
gdjs.scene2Code.GDwidthObjects3.length = 0;
gdjs.scene2Code.GDwidthObjects4.length = 0;
gdjs.scene2Code.GDwidthObjects5.length = 0;
gdjs.scene2Code.GDwidthObjects6.length = 0;
gdjs.scene2Code.GDwidthObjects7.length = 0;
gdjs.scene2Code.GDwidthObjects8.length = 0;
gdjs.scene2Code.GDwidthObjects9.length = 0;
gdjs.scene2Code.GDheightObjects1.length = 0;
gdjs.scene2Code.GDheightObjects2.length = 0;
gdjs.scene2Code.GDheightObjects3.length = 0;
gdjs.scene2Code.GDheightObjects4.length = 0;
gdjs.scene2Code.GDheightObjects5.length = 0;
gdjs.scene2Code.GDheightObjects6.length = 0;
gdjs.scene2Code.GDheightObjects7.length = 0;
gdjs.scene2Code.GDheightObjects8.length = 0;
gdjs.scene2Code.GDheightObjects9.length = 0;
gdjs.scene2Code.GDxObjects1.length = 0;
gdjs.scene2Code.GDxObjects2.length = 0;
gdjs.scene2Code.GDxObjects3.length = 0;
gdjs.scene2Code.GDxObjects4.length = 0;
gdjs.scene2Code.GDxObjects5.length = 0;
gdjs.scene2Code.GDxObjects6.length = 0;
gdjs.scene2Code.GDxObjects7.length = 0;
gdjs.scene2Code.GDxObjects8.length = 0;
gdjs.scene2Code.GDxObjects9.length = 0;
gdjs.scene2Code.GDyObjects1.length = 0;
gdjs.scene2Code.GDyObjects2.length = 0;
gdjs.scene2Code.GDyObjects3.length = 0;
gdjs.scene2Code.GDyObjects4.length = 0;
gdjs.scene2Code.GDyObjects5.length = 0;
gdjs.scene2Code.GDyObjects6.length = 0;
gdjs.scene2Code.GDyObjects7.length = 0;
gdjs.scene2Code.GDyObjects8.length = 0;
gdjs.scene2Code.GDyObjects9.length = 0;
gdjs.scene2Code.GDNewTextObjects1.length = 0;
gdjs.scene2Code.GDNewTextObjects2.length = 0;
gdjs.scene2Code.GDNewTextObjects3.length = 0;
gdjs.scene2Code.GDNewTextObjects4.length = 0;
gdjs.scene2Code.GDNewTextObjects5.length = 0;
gdjs.scene2Code.GDNewTextObjects6.length = 0;
gdjs.scene2Code.GDNewTextObjects7.length = 0;
gdjs.scene2Code.GDNewTextObjects8.length = 0;
gdjs.scene2Code.GDNewTextObjects9.length = 0;
gdjs.scene2Code.GDstateObjects1.length = 0;
gdjs.scene2Code.GDstateObjects2.length = 0;
gdjs.scene2Code.GDstateObjects3.length = 0;
gdjs.scene2Code.GDstateObjects4.length = 0;
gdjs.scene2Code.GDstateObjects5.length = 0;
gdjs.scene2Code.GDstateObjects6.length = 0;
gdjs.scene2Code.GDstateObjects7.length = 0;
gdjs.scene2Code.GDstateObjects8.length = 0;
gdjs.scene2Code.GDstateObjects9.length = 0;
gdjs.scene2Code.GDboxObjects1.length = 0;
gdjs.scene2Code.GDboxObjects2.length = 0;
gdjs.scene2Code.GDboxObjects3.length = 0;
gdjs.scene2Code.GDboxObjects4.length = 0;
gdjs.scene2Code.GDboxObjects5.length = 0;
gdjs.scene2Code.GDboxObjects6.length = 0;
gdjs.scene2Code.GDboxObjects7.length = 0;
gdjs.scene2Code.GDboxObjects8.length = 0;
gdjs.scene2Code.GDboxObjects9.length = 0;
gdjs.scene2Code.GDaddObjects1.length = 0;
gdjs.scene2Code.GDaddObjects2.length = 0;
gdjs.scene2Code.GDaddObjects3.length = 0;
gdjs.scene2Code.GDaddObjects4.length = 0;
gdjs.scene2Code.GDaddObjects5.length = 0;
gdjs.scene2Code.GDaddObjects6.length = 0;
gdjs.scene2Code.GDaddObjects7.length = 0;
gdjs.scene2Code.GDaddObjects8.length = 0;
gdjs.scene2Code.GDaddObjects9.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects1.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects2.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects3.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects4.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects5.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects6.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects7.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects8.length = 0;
gdjs.scene2Code.GDobj_9595name_9595giverObjects9.length = 0;
gdjs.scene2Code.GDcreateObjects1.length = 0;
gdjs.scene2Code.GDcreateObjects2.length = 0;
gdjs.scene2Code.GDcreateObjects3.length = 0;
gdjs.scene2Code.GDcreateObjects4.length = 0;
gdjs.scene2Code.GDcreateObjects5.length = 0;
gdjs.scene2Code.GDcreateObjects6.length = 0;
gdjs.scene2Code.GDcreateObjects7.length = 0;
gdjs.scene2Code.GDcreateObjects8.length = 0;
gdjs.scene2Code.GDcreateObjects9.length = 0;
gdjs.scene2Code.GDreObjects1.length = 0;
gdjs.scene2Code.GDreObjects2.length = 0;
gdjs.scene2Code.GDreObjects3.length = 0;
gdjs.scene2Code.GDreObjects4.length = 0;
gdjs.scene2Code.GDreObjects5.length = 0;
gdjs.scene2Code.GDreObjects6.length = 0;
gdjs.scene2Code.GDreObjects7.length = 0;
gdjs.scene2Code.GDreObjects8.length = 0;
gdjs.scene2Code.GDreObjects9.length = 0;
gdjs.scene2Code.GDscriptIDEObjects1.length = 0;
gdjs.scene2Code.GDscriptIDEObjects2.length = 0;
gdjs.scene2Code.GDscriptIDEObjects3.length = 0;
gdjs.scene2Code.GDscriptIDEObjects4.length = 0;
gdjs.scene2Code.GDscriptIDEObjects5.length = 0;
gdjs.scene2Code.GDscriptIDEObjects6.length = 0;
gdjs.scene2Code.GDscriptIDEObjects7.length = 0;
gdjs.scene2Code.GDscriptIDEObjects8.length = 0;
gdjs.scene2Code.GDscriptIDEObjects9.length = 0;


return;

}

gdjs['scene2Code'] = gdjs.scene2Code;
