gdjs.gCode = {};
gdjs.gCode.localVariables = [];
gdjs.gCode.GDNewSpriteObjects1= [];
gdjs.gCode.GDNewSpriteObjects2= [];
gdjs.gCode.GDNewSpriteObjects3= [];
gdjs.gCode.GDNewSpriteObjects4= [];
gdjs.gCode.GDdebugerObjects1= [];
gdjs.gCode.GDdebugerObjects2= [];
gdjs.gCode.GDdebugerObjects3= [];
gdjs.gCode.GDdebugerObjects4= [];


gdjs.gCode.userFunc0xbc4c58 = function GDJSInlineCode(runtimeScene) {
"use strict";
function register(name,w,h){
    runtimeScene.registerObject({"adaptCollisionMaskAutomatically":true,"assetStoreId":"","name":name,"type":"Sprite","updateIfNotVisible":false,"variables":[],"effects":[],"behaviors":[{"name":"Animation","type":"AnimatableCapability::AnimatableBehavior"},{"name":"Effect","type":"EffectCapability::EffectBehavior"},{"name":"Flippable","type":"FlippableCapability::FlippableBehavior"},{"name":"Opacity","type":"OpacityCapability::OpacityBehavior"},{"name":"Resizable","type":"ResizableCapability::ResizableBehavior"},{"name":"Scale","type":"ScalableCapability::ScalableBehavior"}],"animations":[{"name":"djd","useMultipleDirections":false,"directions":[{"looping":false,"metadata":"{\"pskl\":{}}","timeBetweenFrames":0.08,"sprites":[{"hasCustomCollisionMask":true,"image":"djd","points":[],"originPoint":{"name":"origine","x":0,"y":0},"centerPoint":{"automatic":true,"name":"centre","x":0,"y":0},"customCollisionMask":[[{"x":0,"y":0},{"x":w,"y":0},{"x":w,"y":h},{"x":0,"y":h}]]}]}]}]})
}
var obj = runtimeScene.getGame().getVariables().get('objectList').getChildAt(runtimeScene.getVariables().get('index').getAsNumber()).getAsString()
var prop = runtimeScene.getGame().getVariables().get("PerObjectProperties").getChildNamed(obj)
register(obj,prop.getChildNamed("width").getAsNumber(),prop.getChildNamed('height').getAsNumber())
console.log('width: '+prop.getChildNamed("width").getAsNumber()+' height: '+prop.getChildNamed('height').getAsNumber())
runtimeScene.getVariables().get('index').add(1)
};
gdjs.gCode.eventsList0 = function(runtimeScene) {

{


gdjs.gCode.userFunc0xbc4c58(runtimeScene);

}


};gdjs.gCode.eventsList1 = function(runtimeScene) {

{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(2));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {

let isConditionTrue_0 = false;
if (true)
{

{ //Subevents: 
gdjs.gCode.eventsList0(runtimeScene);} //Subevents end.
}
}

}


};gdjs.gCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(1));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("name")) != gdjs.gCode.localVariables[0].getFromIndex(1).getAsString();
if (isConditionTrue_0) {
{gdjs.gCode.localVariables[0].getFromIndex(0).setNumber(0);
}}

}


};gdjs.gCode.eventsList3 = function(runtimeScene) {

{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(1));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {

let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtsExt__UntitledExtension__create.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("name").getAsString(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("x").getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("y").getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite2.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("image").getAsString(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("name").getAsString(), false, gdjs.gCode.localVariables[0].getFromIndex(0).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__UntitledExtension__resixe.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("name").getAsString(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("height").getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("width").getAsNumber(), gdjs.gCode.localVariables[0].getFromIndex(0).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.gCode.localVariables[0].getFromIndex(1).setString(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("name").getAsString());
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}{gdjs.gCode.localVariables[0].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.gCode.eventsList2(runtimeScene);} //Subevents end.
}
}

}


};gdjs.gCode.userFunc0x1031ce8 = function GDJSInlineCode(runtimeScene) {
"use strict";
function object(name){return runtimeScene.getObjects(name)}; function sceneVar(name){return runtimeScene.getVariables().get(name)}
var Num1 = 49
var Num2 = 50
var Num3 = 51
var Num4 = 52
var Num5 = 53
var Num6 = 54
var Num7 = 55
var Num8 = 56
var Num9 = 57
var Num0 = 48
var q = 81
var w = 87
var e = 69
var r = 82
var t = 84
var y = 89
var u = 85
var i = 73
var o = 79
var p = 80
var a = 65
var s = 83
var d = 68
var f = 70
var g = 71
var h = 72
var j = 74
var k = 75
var l = 76
var z = 90
var x = 88
var c = 67
var v = 86
var b = 66
var n = 78
var m = 77
var Space = 32
var Left = 37
var Right = 39
var Up = 38
var Down = 40
var RShift = 2016
var LShift = 1016
var Return = 13
var Back = 8
var Equal = 187
var Dash = 189
var F1 = 112
var F2 = 113
var F3 = 114
var F4 = 115
var F5 = 116
var F6 = 117
var F7 = 118
var F8 = 119
var F9 = 120
var F10 = 121
var F11 = 122
var F12 = 123

function keyPressed(code){
    return runtimeScene.getGame().getInputManager().isKeyPressed(code)
}
function seperate(a,b,id){runtimeScene.getObjects(a)[id].separateFromObjects(runtimeScene.getObjects(b))}
function isCollidingWith(a,b,t){
    return gdjs.RuntimeObject.collisionTest(a,b,t)
}
eval(runtimeScene.getGame().getVariables().get('Script').getAsString())

};
gdjs.gCode.eventsList4 = function(runtimeScene) {

{


gdjs.gCode.userFunc0x1031ce8(runtimeScene);

}


};gdjs.gCode.eventsList5 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("json", variable);
}
gdjs.gCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.gCode.eventsList1(runtimeScene);} //End of subevents
}
gdjs.gCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(2));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15130492);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("counter19", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("checkName", variable);
}
gdjs.gCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(3), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), false, false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.gCode.eventsList3(runtimeScene);} //End of subevents
}
gdjs.gCode.localVariables.pop();

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.gCode.eventsList4(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15133076);
}
if (isConditionTrue_0) {
{gdjs.evtTools.debuggerTools.enableDebugDraw(runtimeScene, true, true, false, true);
}}

}


};

gdjs.gCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.gCode.GDNewSpriteObjects1.length = 0;
gdjs.gCode.GDNewSpriteObjects2.length = 0;
gdjs.gCode.GDNewSpriteObjects3.length = 0;
gdjs.gCode.GDNewSpriteObjects4.length = 0;
gdjs.gCode.GDdebugerObjects1.length = 0;
gdjs.gCode.GDdebugerObjects2.length = 0;
gdjs.gCode.GDdebugerObjects3.length = 0;
gdjs.gCode.GDdebugerObjects4.length = 0;

gdjs.gCode.eventsList5(runtimeScene);
gdjs.gCode.GDNewSpriteObjects1.length = 0;
gdjs.gCode.GDNewSpriteObjects2.length = 0;
gdjs.gCode.GDNewSpriteObjects3.length = 0;
gdjs.gCode.GDNewSpriteObjects4.length = 0;
gdjs.gCode.GDdebugerObjects1.length = 0;
gdjs.gCode.GDdebugerObjects2.length = 0;
gdjs.gCode.GDdebugerObjects3.length = 0;
gdjs.gCode.GDdebugerObjects4.length = 0;


return;

}

gdjs['gCode'] = gdjs.gCode;
