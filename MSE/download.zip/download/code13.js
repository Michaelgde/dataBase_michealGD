gdjs.love2d_95lvl_95builderCode = {};
gdjs.love2d_95lvl_95builderCode.localVariables = [];
gdjs.love2d_95lvl_95builderCode.GDobjObjects1= [];
gdjs.love2d_95lvl_95builderCode.GDobjObjects2= [];
gdjs.love2d_95lvl_95builderCode.GDPenObjects1= [];
gdjs.love2d_95lvl_95builderCode.GDPenObjects2= [];
gdjs.love2d_95lvl_95builderCode.GDdebugObjects1= [];
gdjs.love2d_95lvl_95builderCode.GDdebugObjects2= [];
gdjs.love2d_95lvl_95builderCode.GDPen2Objects1= [];
gdjs.love2d_95lvl_95builderCode.GDPen2Objects2= [];


gdjs.love2d_95lvl_95builderCode.userFunc0xfd8ea8 = function GDJSInlineCode(runtimeScene) {
"use strict";
// Create a hidden canvas and its context
let hiddenCanvas = document.createElement("canvas");
hiddenCanvas.width = 800;  // Set your canvas width
hiddenCanvas.height = 600; // Set your canvas height
let ctx = hiddenCanvas.getContext("2d");

// Texture Image
const image = new Image();
image.src = "file://C:/Users/USER/Pictures/11635.jpg"; // Replace with your texture path

// Wait for the texture to load before drawing on the canvas
image.onload = function() {
    // Draw the texture on the hidden canvas
    ctx.drawImage(image, 0, 0, hiddenCanvas.width, hiddenCanvas.height);

    // Now, find your GDevelop Sprite and set its texture to the canvas
    //const sprite = runtimeScene.getObjects("obj")[0]; // Replace with your sprite's name
    //sprite.setTexture(hiddenCanvas.toDataURL());
};

// Vertices and Faces (for the cube)
const vertices = [
    { x: -50, y: -50, z: -50 },
    { x: 50, y: -50, z: -50 },
    { x: 50, y: 50, z: -50 },
    { x: -50, y: 50, z: -50 },
    { x: -50, y: -50, z: 50 },
    { x: 50, y: -50, z: 50 },
    { x: 50, y: 50, z: 50 },
    { x: -50, y: 50, z: 50 }
];

const faces = [
    [0, 1, 2, 3], // Back face
    [4, 5, 6, 7], // Front face
    [0, 4, 7, 3], // Left face
    [1, 5, 6, 2], // Right face
    [3, 2, 6, 7], // Top face
    [0, 1, 5, 4]  // Bottom face
];
const fa = [
    [0, 1, 2, 3], // Back face
    [4, 5, 6, 7], // Front face
    [0, 4, 7, 3], // Left face
    [1, 5, 6, 2], // Right face
    [3, 2, 6, 7], // Top face
    [0, 1, 5, 4]  // Bottom face
]

// Colors for each face (optional, for solid color faces)
const faceColors = ["red", "blue", "green", "yellow", "cyan", "magenta"];

// Rotation Variables
let rotationY = runtimeScene.getVariables().get("rotationY").getAsNumber();
let rotationX = runtimeScene.getVariables().get("rotationX").getAsNumber();

// Camera parameters
const focalLength = runtimeScene.getVariables().get('camZ').getAsNumber() // Set your focal length here (controls the perspective effect)
const screenWidth = runtimeScene.getGame().getGameResolutionWidth();
const screenHeight = runtimeScene.getGame().getGameResolutionHeight();
const centerX = runtimeScene.getVariables().get("camX").getAsNumber();
const centerY = runtimeScene.getVariables().get("camY").getAsNumber();

// Camera Projection Function (simplified)
function projectPoint(x, y, z) {
    const scale = focalLength / (focalLength + z); // 3D perspective calculation
    return { x: centerX + x * scale, y: centerY - y * scale };
}

// Pen Object for drawing colored faces
const pen = runtimeScene.getObjects("Pen")[0];  // Replace with your Pen object

// Rotation Logic (simplified for Y-axis rotation)
function rotateY(vertex, angle) {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    return {
        x: vertex.x * cos - vertex.z * sin,
        y: vertex.y,
        z: vertex.x * sin + vertex.z * cos
    };
}

function rotateX(vertex, angle) {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    return {
        x: vertex.x,
        y: vertex.y * cos - vertex.z * sin,
        z: vertex.y * sin + vertex.z * cos
    };
}

// Rotate and Project Vertices
const rotatedVertices = vertices.map(vertex => {
    let rotated = rotateY(vertex, rotationY);  // Rotate horizontally
    rotated = rotateX(rotated, rotationX);    // Rotate vertically
    return rotated;
});

// Draw Cube Faces with Colors (using Pen object)
function render(f,x,y){
    faces.forEach((face, index) => {
    const projectedPoints = face.map(vertexIndex => {
        const rotated = rotatedVertices[vertexIndex];
        return projectPoint(rotated.x, rotated.y, rotated.z + 200);
    });

    // Set fill color for the face
    
    // Draw the lines between the points to form the polygon
    for (let i = 0; i < projectedPoints.length; i++) {
        const start = projectedPoints[i];
        const end = projectedPoints[(i + 1) % projectedPoints.length]; // Wrap around to the first point
        //pen.drawRectangle(start.x, start.y, end.x, end.y);
        //pen.drawLine(start.x+o.x, start.y+o.y, end.x+o.x, end.y+o.y,1);
        pen.beginFillPath(start.x+x,start.y+y)
        pen.drawPathLineTo(projectedPoints[(i + 1) % projectedPoints.length].x+x, projectedPoints[(i + 1) % projectedPoints.length].y+y)
        pen.drawPathLineTo(projectedPoints[(i + 2) % projectedPoints.length].x+x, projectedPoints[(i + 2) % projectedPoints.length].y+y)
        pen.drawPathLineTo(projectedPoints[(i + 3) % projectedPoints.length].x+x, projectedPoints[(i + 3) % projectedPoints.length].y+y)
        //pen.endFillPath()
    }

    //
    })
}
render(fa,100,100)
render(fa,100,200)
render(fa,100,300)
pen.drawRectangle(centerX,focalLength,centerX+32,focalLength+32)


};
gdjs.love2d_95lvl_95builderCode.eventsList0 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.love2d_95lvl_95builderCode.GDdebugObjects1);
{for(var i = 0, len = gdjs.love2d_95lvl_95builderCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.love2d_95lvl_95builderCode.GDdebugObjects1[i].getBehavior("Text").setText("cam position" + runtimeScene.getScene().getVariables().getFromIndex(1).getAsString() + " , " + runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() + " , " + runtimeScene.getScene().getVariables().getFromIndex(3).getAsString());
}
}}

}


{



}


{



}


{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13719324);
}
if (isConditionTrue_0) {
}

}


{


gdjs.love2d_95lvl_95builderCode.userFunc0xfd8ea8(runtimeScene);

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).add(0.1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).sub(0.1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).add(0.1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).sub(0.1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).add(10);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).sub(10);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).sub(1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Pen"), gdjs.love2d_95lvl_95builderCode.GDPenObjects1);
{for(var i = 0, len = gdjs.love2d_95lvl_95builderCode.GDPenObjects1.length ;i < len;++i) {
    gdjs.love2d_95lvl_95builderCode.GDPenObjects1[i].beginFillPath(100, 100);
}
}{for(var i = 0, len = gdjs.love2d_95lvl_95builderCode.GDPenObjects1.length ;i < len;++i) {
    gdjs.love2d_95lvl_95builderCode.GDPenObjects1[i].drawPathLineTo(200, 100);
}
}{for(var i = 0, len = gdjs.love2d_95lvl_95builderCode.GDPenObjects1.length ;i < len;++i) {
    gdjs.love2d_95lvl_95builderCode.GDPenObjects1[i].drawPathLineTo(200, 200);
}
}{for(var i = 0, len = gdjs.love2d_95lvl_95builderCode.GDPenObjects1.length ;i < len;++i) {
    gdjs.love2d_95lvl_95builderCode.GDPenObjects1[i].drawPathLineTo(100, 200);
}
}}

}


{



}


};

gdjs.love2d_95lvl_95builderCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.love2d_95lvl_95builderCode.GDobjObjects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDobjObjects2.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPenObjects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPenObjects2.length = 0;
gdjs.love2d_95lvl_95builderCode.GDdebugObjects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDdebugObjects2.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPen2Objects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPen2Objects2.length = 0;

gdjs.love2d_95lvl_95builderCode.eventsList0(runtimeScene);
gdjs.love2d_95lvl_95builderCode.GDobjObjects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDobjObjects2.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPenObjects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPenObjects2.length = 0;
gdjs.love2d_95lvl_95builderCode.GDdebugObjects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDdebugObjects2.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPen2Objects1.length = 0;
gdjs.love2d_95lvl_95builderCode.GDPen2Objects2.length = 0;


return;

}

gdjs['love2d_95lvl_95builderCode'] = gdjs.love2d_95lvl_95builderCode;
