gdjs.renderCode = {};
gdjs.renderCode.localVariables = [];
gdjs.renderCode.GDdObjects1= [];
gdjs.renderCode.GDdObjects2= [];
gdjs.renderCode.GDaObjects1= [];
gdjs.renderCode.GDaObjects2= [];
gdjs.renderCode.GDtooooObjects1= [];
gdjs.renderCode.GDtooooObjects2= [];


gdjs.renderCode.eventsList0 = function(runtimeScene) {

{



}


{



}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("d"), gdjs.renderCode.GDdObjects1);
gdjs.copyArray(runtimeScene.getObjects("toooo"), gdjs.renderCode.GDtooooObjects1);
{for(var i = 0, len = gdjs.renderCode.GDdObjects1.length ;i < len;++i) {
    gdjs.renderCode.GDdObjects1[i].getBehavior("Text").setText("angle: " + gdjs.evtTools.common.toString((( gdjs.renderCode.GDtooooObjects1.length === 0 ) ? 0 :gdjs.renderCode.GDtooooObjects1[0].getAngle())) + "\npos: " + gdjs.evtTools.common.toString((( gdjs.renderCode.GDtooooObjects1.length === 0 ) ? 0 :gdjs.renderCode.GDtooooObjects1[0].getPointX(""))) + " , " + gdjs.evtTools.common.toString((( gdjs.renderCode.GDtooooObjects1.length === 0 ) ? 0 :gdjs.renderCode.GDtooooObjects1[0].getPointY(""))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("a"), gdjs.renderCode.GDaObjects1);
gdjs.copyArray(runtimeScene.getObjects("toooo"), gdjs.renderCode.GDtooooObjects1);
{for(var i = 0, len = gdjs.renderCode.GDtooooObjects1.length ;i < len;++i) {
    gdjs.renderCode.GDtooooObjects1[i].addPolarForce(gdjs.evtTools.common.toNumber((( gdjs.renderCode.GDaObjects1.length === 0 ) ? "" :gdjs.renderCode.GDaObjects1[0].getBehavior("Text").getText())) - 90, 2, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "q");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("toooo"), gdjs.renderCode.GDtooooObjects1);
{for(var i = 0, len = gdjs.renderCode.GDtooooObjects1.length ;i < len;++i) {
    gdjs.renderCode.GDtooooObjects1[i].setPosition(0,0);
}
}}

}


};

gdjs.renderCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.renderCode.GDdObjects1.length = 0;
gdjs.renderCode.GDdObjects2.length = 0;
gdjs.renderCode.GDaObjects1.length = 0;
gdjs.renderCode.GDaObjects2.length = 0;
gdjs.renderCode.GDtooooObjects1.length = 0;
gdjs.renderCode.GDtooooObjects2.length = 0;

gdjs.renderCode.eventsList0(runtimeScene);
gdjs.renderCode.GDdObjects1.length = 0;
gdjs.renderCode.GDdObjects2.length = 0;
gdjs.renderCode.GDaObjects1.length = 0;
gdjs.renderCode.GDaObjects2.length = 0;
gdjs.renderCode.GDtooooObjects1.length = 0;
gdjs.renderCode.GDtooooObjects2.length = 0;


return;

}

gdjs['renderCode'] = gdjs.renderCode;
