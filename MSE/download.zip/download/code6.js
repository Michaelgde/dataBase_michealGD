gdjs.engine2Code = {};
gdjs.engine2Code.localVariables = [];
gdjs.engine2Code.forEachIndex2 = 0;

gdjs.engine2Code.forEachObjects2 = [];

gdjs.engine2Code.forEachTemporary2 = null;

gdjs.engine2Code.forEachTotalCount2 = 0;

gdjs.engine2Code.GDcondition_9595blockObjects1= [];
gdjs.engine2Code.GDcondition_9595blockObjects2= [];
gdjs.engine2Code.GDcondition_9595blockObjects3= [];
gdjs.engine2Code.GDcondition_9595blockObjects4= [];
gdjs.engine2Code.GDcondition_9595blockObjects5= [];
gdjs.engine2Code.GDcondition_9595blockObjects6= [];
gdjs.engine2Code.GDcondition_9595blockObjects7= [];
gdjs.engine2Code.GDcondition_9595blockObjects8= [];
gdjs.engine2Code.GDaction_9595blockObjects1= [];
gdjs.engine2Code.GDaction_9595blockObjects2= [];
gdjs.engine2Code.GDaction_9595blockObjects3= [];
gdjs.engine2Code.GDaction_9595blockObjects4= [];
gdjs.engine2Code.GDaction_9595blockObjects5= [];
gdjs.engine2Code.GDaction_9595blockObjects6= [];
gdjs.engine2Code.GDaction_9595blockObjects7= [];
gdjs.engine2Code.GDaction_9595blockObjects8= [];
gdjs.engine2Code.GDwriterObjects1= [];
gdjs.engine2Code.GDwriterObjects2= [];
gdjs.engine2Code.GDwriterObjects3= [];
gdjs.engine2Code.GDwriterObjects4= [];
gdjs.engine2Code.GDwriterObjects5= [];
gdjs.engine2Code.GDwriterObjects6= [];
gdjs.engine2Code.GDwriterObjects7= [];
gdjs.engine2Code.GDwriterObjects8= [];
gdjs.engine2Code.GDdialougObjects1= [];
gdjs.engine2Code.GDdialougObjects2= [];
gdjs.engine2Code.GDdialougObjects3= [];
gdjs.engine2Code.GDdialougObjects4= [];
gdjs.engine2Code.GDdialougObjects5= [];
gdjs.engine2Code.GDdialougObjects6= [];
gdjs.engine2Code.GDdialougObjects7= [];
gdjs.engine2Code.GDdialougObjects8= [];
gdjs.engine2Code.GDvirtualObjects1= [];
gdjs.engine2Code.GDvirtualObjects2= [];
gdjs.engine2Code.GDvirtualObjects3= [];
gdjs.engine2Code.GDvirtualObjects4= [];
gdjs.engine2Code.GDvirtualObjects5= [];
gdjs.engine2Code.GDvirtualObjects6= [];
gdjs.engine2Code.GDvirtualObjects7= [];
gdjs.engine2Code.GDvirtualObjects8= [];
gdjs.engine2Code.GDsaObjects1= [];
gdjs.engine2Code.GDsaObjects2= [];
gdjs.engine2Code.GDsaObjects3= [];
gdjs.engine2Code.GDsaObjects4= [];
gdjs.engine2Code.GDsaObjects5= [];
gdjs.engine2Code.GDsaObjects6= [];
gdjs.engine2Code.GDsaObjects7= [];
gdjs.engine2Code.GDsaObjects8= [];
gdjs.engine2Code.GDscObjects1= [];
gdjs.engine2Code.GDscObjects2= [];
gdjs.engine2Code.GDscObjects3= [];
gdjs.engine2Code.GDscObjects4= [];
gdjs.engine2Code.GDscObjects5= [];
gdjs.engine2Code.GDscObjects6= [];
gdjs.engine2Code.GDscObjects7= [];
gdjs.engine2Code.GDscObjects8= [];
gdjs.engine2Code.GDwriter2Objects1= [];
gdjs.engine2Code.GDwriter2Objects2= [];
gdjs.engine2Code.GDwriter2Objects3= [];
gdjs.engine2Code.GDwriter2Objects4= [];
gdjs.engine2Code.GDwriter2Objects5= [];
gdjs.engine2Code.GDwriter2Objects6= [];
gdjs.engine2Code.GDwriter2Objects7= [];
gdjs.engine2Code.GDwriter2Objects8= [];
gdjs.engine2Code.GDcode_9595viewObjects1= [];
gdjs.engine2Code.GDcode_9595viewObjects2= [];
gdjs.engine2Code.GDcode_9595viewObjects3= [];
gdjs.engine2Code.GDcode_9595viewObjects4= [];
gdjs.engine2Code.GDcode_9595viewObjects5= [];
gdjs.engine2Code.GDcode_9595viewObjects6= [];
gdjs.engine2Code.GDcode_9595viewObjects7= [];
gdjs.engine2Code.GDcode_9595viewObjects8= [];
gdjs.engine2Code.GDdrawerObjects1= [];
gdjs.engine2Code.GDdrawerObjects2= [];
gdjs.engine2Code.GDdrawerObjects3= [];
gdjs.engine2Code.GDdrawerObjects4= [];
gdjs.engine2Code.GDdrawerObjects5= [];
gdjs.engine2Code.GDdrawerObjects6= [];
gdjs.engine2Code.GDdrawerObjects7= [];
gdjs.engine2Code.GDdrawerObjects8= [];
gdjs.engine2Code.GDaddObjects1= [];
gdjs.engine2Code.GDaddObjects2= [];
gdjs.engine2Code.GDaddObjects3= [];
gdjs.engine2Code.GDaddObjects4= [];
gdjs.engine2Code.GDaddObjects5= [];
gdjs.engine2Code.GDaddObjects6= [];
gdjs.engine2Code.GDaddObjects7= [];
gdjs.engine2Code.GDaddObjects8= [];
gdjs.engine2Code.GDapplyObjects1= [];
gdjs.engine2Code.GDapplyObjects2= [];
gdjs.engine2Code.GDapplyObjects3= [];
gdjs.engine2Code.GDapplyObjects4= [];
gdjs.engine2Code.GDapplyObjects5= [];
gdjs.engine2Code.GDapplyObjects6= [];
gdjs.engine2Code.GDapplyObjects7= [];
gdjs.engine2Code.GDapplyObjects8= [];
gdjs.engine2Code.GDparamInputObjects1= [];
gdjs.engine2Code.GDparamInputObjects2= [];
gdjs.engine2Code.GDparamInputObjects3= [];
gdjs.engine2Code.GDparamInputObjects4= [];
gdjs.engine2Code.GDparamInputObjects5= [];
gdjs.engine2Code.GDparamInputObjects6= [];
gdjs.engine2Code.GDparamInputObjects7= [];
gdjs.engine2Code.GDparamInputObjects8= [];
gdjs.engine2Code.GDcolObjects1= [];
gdjs.engine2Code.GDcolObjects2= [];
gdjs.engine2Code.GDcolObjects3= [];
gdjs.engine2Code.GDcolObjects4= [];
gdjs.engine2Code.GDcolObjects5= [];
gdjs.engine2Code.GDcolObjects6= [];
gdjs.engine2Code.GDcolObjects7= [];
gdjs.engine2Code.GDcolObjects8= [];
gdjs.engine2Code.GDcObjects1= [];
gdjs.engine2Code.GDcObjects2= [];
gdjs.engine2Code.GDcObjects3= [];
gdjs.engine2Code.GDcObjects4= [];
gdjs.engine2Code.GDcObjects5= [];
gdjs.engine2Code.GDcObjects6= [];
gdjs.engine2Code.GDcObjects7= [];
gdjs.engine2Code.GDcObjects8= [];
gdjs.engine2Code.GDaObjects1= [];
gdjs.engine2Code.GDaObjects2= [];
gdjs.engine2Code.GDaObjects3= [];
gdjs.engine2Code.GDaObjects4= [];
gdjs.engine2Code.GDaObjects5= [];
gdjs.engine2Code.GDaObjects6= [];
gdjs.engine2Code.GDaObjects7= [];
gdjs.engine2Code.GDaObjects8= [];
gdjs.engine2Code.GDcol2Objects1= [];
gdjs.engine2Code.GDcol2Objects2= [];
gdjs.engine2Code.GDcol2Objects3= [];
gdjs.engine2Code.GDcol2Objects4= [];
gdjs.engine2Code.GDcol2Objects5= [];
gdjs.engine2Code.GDcol2Objects6= [];
gdjs.engine2Code.GDcol2Objects7= [];
gdjs.engine2Code.GDcol2Objects8= [];
gdjs.engine2Code.GDselectorObjects1= [];
gdjs.engine2Code.GDselectorObjects2= [];
gdjs.engine2Code.GDselectorObjects3= [];
gdjs.engine2Code.GDselectorObjects4= [];
gdjs.engine2Code.GDselectorObjects5= [];
gdjs.engine2Code.GDselectorObjects6= [];
gdjs.engine2Code.GDselectorObjects7= [];
gdjs.engine2Code.GDselectorObjects8= [];
gdjs.engine2Code.GDmoverObjects1= [];
gdjs.engine2Code.GDmoverObjects2= [];
gdjs.engine2Code.GDmoverObjects3= [];
gdjs.engine2Code.GDmoverObjects4= [];
gdjs.engine2Code.GDmoverObjects5= [];
gdjs.engine2Code.GDmoverObjects6= [];
gdjs.engine2Code.GDmoverObjects7= [];
gdjs.engine2Code.GDmoverObjects8= [];


gdjs.engine2Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9366668);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("virtual"), gdjs.engine2Code.GDvirtualObjects2);
{for(var i = 0, len = gdjs.engine2Code.GDvirtualObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDvirtualObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9367788);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}}

}


};gdjs.engine2Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("virtual"), gdjs.engine2Code.GDvirtualObjects1);
{for(var i = 0, len = gdjs.engine2Code.GDvirtualObjects1.length ;i < len;++i) {
    gdjs.engine2Code.GDvirtualObjects1[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}}

}


};gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDaObjects1Objects = Hashtable.newFrom({"a": gdjs.engine2Code.GDaObjects1});
gdjs.engine2Code.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("a"), gdjs.engine2Code.GDaObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDaObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
}

}


};gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDcObjects1Objects = Hashtable.newFrom({"c": gdjs.engine2Code.GDcObjects1});
gdjs.engine2Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("c"), gdjs.engine2Code.GDcObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDcObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
}

}


};gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDcObjects2Objects = Hashtable.newFrom({"c": gdjs.engine2Code.GDcObjects2});
gdjs.engine2Code.eventsList4 = function(runtimeScene) {

};gdjs.engine2Code.eventsList5 = function(runtimeScene) {

{


const repeatCount4 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(9).getChild("variables").getChild(gdjs.engine2Code.localVariables[1].getFromIndex(1).getAsNumber() - 1).getChild("param"));
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(gdjs.engine2Code.GDcObjects2, gdjs.engine2Code.GDcObjects4);


let isConditionTrue_0 = false;
if (true)
{
{for(var i = 0, len = gdjs.engine2Code.GDcObjects4.length ;i < len;++i) {
    gdjs.engine2Code.GDcObjects4[i].getBehavior("Text").setText(gdjs.engine2Code.GDcObjects4[i].getBehavior("Text").getText() + (runtimeScene.getScene().getVariables().getFromIndex(9).getChild("variables").getChild(gdjs.engine2Code.localVariables[1].getFromIndex(1).getAsNumber() - 1).getChild("param").getChild(gdjs.engine2Code.localVariables[1].getFromIndex(0).getAsNumber()).getAsString() + runtimeScene.getScene().getVariables().getFromIndex(9).getChild("variables").getChild(gdjs.engine2Code.localVariables[1].getFromIndex(1).getAsNumber() - 1).getChild("codeE").getChild(gdjs.engine2Code.localVariables[1].getFromIndex(0).getAsNumber() + 1).getAsString()));
}
}{gdjs.engine2Code.localVariables[1].getFromIndex(0).add(1);
}}
}

}


};gdjs.engine2Code.eventsList6 = function(runtimeScene) {

{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(9).getChild("variables"));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(gdjs.engine2Code.GDcObjects1, gdjs.engine2Code.GDcObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDcObjects2Objects, 0, gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber() * 32, "conditions");
}{for(var i = 0, len = gdjs.engine2Code.GDcObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDcObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(9).getChild("variables").getChild(gdjs.engine2Code.localVariables[1].getFromIndex(1).getAsNumber()).getChild("codeE").getChild(0).getAsString());
}
}{for(var i = 0, len = gdjs.engine2Code.GDcObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDcObjects2[i].returnVariable(gdjs.engine2Code.GDcObjects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.engine2Code.localVariables[1].getFromIndex(1).getAsNumber());
}
}{gdjs.engine2Code.localVariables[1].getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.engine2Code.GDcObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDcObjects2[i].returnVariable(gdjs.engine2Code.GDcObjects2[i].getVariables().getFromIndex(1)).setString("variables");
}
}{gdjs.engine2Code.localVariables[0].getFromIndex(0).add(1);
}{gdjs.engine2Code.localVariables[1].getFromIndex(0).setNumber(0);
}
{ //Subevents: 
gdjs.engine2Code.eventsList5(runtimeScene);} //Subevents end.
}
}

}


};gdjs.engine2Code.eventsList7 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("index", variable);
}
gdjs.engine2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.engine2Code.eventsList6(runtimeScene);} //End of subevents
}
gdjs.engine2Code.localVariables.pop();

}


};gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDaObjects2Objects = Hashtable.newFrom({"a": gdjs.engine2Code.GDaObjects2});
gdjs.engine2Code.eventsList8 = function(runtimeScene) {

};gdjs.engine2Code.eventsList9 = function(runtimeScene) {

{


const repeatCount4 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(8).getChild("variables").getChild(gdjs.engine2Code.localVariables[1].getFromIndex(1).getAsNumber() - 1).getChild("param"));
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(gdjs.engine2Code.GDaObjects2, gdjs.engine2Code.GDaObjects4);


let isConditionTrue_0 = false;
if (true)
{
{for(var i = 0, len = gdjs.engine2Code.GDaObjects4.length ;i < len;++i) {
    gdjs.engine2Code.GDaObjects4[i].getBehavior("Text").setText(gdjs.engine2Code.GDaObjects4[i].getBehavior("Text").getText() + (runtimeScene.getScene().getVariables().getFromIndex(8).getChild("variables").getChild(gdjs.engine2Code.localVariables[1].getFromIndex(1).getAsNumber() - 1).getChild("param").getChild(gdjs.engine2Code.localVariables[1].getFromIndex(0).getAsNumber()).getAsString() + runtimeScene.getScene().getVariables().getFromIndex(8).getChild("variables").getChild(gdjs.engine2Code.localVariables[1].getFromIndex(1).getAsNumber() - 1).getChild("codeE").getChild(gdjs.engine2Code.localVariables[1].getFromIndex(0).getAsNumber() + 1).getAsString()));
}
}{gdjs.engine2Code.localVariables[1].getFromIndex(0).add(1);
}}
}

}


};gdjs.engine2Code.eventsList10 = function(runtimeScene) {

{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(8).getChild("variables"));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(gdjs.engine2Code.GDaObjects1, gdjs.engine2Code.GDaObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDaObjects2Objects, 0, gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber() * 32, "action");
}{for(var i = 0, len = gdjs.engine2Code.GDaObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDaObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(8).getChild("variables").getChild(gdjs.engine2Code.localVariables[1].getFromIndex(1).getAsNumber()).getChild("codeE").getChild(0).getAsString());
}
}{for(var i = 0, len = gdjs.engine2Code.GDaObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDaObjects2[i].returnVariable(gdjs.engine2Code.GDaObjects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.engine2Code.localVariables[1].getFromIndex(1).getAsNumber());
}
}{gdjs.engine2Code.localVariables[1].getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.engine2Code.GDaObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDaObjects2[i].returnVariable(gdjs.engine2Code.GDaObjects2[i].getVariables().getFromIndex(1)).setString("variables");
}
}{gdjs.engine2Code.localVariables[0].getFromIndex(0).add(1);
}{gdjs.engine2Code.localVariables[1].getFromIndex(0).setNumber(0);
}
{ //Subevents: 
gdjs.engine2Code.eventsList9(runtimeScene);} //Subevents end.
}
}

}


};gdjs.engine2Code.eventsList11 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("index", variable);
}
gdjs.engine2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.engine2Code.eventsList10(runtimeScene);} //End of subevents
}
gdjs.engine2Code.localVariables.pop();

}


};gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDparamInputObjects2Objects = Hashtable.newFrom({"paramInput": gdjs.engine2Code.GDparamInputObjects2});
gdjs.engine2Code.eventsList12 = function(runtimeScene) {

};gdjs.engine2Code.eventsList13 = function(runtimeScene) {

{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(gdjs.engine2Code.GDparamInputObjects1, gdjs.engine2Code.GDparamInputObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDparamInputObjects2Objects, 384, 96 + (gdjs.engine2Code.localVariables[1].getFromIndex(1).getAsNumber() * 32), "param");
}{for(var i = 0, len = gdjs.engine2Code.GDparamInputObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDparamInputObjects2[i].returnVariable(gdjs.engine2Code.GDparamInputObjects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.engine2Code.localVariables[1].getFromIndex(1).getAsNumber());
}
}{for(var i = 0, len = gdjs.engine2Code.GDparamInputObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDparamInputObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.engine2Code.localVariables[1].getFromIndex(1).getAsNumber()).getAsString());
}
}{gdjs.engine2Code.localVariables[1].getFromIndex(1).add(1);
}}
}

}


};gdjs.engine2Code.eventsList14 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("index", variable);
}
gdjs.engine2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.engine2Code.eventsList13(runtimeScene);} //End of subevents
}
gdjs.engine2Code.localVariables.pop();

}


};gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDapplyObjects1Objects = Hashtable.newFrom({"apply": gdjs.engine2Code.GDapplyObjects1});
gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDcol2Objects3Objects = Hashtable.newFrom({"col2": gdjs.engine2Code.GDcol2Objects3});
gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDaction_95959595blockObjects3Objects = Hashtable.newFrom({"action_block": gdjs.engine2Code.GDaction_9595blockObjects3});
gdjs.engine2Code.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("writer2"), gdjs.engine2Code.GDwriter2Objects3);
{for(var i = 0, len = gdjs.engine2Code.GDwriter2Objects3.length ;i < len;++i) {
    gdjs.engine2Code.GDwriter2Objects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDcol2Objects3Objects = Hashtable.newFrom({"col2": gdjs.engine2Code.GDcol2Objects3});
gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDcondition_95959595blockObjects3Objects = Hashtable.newFrom({"condition_block": gdjs.engine2Code.GDcondition_9595blockObjects3});
gdjs.engine2Code.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("writer"), gdjs.engine2Code.GDwriterObjects3);
{for(var i = 0, len = gdjs.engine2Code.GDwriterObjects3.length ;i < len;++i) {
    gdjs.engine2Code.GDwriterObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.engine2Code.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("action_block"), gdjs.engine2Code.GDaction_9595blockObjects3);
gdjs.copyArray(runtimeScene.getObjects("col2"), gdjs.engine2Code.GDcol2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.engine2Code.localVariables[0].getFromIndex(0)) >= gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDcol2Objects3Objects, gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDaction_95959595blockObjects3Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.engine2Code.GDaction_9595blockObjects3 */
{gdjs.evtTools.network.jsonToObjectVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0)), (gdjs.engine2Code.GDaction_9595blockObjects3.length !== 0 ? gdjs.engine2Code.GDaction_9595blockObjects3[0] : null), ((gdjs.engine2Code.GDaction_9595blockObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engine2Code.GDaction_9595blockObjects3[0].getVariables()).getFromIndex(0));
}
{ //Subevents
gdjs.engine2Code.eventsList15(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("col2"), gdjs.engine2Code.GDcol2Objects3);
gdjs.copyArray(runtimeScene.getObjects("condition_block"), gdjs.engine2Code.GDcondition_9595blockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.engine2Code.localVariables[0].getFromIndex(0)) >= gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDcol2Objects3Objects, gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDcondition_95959595blockObjects3Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.engine2Code.GDcondition_9595blockObjects3 */
{gdjs.evtTools.network.jsonToObjectVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(0)), (gdjs.engine2Code.GDcondition_9595blockObjects3.length !== 0 ? gdjs.engine2Code.GDcondition_9595blockObjects3[0] : null), ((gdjs.engine2Code.GDcondition_9595blockObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engine2Code.GDcondition_9595blockObjects3[0].getVariables()).getFromIndex(0));
}
{ //Subevents
gdjs.engine2Code.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.engine2Code.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("paramInput"), gdjs.engine2Code.GDparamInputObjects1);

for (gdjs.engine2Code.forEachIndex2 = 0;gdjs.engine2Code.forEachIndex2 < gdjs.engine2Code.GDparamInputObjects1.length;++gdjs.engine2Code.forEachIndex2) {
gdjs.engine2Code.GDparamInputObjects2.length = 0;


gdjs.engine2Code.forEachTemporary2 = gdjs.engine2Code.GDparamInputObjects1[gdjs.engine2Code.forEachIndex2];
gdjs.engine2Code.GDparamInputObjects2.push(gdjs.engine2Code.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild(((gdjs.engine2Code.GDparamInputObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.engine2Code.GDparamInputObjects2[0].getVariables()).getFromIndex(0).getAsNumber()).setString((( gdjs.engine2Code.GDparamInputObjects2.length === 0 ) ? "" :gdjs.engine2Code.GDparamInputObjects2[0].getBehavior("Text").getText()));
}{gdjs.engine2Code.localVariables[0].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.engine2Code.eventsList17(runtimeScene);} //Subevents end.
}
}

}


};gdjs.engine2Code.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("apply"), gdjs.engine2Code.GDapplyObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count", variable);
}
gdjs.engine2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDapplyObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.engine2Code.eventsList18(runtimeScene);} //End of subevents
}
gdjs.engine2Code.localVariables.pop();

}


};gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDcondition_95959595blockObjects2Objects = Hashtable.newFrom({"condition_block": gdjs.engine2Code.GDcondition_9595blockObjects2});
gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDaction_95959595blockObjects1Objects = Hashtable.newFrom({"action_block": gdjs.engine2Code.GDaction_9595blockObjects1});
gdjs.engine2Code.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("condition_block"), gdjs.engine2Code.GDcondition_9595blockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDcondition_95959595blockObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(13), false, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.engine2Code.GDcondition_9595blockObjects2 */
gdjs.copyArray(runtimeScene.getObjects("selector"), gdjs.engine2Code.GDselectorObjects2);
{for(var i = 0, len = gdjs.engine2Code.GDselectorObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDselectorObjects2[i].setPosition((( gdjs.engine2Code.GDcondition_9595blockObjects2.length === 0 ) ? 0 :gdjs.engine2Code.GDcondition_9595blockObjects2[0].getPointX("")),(( gdjs.engine2Code.GDcondition_9595blockObjects2.length === 0 ) ? 0 :gdjs.engine2Code.GDcondition_9595blockObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.engine2Code.GDselectorObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDselectorObjects2[i].setZOrder((( gdjs.engine2Code.GDcondition_9595blockObjects2.length === 0 ) ? 0 :gdjs.engine2Code.GDcondition_9595blockObjects2[0].getZOrder()) + 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("action_block"), gdjs.engine2Code.GDaction_9595blockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDaction_95959595blockObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(13), false, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.engine2Code.GDaction_9595blockObjects1 */
gdjs.copyArray(runtimeScene.getObjects("selector"), gdjs.engine2Code.GDselectorObjects1);
{for(var i = 0, len = gdjs.engine2Code.GDselectorObjects1.length ;i < len;++i) {
    gdjs.engine2Code.GDselectorObjects1[i].setPosition((( gdjs.engine2Code.GDaction_9595blockObjects1.length === 0 ) ? 0 :gdjs.engine2Code.GDaction_9595blockObjects1[0].getPointX("")) - 640,(( gdjs.engine2Code.GDaction_9595blockObjects1.length === 0 ) ? 0 :gdjs.engine2Code.GDaction_9595blockObjects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.engine2Code.GDselectorObjects1.length ;i < len;++i) {
    gdjs.engine2Code.GDselectorObjects1[i].setZOrder((( gdjs.engine2Code.GDaction_9595blockObjects1.length === 0 ) ? 0 :gdjs.engine2Code.GDaction_9595blockObjects1[0].getZOrder()) + 1);
}
}}

}


};gdjs.engine2Code.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.engine2Code.eventsList22 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14393604);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(13).setBoolean(false);
}
{ //Subevents
gdjs.engine2Code.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDaction_95959595blockObjects2Objects = Hashtable.newFrom({"action_block": gdjs.engine2Code.GDaction_9595blockObjects2});
gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDcondition_95959595blockObjects2Objects = Hashtable.newFrom({"condition_block": gdjs.engine2Code.GDcondition_9595blockObjects2});
gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDwriterObjects2Objects = Hashtable.newFrom({"writer": gdjs.engine2Code.GDwriterObjects2});
gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDwriter2Objects2Objects = Hashtable.newFrom({"writer2": gdjs.engine2Code.GDwriter2Objects2});
gdjs.engine2Code.eventsList23 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.engine2Code.localVariables[0].getFromIndex(1)) >= gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(16).getChild(gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("action").getChild(gdjs.engine2Code.localVariables[0].getFromIndex(2).getAsNumber() - 1).getChild("param"));
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.engine2Code.GDwriter2Objects6, gdjs.engine2Code.GDwriter2Objects7);

{for(var i = 0, len = gdjs.engine2Code.GDwriter2Objects7.length ;i < len;++i) {
    gdjs.engine2Code.GDwriter2Objects7[i].getBehavior("Text").setText(gdjs.engine2Code.GDwriter2Objects7[i].getBehavior("Text").getText() + (gdjs.evtTools.string.newLine()));
}
}}

}


};gdjs.engine2Code.eventsList24 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.engine2Code.localVariables[0].getFromIndex(2)) > gdjs.engine2Code.localVariables[0].getFromIndex(3).getAsNumber();
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.engine2Code.GDaction_9595blockObjects2, gdjs.engine2Code.GDaction_9595blockObjects5);

{gdjs.engine2Code.localVariables[0].getFromIndex(4).setNumber(gdjs.engine2Code.localVariables[0].getFromIndex(2).getAsNumber());
}{for(var i = 0, len = gdjs.engine2Code.GDaction_9595blockObjects5.length ;i < len;++i) {
    gdjs.engine2Code.GDaction_9595blockObjects5[i].getBehavior("Resizable").setHeight(gdjs.engine2Code.localVariables[0].getFromIndex(4).getAsNumber() * 20);
}
}}

}


{


const repeatCount6 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(16).getChild(gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("action").getChild(gdjs.engine2Code.localVariables[0].getFromIndex(2).getAsNumber() - 1).getChild("param"));
for (let repeatIndex6 = 0;repeatIndex6 < repeatCount6;++repeatIndex6) {
gdjs.copyArray(gdjs.engine2Code.GDwriter2Objects4, gdjs.engine2Code.GDwriter2Objects6);


let isConditionTrue_0 = false;
if (true)
{
{for(var i = 0, len = gdjs.engine2Code.GDwriter2Objects6.length ;i < len;++i) {
    gdjs.engine2Code.GDwriter2Objects6[i].getBehavior("Text").setText(gdjs.engine2Code.GDwriter2Objects6[i].getBehavior("Text").getText() + (runtimeScene.getScene().getVariables().getFromIndex(16).getChild(gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("action").getChild(gdjs.engine2Code.localVariables[0].getFromIndex(2).getAsNumber() - 1).getChild("param").getChild(gdjs.engine2Code.localVariables[0].getFromIndex(1).getAsNumber()).getAsString() + runtimeScene.getScene().getVariables().getFromIndex(16).getChild(gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("action").getChild(gdjs.engine2Code.localVariables[0].getFromIndex(2).getAsNumber() - 1).getChild("codeE").getChild(gdjs.engine2Code.localVariables[0].getFromIndex(1).getAsNumber() + 1).getAsString()));
}
}{gdjs.engine2Code.localVariables[0].getFromIndex(1).add(1);
}
{ //Subevents: 
gdjs.engine2Code.eventsList23(runtimeScene);} //Subevents end.
}
}

}


};gdjs.engine2Code.eventsList25 = function(runtimeScene) {

};gdjs.engine2Code.eventsList26 = function(runtimeScene) {

{


const repeatCount4 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(16).getChild(gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("action"));
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(gdjs.engine2Code.GDwriter2Objects2, gdjs.engine2Code.GDwriter2Objects4);


let isConditionTrue_0 = false;
if (true)
{
{for(var i = 0, len = gdjs.engine2Code.GDwriter2Objects4.length ;i < len;++i) {
    gdjs.engine2Code.GDwriter2Objects4[i].getBehavior("Text").setText(gdjs.engine2Code.GDwriter2Objects4[i].getBehavior("Text").getText() + (runtimeScene.getScene().getVariables().getFromIndex(16).getChild(gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("action").getChild(0).getChild("codeE").getChild(0).getAsString()));
}
}{gdjs.engine2Code.localVariables[0].getFromIndex(2).add(1);
}{gdjs.engine2Code.localVariables[0].getFromIndex(1).setNumber(0);
}
{ //Subevents: 
gdjs.engine2Code.eventsList24(runtimeScene);} //Subevents end.
}
}

}


{


const repeatCount4 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(16).getChild(gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("condition"));
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {

let isConditionTrue_0 = false;
if (true)
{
}
}

}


};gdjs.engine2Code.eventsList27 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(16));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(gdjs.engine2Code.GDaction_9595blockObjects1, gdjs.engine2Code.GDaction_9595blockObjects2);

gdjs.copyArray(gdjs.engine2Code.GDcondition_9595blockObjects1, gdjs.engine2Code.GDcondition_9595blockObjects2);

gdjs.copyArray(gdjs.engine2Code.GDwriterObjects1, gdjs.engine2Code.GDwriterObjects2);

gdjs.copyArray(gdjs.engine2Code.GDwriter2Objects1, gdjs.engine2Code.GDwriter2Objects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.engine2Code.localVariables[0].getFromIndex(0).add(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDaction_95959595blockObjects2Objects, 640, (32 * gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber()) + gdjs.engine2Code.localVariables[0].getFromIndex(4).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDcondition_95959595blockObjects2Objects, 0, (32 * gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber()) + gdjs.engine2Code.localVariables[0].getFromIndex(4).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDwriterObjects2Objects, 0, -(5) + (32 * gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber()) + gdjs.engine2Code.localVariables[0].getFromIndex(4).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.engine2Code.mapOfGDgdjs_9546engine2Code_9546GDwriter2Objects2Objects, 640, (32 * gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber()) + gdjs.engine2Code.localVariables[0].getFromIndex(4).getAsNumber(), "");
}{for(var i = 0, len = gdjs.engine2Code.GDcondition_9595blockObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDcondition_9595blockObjects2[i].returnVariable(gdjs.engine2Code.GDcondition_9595blockObjects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber());
}
}{for(var i = 0, len = gdjs.engine2Code.GDaction_9595blockObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDaction_9595blockObjects2[i].returnVariable(gdjs.engine2Code.GDaction_9595blockObjects2[i].getVariables().getFromIndex(5)).setNumber(gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber());
}
}{gdjs.engine2Code.localVariables[0].getFromIndex(2).setNumber(0);
}{gdjs.engine2Code.localVariables[0].getFromIndex(3).setNumber(0);
}{for(var i = 0, len = gdjs.engine2Code.GDwriter2Objects2.length ;i < len;++i) {
    gdjs.engine2Code.GDwriter2Objects2[i].getBehavior("Text").setText("");
}
}{for(var i = 0, len = gdjs.engine2Code.GDwriterObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDwriterObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(16).getChild(gdjs.engine2Code.localVariables[0].getFromIndex(0).getAsNumber()).getChild("condition").getChild(0).getChild("codeE").getChild(0).getAsString());
}
}{for(var i = 0, len = gdjs.engine2Code.GDcondition_9595blockObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDcondition_9595blockObjects2[i].getBehavior("Resizable").setWidth(400);
}
}{for(var i = 0, len = gdjs.engine2Code.GDaction_9595blockObjects2.length ;i < len;++i) {
    gdjs.engine2Code.GDaction_9595blockObjects2[i].getBehavior("Resizable").setWidth(400);
}
}
{ //Subevents: 
gdjs.engine2Code.eventsList26(runtimeScene);} //Subevents end.
}
}

}


};gdjs.engine2Code.eventsList28 = function(runtimeScene) {

{


gdjs.engine2Code.eventsList0(runtimeScene);
}


{


gdjs.engine2Code.eventsList1(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "action");
if (isConditionTrue_0) {

{ //Subevents
gdjs.engine2Code.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conditions");
if (isConditionTrue_0) {

{ //Subevents
gdjs.engine2Code.eventsList3(runtimeScene);} //End of subevents
}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(1);
variables._declare("counter", variable);
}
gdjs.engine2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conditions");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14402292);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("c"), gdjs.engine2Code.GDcObjects1);
{for(var i = 0, len = gdjs.engine2Code.GDcObjects1.length ;i < len;++i) {
    gdjs.engine2Code.GDcObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.engine2Code.eventsList7(runtimeScene);} //End of subevents
}
gdjs.engine2Code.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(1);
variables._declare("counter", variable);
}
gdjs.engine2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "action");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14407900);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("a"), gdjs.engine2Code.GDaObjects1);
{for(var i = 0, len = gdjs.engine2Code.GDaObjects1.length ;i < len;++i) {
    gdjs.engine2Code.GDaObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.engine2Code.eventsList11(runtimeScene);} //End of subevents
}
gdjs.engine2Code.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(1);
variables._declare("counter", variable);
}
gdjs.engine2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "param");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14413564);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("paramInput"), gdjs.engine2Code.GDparamInputObjects1);
{for(var i = 0, len = gdjs.engine2Code.GDparamInputObjects1.length ;i < len;++i) {
    gdjs.engine2Code.GDparamInputObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.engine2Code.eventsList14(runtimeScene);} //End of subevents
}
gdjs.engine2Code.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "param");
if (isConditionTrue_0) {

{ //Subevents
gdjs.engine2Code.eventsList19(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {

{ //Subevents
gdjs.engine2Code.eventsList20(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(13), true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.engine2Code.eventsList22(runtimeScene);} //End of subevents
}

}


{



}


{



}


{



}


{



}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(-1);
variables._declare("climb2", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("Aclimb", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("TEMPheight_a_", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("TEMPheight_c_", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("F_TEMPheight", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("Cclimb", variable);
}
gdjs.engine2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12624764);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("action_block"), gdjs.engine2Code.GDaction_9595blockObjects1);
gdjs.copyArray(runtimeScene.getObjects("condition_block"), gdjs.engine2Code.GDcondition_9595blockObjects1);
gdjs.copyArray(runtimeScene.getObjects("writer"), gdjs.engine2Code.GDwriterObjects1);
gdjs.copyArray(runtimeScene.getObjects("writer2"), gdjs.engine2Code.GDwriter2Objects1);
{for(var i = 0, len = gdjs.engine2Code.GDcondition_9595blockObjects1.length ;i < len;++i) {
    gdjs.engine2Code.GDcondition_9595blockObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.engine2Code.GDaction_9595blockObjects1.length ;i < len;++i) {
    gdjs.engine2Code.GDaction_9595blockObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.engine2Code.GDwriterObjects1.length ;i < len;++i) {
    gdjs.engine2Code.GDwriterObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.engine2Code.GDwriter2Objects1.length ;i < len;++i) {
    gdjs.engine2Code.GDwriter2Objects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.engine2Code.eventsList27(runtimeScene);} //End of subevents
}
gdjs.engine2Code.localVariables.pop();

}


};

gdjs.engine2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.engine2Code.GDcondition_9595blockObjects1.length = 0;
gdjs.engine2Code.GDcondition_9595blockObjects2.length = 0;
gdjs.engine2Code.GDcondition_9595blockObjects3.length = 0;
gdjs.engine2Code.GDcondition_9595blockObjects4.length = 0;
gdjs.engine2Code.GDcondition_9595blockObjects5.length = 0;
gdjs.engine2Code.GDcondition_9595blockObjects6.length = 0;
gdjs.engine2Code.GDcondition_9595blockObjects7.length = 0;
gdjs.engine2Code.GDcondition_9595blockObjects8.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects1.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects2.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects3.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects4.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects5.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects6.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects7.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects8.length = 0;
gdjs.engine2Code.GDwriterObjects1.length = 0;
gdjs.engine2Code.GDwriterObjects2.length = 0;
gdjs.engine2Code.GDwriterObjects3.length = 0;
gdjs.engine2Code.GDwriterObjects4.length = 0;
gdjs.engine2Code.GDwriterObjects5.length = 0;
gdjs.engine2Code.GDwriterObjects6.length = 0;
gdjs.engine2Code.GDwriterObjects7.length = 0;
gdjs.engine2Code.GDwriterObjects8.length = 0;
gdjs.engine2Code.GDdialougObjects1.length = 0;
gdjs.engine2Code.GDdialougObjects2.length = 0;
gdjs.engine2Code.GDdialougObjects3.length = 0;
gdjs.engine2Code.GDdialougObjects4.length = 0;
gdjs.engine2Code.GDdialougObjects5.length = 0;
gdjs.engine2Code.GDdialougObjects6.length = 0;
gdjs.engine2Code.GDdialougObjects7.length = 0;
gdjs.engine2Code.GDdialougObjects8.length = 0;
gdjs.engine2Code.GDvirtualObjects1.length = 0;
gdjs.engine2Code.GDvirtualObjects2.length = 0;
gdjs.engine2Code.GDvirtualObjects3.length = 0;
gdjs.engine2Code.GDvirtualObjects4.length = 0;
gdjs.engine2Code.GDvirtualObjects5.length = 0;
gdjs.engine2Code.GDvirtualObjects6.length = 0;
gdjs.engine2Code.GDvirtualObjects7.length = 0;
gdjs.engine2Code.GDvirtualObjects8.length = 0;
gdjs.engine2Code.GDsaObjects1.length = 0;
gdjs.engine2Code.GDsaObjects2.length = 0;
gdjs.engine2Code.GDsaObjects3.length = 0;
gdjs.engine2Code.GDsaObjects4.length = 0;
gdjs.engine2Code.GDsaObjects5.length = 0;
gdjs.engine2Code.GDsaObjects6.length = 0;
gdjs.engine2Code.GDsaObjects7.length = 0;
gdjs.engine2Code.GDsaObjects8.length = 0;
gdjs.engine2Code.GDscObjects1.length = 0;
gdjs.engine2Code.GDscObjects2.length = 0;
gdjs.engine2Code.GDscObjects3.length = 0;
gdjs.engine2Code.GDscObjects4.length = 0;
gdjs.engine2Code.GDscObjects5.length = 0;
gdjs.engine2Code.GDscObjects6.length = 0;
gdjs.engine2Code.GDscObjects7.length = 0;
gdjs.engine2Code.GDscObjects8.length = 0;
gdjs.engine2Code.GDwriter2Objects1.length = 0;
gdjs.engine2Code.GDwriter2Objects2.length = 0;
gdjs.engine2Code.GDwriter2Objects3.length = 0;
gdjs.engine2Code.GDwriter2Objects4.length = 0;
gdjs.engine2Code.GDwriter2Objects5.length = 0;
gdjs.engine2Code.GDwriter2Objects6.length = 0;
gdjs.engine2Code.GDwriter2Objects7.length = 0;
gdjs.engine2Code.GDwriter2Objects8.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects1.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects2.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects3.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects4.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects5.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects6.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects7.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects8.length = 0;
gdjs.engine2Code.GDdrawerObjects1.length = 0;
gdjs.engine2Code.GDdrawerObjects2.length = 0;
gdjs.engine2Code.GDdrawerObjects3.length = 0;
gdjs.engine2Code.GDdrawerObjects4.length = 0;
gdjs.engine2Code.GDdrawerObjects5.length = 0;
gdjs.engine2Code.GDdrawerObjects6.length = 0;
gdjs.engine2Code.GDdrawerObjects7.length = 0;
gdjs.engine2Code.GDdrawerObjects8.length = 0;
gdjs.engine2Code.GDaddObjects1.length = 0;
gdjs.engine2Code.GDaddObjects2.length = 0;
gdjs.engine2Code.GDaddObjects3.length = 0;
gdjs.engine2Code.GDaddObjects4.length = 0;
gdjs.engine2Code.GDaddObjects5.length = 0;
gdjs.engine2Code.GDaddObjects6.length = 0;
gdjs.engine2Code.GDaddObjects7.length = 0;
gdjs.engine2Code.GDaddObjects8.length = 0;
gdjs.engine2Code.GDapplyObjects1.length = 0;
gdjs.engine2Code.GDapplyObjects2.length = 0;
gdjs.engine2Code.GDapplyObjects3.length = 0;
gdjs.engine2Code.GDapplyObjects4.length = 0;
gdjs.engine2Code.GDapplyObjects5.length = 0;
gdjs.engine2Code.GDapplyObjects6.length = 0;
gdjs.engine2Code.GDapplyObjects7.length = 0;
gdjs.engine2Code.GDapplyObjects8.length = 0;
gdjs.engine2Code.GDparamInputObjects1.length = 0;
gdjs.engine2Code.GDparamInputObjects2.length = 0;
gdjs.engine2Code.GDparamInputObjects3.length = 0;
gdjs.engine2Code.GDparamInputObjects4.length = 0;
gdjs.engine2Code.GDparamInputObjects5.length = 0;
gdjs.engine2Code.GDparamInputObjects6.length = 0;
gdjs.engine2Code.GDparamInputObjects7.length = 0;
gdjs.engine2Code.GDparamInputObjects8.length = 0;
gdjs.engine2Code.GDcolObjects1.length = 0;
gdjs.engine2Code.GDcolObjects2.length = 0;
gdjs.engine2Code.GDcolObjects3.length = 0;
gdjs.engine2Code.GDcolObjects4.length = 0;
gdjs.engine2Code.GDcolObjects5.length = 0;
gdjs.engine2Code.GDcolObjects6.length = 0;
gdjs.engine2Code.GDcolObjects7.length = 0;
gdjs.engine2Code.GDcolObjects8.length = 0;
gdjs.engine2Code.GDcObjects1.length = 0;
gdjs.engine2Code.GDcObjects2.length = 0;
gdjs.engine2Code.GDcObjects3.length = 0;
gdjs.engine2Code.GDcObjects4.length = 0;
gdjs.engine2Code.GDcObjects5.length = 0;
gdjs.engine2Code.GDcObjects6.length = 0;
gdjs.engine2Code.GDcObjects7.length = 0;
gdjs.engine2Code.GDcObjects8.length = 0;
gdjs.engine2Code.GDaObjects1.length = 0;
gdjs.engine2Code.GDaObjects2.length = 0;
gdjs.engine2Code.GDaObjects3.length = 0;
gdjs.engine2Code.GDaObjects4.length = 0;
gdjs.engine2Code.GDaObjects5.length = 0;
gdjs.engine2Code.GDaObjects6.length = 0;
gdjs.engine2Code.GDaObjects7.length = 0;
gdjs.engine2Code.GDaObjects8.length = 0;
gdjs.engine2Code.GDcol2Objects1.length = 0;
gdjs.engine2Code.GDcol2Objects2.length = 0;
gdjs.engine2Code.GDcol2Objects3.length = 0;
gdjs.engine2Code.GDcol2Objects4.length = 0;
gdjs.engine2Code.GDcol2Objects5.length = 0;
gdjs.engine2Code.GDcol2Objects6.length = 0;
gdjs.engine2Code.GDcol2Objects7.length = 0;
gdjs.engine2Code.GDcol2Objects8.length = 0;
gdjs.engine2Code.GDselectorObjects1.length = 0;
gdjs.engine2Code.GDselectorObjects2.length = 0;
gdjs.engine2Code.GDselectorObjects3.length = 0;
gdjs.engine2Code.GDselectorObjects4.length = 0;
gdjs.engine2Code.GDselectorObjects5.length = 0;
gdjs.engine2Code.GDselectorObjects6.length = 0;
gdjs.engine2Code.GDselectorObjects7.length = 0;
gdjs.engine2Code.GDselectorObjects8.length = 0;
gdjs.engine2Code.GDmoverObjects1.length = 0;
gdjs.engine2Code.GDmoverObjects2.length = 0;
gdjs.engine2Code.GDmoverObjects3.length = 0;
gdjs.engine2Code.GDmoverObjects4.length = 0;
gdjs.engine2Code.GDmoverObjects5.length = 0;
gdjs.engine2Code.GDmoverObjects6.length = 0;
gdjs.engine2Code.GDmoverObjects7.length = 0;
gdjs.engine2Code.GDmoverObjects8.length = 0;

gdjs.engine2Code.eventsList28(runtimeScene);
gdjs.engine2Code.GDcondition_9595blockObjects1.length = 0;
gdjs.engine2Code.GDcondition_9595blockObjects2.length = 0;
gdjs.engine2Code.GDcondition_9595blockObjects3.length = 0;
gdjs.engine2Code.GDcondition_9595blockObjects4.length = 0;
gdjs.engine2Code.GDcondition_9595blockObjects5.length = 0;
gdjs.engine2Code.GDcondition_9595blockObjects6.length = 0;
gdjs.engine2Code.GDcondition_9595blockObjects7.length = 0;
gdjs.engine2Code.GDcondition_9595blockObjects8.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects1.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects2.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects3.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects4.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects5.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects6.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects7.length = 0;
gdjs.engine2Code.GDaction_9595blockObjects8.length = 0;
gdjs.engine2Code.GDwriterObjects1.length = 0;
gdjs.engine2Code.GDwriterObjects2.length = 0;
gdjs.engine2Code.GDwriterObjects3.length = 0;
gdjs.engine2Code.GDwriterObjects4.length = 0;
gdjs.engine2Code.GDwriterObjects5.length = 0;
gdjs.engine2Code.GDwriterObjects6.length = 0;
gdjs.engine2Code.GDwriterObjects7.length = 0;
gdjs.engine2Code.GDwriterObjects8.length = 0;
gdjs.engine2Code.GDdialougObjects1.length = 0;
gdjs.engine2Code.GDdialougObjects2.length = 0;
gdjs.engine2Code.GDdialougObjects3.length = 0;
gdjs.engine2Code.GDdialougObjects4.length = 0;
gdjs.engine2Code.GDdialougObjects5.length = 0;
gdjs.engine2Code.GDdialougObjects6.length = 0;
gdjs.engine2Code.GDdialougObjects7.length = 0;
gdjs.engine2Code.GDdialougObjects8.length = 0;
gdjs.engine2Code.GDvirtualObjects1.length = 0;
gdjs.engine2Code.GDvirtualObjects2.length = 0;
gdjs.engine2Code.GDvirtualObjects3.length = 0;
gdjs.engine2Code.GDvirtualObjects4.length = 0;
gdjs.engine2Code.GDvirtualObjects5.length = 0;
gdjs.engine2Code.GDvirtualObjects6.length = 0;
gdjs.engine2Code.GDvirtualObjects7.length = 0;
gdjs.engine2Code.GDvirtualObjects8.length = 0;
gdjs.engine2Code.GDsaObjects1.length = 0;
gdjs.engine2Code.GDsaObjects2.length = 0;
gdjs.engine2Code.GDsaObjects3.length = 0;
gdjs.engine2Code.GDsaObjects4.length = 0;
gdjs.engine2Code.GDsaObjects5.length = 0;
gdjs.engine2Code.GDsaObjects6.length = 0;
gdjs.engine2Code.GDsaObjects7.length = 0;
gdjs.engine2Code.GDsaObjects8.length = 0;
gdjs.engine2Code.GDscObjects1.length = 0;
gdjs.engine2Code.GDscObjects2.length = 0;
gdjs.engine2Code.GDscObjects3.length = 0;
gdjs.engine2Code.GDscObjects4.length = 0;
gdjs.engine2Code.GDscObjects5.length = 0;
gdjs.engine2Code.GDscObjects6.length = 0;
gdjs.engine2Code.GDscObjects7.length = 0;
gdjs.engine2Code.GDscObjects8.length = 0;
gdjs.engine2Code.GDwriter2Objects1.length = 0;
gdjs.engine2Code.GDwriter2Objects2.length = 0;
gdjs.engine2Code.GDwriter2Objects3.length = 0;
gdjs.engine2Code.GDwriter2Objects4.length = 0;
gdjs.engine2Code.GDwriter2Objects5.length = 0;
gdjs.engine2Code.GDwriter2Objects6.length = 0;
gdjs.engine2Code.GDwriter2Objects7.length = 0;
gdjs.engine2Code.GDwriter2Objects8.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects1.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects2.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects3.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects4.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects5.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects6.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects7.length = 0;
gdjs.engine2Code.GDcode_9595viewObjects8.length = 0;
gdjs.engine2Code.GDdrawerObjects1.length = 0;
gdjs.engine2Code.GDdrawerObjects2.length = 0;
gdjs.engine2Code.GDdrawerObjects3.length = 0;
gdjs.engine2Code.GDdrawerObjects4.length = 0;
gdjs.engine2Code.GDdrawerObjects5.length = 0;
gdjs.engine2Code.GDdrawerObjects6.length = 0;
gdjs.engine2Code.GDdrawerObjects7.length = 0;
gdjs.engine2Code.GDdrawerObjects8.length = 0;
gdjs.engine2Code.GDaddObjects1.length = 0;
gdjs.engine2Code.GDaddObjects2.length = 0;
gdjs.engine2Code.GDaddObjects3.length = 0;
gdjs.engine2Code.GDaddObjects4.length = 0;
gdjs.engine2Code.GDaddObjects5.length = 0;
gdjs.engine2Code.GDaddObjects6.length = 0;
gdjs.engine2Code.GDaddObjects7.length = 0;
gdjs.engine2Code.GDaddObjects8.length = 0;
gdjs.engine2Code.GDapplyObjects1.length = 0;
gdjs.engine2Code.GDapplyObjects2.length = 0;
gdjs.engine2Code.GDapplyObjects3.length = 0;
gdjs.engine2Code.GDapplyObjects4.length = 0;
gdjs.engine2Code.GDapplyObjects5.length = 0;
gdjs.engine2Code.GDapplyObjects6.length = 0;
gdjs.engine2Code.GDapplyObjects7.length = 0;
gdjs.engine2Code.GDapplyObjects8.length = 0;
gdjs.engine2Code.GDparamInputObjects1.length = 0;
gdjs.engine2Code.GDparamInputObjects2.length = 0;
gdjs.engine2Code.GDparamInputObjects3.length = 0;
gdjs.engine2Code.GDparamInputObjects4.length = 0;
gdjs.engine2Code.GDparamInputObjects5.length = 0;
gdjs.engine2Code.GDparamInputObjects6.length = 0;
gdjs.engine2Code.GDparamInputObjects7.length = 0;
gdjs.engine2Code.GDparamInputObjects8.length = 0;
gdjs.engine2Code.GDcolObjects1.length = 0;
gdjs.engine2Code.GDcolObjects2.length = 0;
gdjs.engine2Code.GDcolObjects3.length = 0;
gdjs.engine2Code.GDcolObjects4.length = 0;
gdjs.engine2Code.GDcolObjects5.length = 0;
gdjs.engine2Code.GDcolObjects6.length = 0;
gdjs.engine2Code.GDcolObjects7.length = 0;
gdjs.engine2Code.GDcolObjects8.length = 0;
gdjs.engine2Code.GDcObjects1.length = 0;
gdjs.engine2Code.GDcObjects2.length = 0;
gdjs.engine2Code.GDcObjects3.length = 0;
gdjs.engine2Code.GDcObjects4.length = 0;
gdjs.engine2Code.GDcObjects5.length = 0;
gdjs.engine2Code.GDcObjects6.length = 0;
gdjs.engine2Code.GDcObjects7.length = 0;
gdjs.engine2Code.GDcObjects8.length = 0;
gdjs.engine2Code.GDaObjects1.length = 0;
gdjs.engine2Code.GDaObjects2.length = 0;
gdjs.engine2Code.GDaObjects3.length = 0;
gdjs.engine2Code.GDaObjects4.length = 0;
gdjs.engine2Code.GDaObjects5.length = 0;
gdjs.engine2Code.GDaObjects6.length = 0;
gdjs.engine2Code.GDaObjects7.length = 0;
gdjs.engine2Code.GDaObjects8.length = 0;
gdjs.engine2Code.GDcol2Objects1.length = 0;
gdjs.engine2Code.GDcol2Objects2.length = 0;
gdjs.engine2Code.GDcol2Objects3.length = 0;
gdjs.engine2Code.GDcol2Objects4.length = 0;
gdjs.engine2Code.GDcol2Objects5.length = 0;
gdjs.engine2Code.GDcol2Objects6.length = 0;
gdjs.engine2Code.GDcol2Objects7.length = 0;
gdjs.engine2Code.GDcol2Objects8.length = 0;
gdjs.engine2Code.GDselectorObjects1.length = 0;
gdjs.engine2Code.GDselectorObjects2.length = 0;
gdjs.engine2Code.GDselectorObjects3.length = 0;
gdjs.engine2Code.GDselectorObjects4.length = 0;
gdjs.engine2Code.GDselectorObjects5.length = 0;
gdjs.engine2Code.GDselectorObjects6.length = 0;
gdjs.engine2Code.GDselectorObjects7.length = 0;
gdjs.engine2Code.GDselectorObjects8.length = 0;
gdjs.engine2Code.GDmoverObjects1.length = 0;
gdjs.engine2Code.GDmoverObjects2.length = 0;
gdjs.engine2Code.GDmoverObjects3.length = 0;
gdjs.engine2Code.GDmoverObjects4.length = 0;
gdjs.engine2Code.GDmoverObjects5.length = 0;
gdjs.engine2Code.GDmoverObjects6.length = 0;
gdjs.engine2Code.GDmoverObjects7.length = 0;
gdjs.engine2Code.GDmoverObjects8.length = 0;


return;

}

gdjs['engine2Code'] = gdjs.engine2Code;
