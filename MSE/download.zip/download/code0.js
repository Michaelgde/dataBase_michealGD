gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.GDfloorObjects1= [];
gdjs.Untitled_32sceneCode.GDfloorObjects2= [];
gdjs.Untitled_32sceneCode.GDplankObjects1= [];
gdjs.Untitled_32sceneCode.GDplankObjects2= [];
gdjs.Untitled_32sceneCode.GDcamObjects1= [];
gdjs.Untitled_32sceneCode.GDcamObjects2= [];


gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("cam"), gdjs.Untitled_32sceneCode.GDcamObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Untitled_32sceneCode.GDcamObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDcamObjects1[0].getX()), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.Untitled_32sceneCode.GDcamObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDcamObjects1[0].getY()), "", 0);
}{gdjs.scene3d.camera.setCameraZ(runtimeScene, (( gdjs.Untitled_32sceneCode.GDcamObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDcamObjects1[0].getBehavior("Object3D").getZ()), "", 0);
}{gdjs.scene3d.camera.setCameraRotationX(runtimeScene, (( gdjs.Untitled_32sceneCode.GDcamObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDcamObjects1[0].getBehavior("Object3D").getRotationX()) + 90, "", 0);
}{gdjs.scene3d.camera.setCameraRotationY(runtimeScene, (( gdjs.Untitled_32sceneCode.GDcamObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDcamObjects1[0].getBehavior("Object3D").getRotationY()), "", 0);
}{gdjs.evtTools.camera.setCameraRotation(runtimeScene, (( gdjs.Untitled_32sceneCode.GDcamObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDcamObjects1[0].getAngle()) + 90, "", 0);
}}

}


};gdjs.Untitled_32sceneCode.eventsList1 = function(runtimeScene) {

{


gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);
}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDfloorObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDfloorObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDplankObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDplankObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDcamObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDcamObjects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList1(runtimeScene);
gdjs.Untitled_32sceneCode.GDfloorObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDfloorObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDplankObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDplankObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDcamObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDcamObjects2.length = 0;


return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
