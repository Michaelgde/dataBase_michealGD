gdjs.Untitled_32scene2Code = {};
gdjs.Untitled_32scene2Code.localVariables = [];
gdjs.Untitled_32scene2Code.GDmanObjects1= [];
gdjs.Untitled_32scene2Code.GDmanObjects2= [];


gdjs.Untitled_32scene2Code.userFunc0xbc44c8 = function GDJSInlineCode(runtimeScene) {
"use strict";
//runtimeScene.registerObject({
//    name: "obj",
//    type: "Sprite",
//    x: 100,
//    y: 100,
//    image: "mySprite.png"
//});

//runtimeScene.getObjects('man')[0].name = 'obj'
//runtimeScene.getObjects('man')[0].persistentUuid = runtimeScene.createNewUniqueId()
//runtimeScene.addObject(runtimeScene.getObjects('man')[0])
//runtimeScene.getObjects('man')[0].deleteFromScene()
//console.log(runtimeScene.getObjects("man"))
//runtimeScene.createObject('obj')
console.log(runtimeScene._objects)
runtimeScene.getVariables().get('objf').fromJSON(JSON.stringify(runtimeScene.getVariables().get('jj').getAsString()))
runtimeScene.registerObject({"adaptCollisionMaskAutomatically":true,"assetStoreId":"","name":"lad","type":"Sprite","updateIfNotVisible":false,"variables":[],"effects":[],"behaviors":[{"name":"Animation","type":"AnimatableCapability::AnimatableBehavior"},{"name":"Effect","type":"EffectCapability::EffectBehavior"},{"name":"Flippable","type":"FlippableCapability::FlippableBehavior"},{"name":"Opacity","type":"OpacityCapability::OpacityBehavior"},{"name":"Resizable","type":"ResizableCapability::ResizableBehavior"},{"name":"Scale","type":"ScalableCapability::ScalableBehavior"}],"animations":[{"name":"djd","useMultipleDirections":false,"directions":[{"looping":false,"metadata":"{\"pskl\":{}}","timeBetweenFrames":0.08,"sprites":[{"hasCustomCollisionMask":true,"image":"djd","points":[],"originPoint":{"name":"origine","x":0,"y":0},"centerPoint":{"automatic":true,"name":"centre","x":0,"y":0},"customCollisionMask":[[{"x":0,"y":0},{"x":64,"y":0},{"x":64,"y":64},{"x":0,"y":64}]]}]}]}]})
//runtimeScene.addObject()
console.log(runtimeScene.getGame()._resourcesLoader)
runtimeScene.createObject('lad')

};
gdjs.Untitled_32scene2Code.eventsList0 = function(runtimeScene) {

{


gdjs.Untitled_32scene2Code.userFunc0xbc44c8(runtimeScene);

}


};gdjs.Untitled_32scene2Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10319044);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32scene2Code.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
if (isConditionTrue_0) {
{gdjs.evtsExt__UploadDownloadTextFile__DownloadTextFile.func(runtimeScene, "json", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().get("objf")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};

gdjs.Untitled_32scene2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32scene2Code.GDmanObjects1.length = 0;
gdjs.Untitled_32scene2Code.GDmanObjects2.length = 0;

gdjs.Untitled_32scene2Code.eventsList1(runtimeScene);
gdjs.Untitled_32scene2Code.GDmanObjects1.length = 0;
gdjs.Untitled_32scene2Code.GDmanObjects2.length = 0;


return;

}

gdjs['Untitled_32scene2Code'] = gdjs.Untitled_32scene2Code;
