gdjs.mainCode = {};
gdjs.mainCode.localVariables = [];
gdjs.mainCode.GDplayerObjects1= [];
gdjs.mainCode.GDplayerObjects2= [];
gdjs.mainCode.GDgrass_9595blockObjects1= [];
gdjs.mainCode.GDgrass_9595blockObjects2= [];
gdjs.mainCode.GDdirtObjects1= [];
gdjs.mainCode.GDdirtObjects2= [];


gdjs.mainCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.mainCode.GDplayerObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.mainCode.GDplayerObjects1.length !== 0 ? gdjs.mainCode.GDplayerObjects1[0] : null), true, "", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}}

}


};

gdjs.mainCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.mainCode.GDplayerObjects1.length = 0;
gdjs.mainCode.GDplayerObjects2.length = 0;
gdjs.mainCode.GDgrass_9595blockObjects1.length = 0;
gdjs.mainCode.GDgrass_9595blockObjects2.length = 0;
gdjs.mainCode.GDdirtObjects1.length = 0;
gdjs.mainCode.GDdirtObjects2.length = 0;

gdjs.mainCode.eventsList0(runtimeScene);
gdjs.mainCode.GDplayerObjects1.length = 0;
gdjs.mainCode.GDplayerObjects2.length = 0;
gdjs.mainCode.GDgrass_9595blockObjects1.length = 0;
gdjs.mainCode.GDgrass_9595blockObjects2.length = 0;
gdjs.mainCode.GDdirtObjects1.length = 0;
gdjs.mainCode.GDdirtObjects2.length = 0;


return;

}

gdjs['mainCode'] = gdjs.mainCode;
