gdjs.raceCode = {};
gdjs.raceCode.localVariables = [];
gdjs.raceCode.GDboat1Objects1= [];
gdjs.raceCode.GDboat1Objects2= [];
gdjs.raceCode.GDwaterObjects1= [];
gdjs.raceCode.GDwaterObjects2= [];
gdjs.raceCode.GDwater_9595particlesObjects1= [];
gdjs.raceCode.GDwater_9595particlesObjects2= [];


gdjs.raceCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.raceCode.GDwaterObjects1 */
{gdjs.evtTools.tween.tweenCameraZoom2(runtimeScene, "zoom camera to boat", 3, "", "easeInQuad", 1);
}{for(var i = 0, len = gdjs.raceCode.GDwaterObjects1.length ;i < len;++i) {
    gdjs.raceCode.GDwaterObjects1[i].getBehavior("Opacity").setOpacity(150);
}
}}

}


};gdjs.raceCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.raceCode.GDwaterObjects1);
{for(var i = 0, len = gdjs.raceCode.GDwaterObjects1.length ;i < len;++i) {
    gdjs.raceCode.GDwaterObjects1[i].getBehavior("Resizable").setSize(1000000, 1000000);
}
}
{ //Subevents
gdjs.raceCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("boat1"), gdjs.raceCode.GDboat1Objects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.raceCode.GDboat1Objects1.length !== 0 ? gdjs.raceCode.GDboat1Objects1[0] : null), true, "", 0);
}{gdjs.evtTools.camera.setCameraRotation(runtimeScene, (( gdjs.raceCode.GDboat1Objects1.length === 0 ) ? 0 :gdjs.raceCode.GDboat1Objects1[0].getAngle()), "", 0);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("boat1"), gdjs.raceCode.GDboat1Objects1);
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.raceCode.GDwaterObjects1);
gdjs.copyArray(runtimeScene.getObjects("water_particles"), gdjs.raceCode.GDwater_9595particlesObjects1);
{for(var i = 0, len = gdjs.raceCode.GDboat1Objects1.length ;i < len;++i) {
    gdjs.raceCode.GDboat1Objects1[i].addPolarForce((gdjs.raceCode.GDboat1Objects1[i].getAngle()) - 90, 100, 0);
}
}{for(var i = 0, len = gdjs.raceCode.GDwater_9595particlesObjects1.length ;i < len;++i) {
    gdjs.raceCode.GDwater_9595particlesObjects1[i].setAngle((( gdjs.raceCode.GDboat1Objects1.length === 0 ) ? 0 :gdjs.raceCode.GDboat1Objects1[0].getAngle()) + 90);
}
}{for(var i = 0, len = gdjs.raceCode.GDwater_9595particlesObjects1.length ;i < len;++i) {
    gdjs.raceCode.GDwater_9595particlesObjects1[i].setPosition((( gdjs.raceCode.GDboat1Objects1.length === 0 ) ? 0 :gdjs.raceCode.GDboat1Objects1[0].getCenterXInScene()),(( gdjs.raceCode.GDboat1Objects1.length === 0 ) ? 0 :gdjs.raceCode.GDboat1Objects1[0].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.raceCode.GDwaterObjects1.length ;i < len;++i) {
    gdjs.raceCode.GDwaterObjects1[i].setXOffset(gdjs.raceCode.GDwaterObjects1[i].getXOffset() + (0.08));
}
}{for(var i = 0, len = gdjs.raceCode.GDwaterObjects1.length ;i < len;++i) {
    gdjs.raceCode.GDwaterObjects1[i].setYOffset(gdjs.raceCode.GDwaterObjects1[i].getYOffset() - (0.1));
}
}{for(var i = 0, len = gdjs.raceCode.GDboat1Objects1.length ;i < len;++i) {
    gdjs.raceCode.GDboat1Objects1[i].setPosition(gdjs.evtTools.common.clamp((gdjs.raceCode.GDboat1Objects1[i].getPointX("")), 0, 100000),gdjs.evtTools.common.clamp((gdjs.raceCode.GDboat1Objects1[i].getPointY("")), 0, 100000));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("boat1"), gdjs.raceCode.GDboat1Objects1);
{for(var i = 0, len = gdjs.raceCode.GDboat1Objects1.length ;i < len;++i) {
    gdjs.raceCode.GDboat1Objects1[i].setAngle(gdjs.raceCode.GDboat1Objects1[i].getAngle() - (2));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("boat1"), gdjs.raceCode.GDboat1Objects1);
{for(var i = 0, len = gdjs.raceCode.GDboat1Objects1.length ;i < len;++i) {
    gdjs.raceCode.GDboat1Objects1[i].setAngle(gdjs.raceCode.GDboat1Objects1[i].getAngle() + (2));
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.raceCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.raceCode.GDboat1Objects1.length = 0;
gdjs.raceCode.GDboat1Objects2.length = 0;
gdjs.raceCode.GDwaterObjects1.length = 0;
gdjs.raceCode.GDwaterObjects2.length = 0;
gdjs.raceCode.GDwater_9595particlesObjects1.length = 0;
gdjs.raceCode.GDwater_9595particlesObjects2.length = 0;

gdjs.raceCode.eventsList1(runtimeScene);
gdjs.raceCode.GDboat1Objects1.length = 0;
gdjs.raceCode.GDboat1Objects2.length = 0;
gdjs.raceCode.GDwaterObjects1.length = 0;
gdjs.raceCode.GDwaterObjects2.length = 0;
gdjs.raceCode.GDwater_9595particlesObjects1.length = 0;
gdjs.raceCode.GDwater_9595particlesObjects2.length = 0;


return;

}

gdjs['raceCode'] = gdjs.raceCode;
