gdjs.errorCode = {};
gdjs.errorCode.localVariables = [];
gdjs.errorCode.GDNewPanelSpriteObjects1= [];
gdjs.errorCode.GDNewPanelSpriteObjects2= [];
gdjs.errorCode.GDNewTextObjects1= [];
gdjs.errorCode.GDNewTextObjects2= [];
gdjs.errorCode.GDbackObjects1= [];
gdjs.errorCode.GDbackObjects2= [];


gdjs.errorCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.errorCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.errorCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.errorCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.errorCode.GDNewTextObjects1.length = 0;
gdjs.errorCode.GDNewTextObjects2.length = 0;
gdjs.errorCode.GDbackObjects1.length = 0;
gdjs.errorCode.GDbackObjects2.length = 0;

gdjs.errorCode.eventsList0(runtimeScene);
gdjs.errorCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.errorCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.errorCode.GDNewTextObjects1.length = 0;
gdjs.errorCode.GDNewTextObjects2.length = 0;
gdjs.errorCode.GDbackObjects1.length = 0;
gdjs.errorCode.GDbackObjects2.length = 0;


return;

}

gdjs['errorCode'] = gdjs.errorCode;
