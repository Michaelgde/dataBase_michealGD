gdjs.rogueCode = {};
gdjs.rogueCode.localVariables = [];
gdjs.rogueCode.GDdiverObjects1_1final = [];

gdjs.rogueCode.GDplayer1Objects1_1final = [];

gdjs.rogueCode.GDshootObjects1_1final = [];

gdjs.rogueCode.GDshootObjects2_2final = [];

gdjs.rogueCode.GDwater_9595particlees2Objects1_1final = [];

gdjs.rogueCode.GDwater_9595particleesObjects1_1final = [];

gdjs.rogueCode.GDwaveObjects1_1final = [];

gdjs.rogueCode.GDplayer1Objects1= [];
gdjs.rogueCode.GDplayer1Objects2= [];
gdjs.rogueCode.GDplayer1Objects3= [];
gdjs.rogueCode.GDpillarObjects1= [];
gdjs.rogueCode.GDpillarObjects2= [];
gdjs.rogueCode.GDpillarObjects3= [];
gdjs.rogueCode.GDcement_9595block_9595blueObjects1= [];
gdjs.rogueCode.GDcement_9595block_9595blueObjects2= [];
gdjs.rogueCode.GDcement_9595block_9595blueObjects3= [];
gdjs.rogueCode.GDclonObjects1= [];
gdjs.rogueCode.GDclonObjects2= [];
gdjs.rogueCode.GDclonObjects3= [];
gdjs.rogueCode.GDsmasherObjects1= [];
gdjs.rogueCode.GDsmasherObjects2= [];
gdjs.rogueCode.GDsmasherObjects3= [];
gdjs.rogueCode.GDcement_9595block_9595blue2Objects1= [];
gdjs.rogueCode.GDcement_9595block_9595blue2Objects2= [];
gdjs.rogueCode.GDcement_9595block_9595blue2Objects3= [];
gdjs.rogueCode.GDdoorObjects1= [];
gdjs.rogueCode.GDdoorObjects2= [];
gdjs.rogueCode.GDdoorObjects3= [];
gdjs.rogueCode.GDrifleObjects1= [];
gdjs.rogueCode.GDrifleObjects2= [];
gdjs.rogueCode.GDrifleObjects3= [];
gdjs.rogueCode.GDhit_9595boxObjects1= [];
gdjs.rogueCode.GDhit_9595boxObjects2= [];
gdjs.rogueCode.GDhit_9595boxObjects3= [];
gdjs.rogueCode.GDbulletObjects1= [];
gdjs.rogueCode.GDbulletObjects2= [];
gdjs.rogueCode.GDbulletObjects3= [];
gdjs.rogueCode.GDreloadObjects1= [];
gdjs.rogueCode.GDreloadObjects2= [];
gdjs.rogueCode.GDreloadObjects3= [];
gdjs.rogueCode.GDreload2Objects1= [];
gdjs.rogueCode.GDreload2Objects2= [];
gdjs.rogueCode.GDreload2Objects3= [];
gdjs.rogueCode.GDwaterObjects1= [];
gdjs.rogueCode.GDwaterObjects2= [];
gdjs.rogueCode.GDwaterObjects3= [];
gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1= [];
gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects2= [];
gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects3= [];
gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects1= [];
gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects2= [];
gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects3= [];
gdjs.rogueCode.GDwater_9595particleesObjects1= [];
gdjs.rogueCode.GDwater_9595particleesObjects2= [];
gdjs.rogueCode.GDwater_9595particleesObjects3= [];
gdjs.rogueCode.GDwater_9595particlees2Objects1= [];
gdjs.rogueCode.GDwater_9595particlees2Objects2= [];
gdjs.rogueCode.GDwater_9595particlees2Objects3= [];
gdjs.rogueCode.GDlifeObjects1= [];
gdjs.rogueCode.GDlifeObjects2= [];
gdjs.rogueCode.GDlifeObjects3= [];
gdjs.rogueCode.GDbackgroundObjects1= [];
gdjs.rogueCode.GDbackgroundObjects2= [];
gdjs.rogueCode.GDbackgroundObjects3= [];
gdjs.rogueCode.GDwin_9595failObjects1= [];
gdjs.rogueCode.GDwin_9595failObjects2= [];
gdjs.rogueCode.GDwin_9595failObjects3= [];
gdjs.rogueCode.GDstateObjects1= [];
gdjs.rogueCode.GDstateObjects2= [];
gdjs.rogueCode.GDstateObjects3= [];
gdjs.rogueCode.GDlineObjects1= [];
gdjs.rogueCode.GDlineObjects2= [];
gdjs.rogueCode.GDlineObjects3= [];
gdjs.rogueCode.GDsensorObjects1= [];
gdjs.rogueCode.GDsensorObjects2= [];
gdjs.rogueCode.GDsensorObjects3= [];
gdjs.rogueCode.GDblockerObjects1= [];
gdjs.rogueCode.GDblockerObjects2= [];
gdjs.rogueCode.GDblockerObjects3= [];
gdjs.rogueCode.GDsensor2Objects1= [];
gdjs.rogueCode.GDsensor2Objects2= [];
gdjs.rogueCode.GDsensor2Objects3= [];
gdjs.rogueCode.GDsmasher_9595aObjects1= [];
gdjs.rogueCode.GDsmasher_9595aObjects2= [];
gdjs.rogueCode.GDsmasher_9595aObjects3= [];
gdjs.rogueCode.GDblast_9595botObjects1= [];
gdjs.rogueCode.GDblast_9595botObjects2= [];
gdjs.rogueCode.GDblast_9595botObjects3= [];
gdjs.rogueCode.GDwaveObjects1= [];
gdjs.rogueCode.GDwaveObjects2= [];
gdjs.rogueCode.GDwaveObjects3= [];
gdjs.rogueCode.GDdiverObjects1= [];
gdjs.rogueCode.GDdiverObjects2= [];
gdjs.rogueCode.GDdiverObjects3= [];
gdjs.rogueCode.GDlevelObjects1= [];
gdjs.rogueCode.GDlevelObjects2= [];
gdjs.rogueCode.GDlevelObjects3= [];
gdjs.rogueCode.GDbossObjects1= [];
gdjs.rogueCode.GDbossObjects2= [];
gdjs.rogueCode.GDbossObjects3= [];
gdjs.rogueCode.GDbackObjects1= [];
gdjs.rogueCode.GDbackObjects2= [];
gdjs.rogueCode.GDbackObjects3= [];
gdjs.rogueCode.GDShadedDarkJoystickObjects1= [];
gdjs.rogueCode.GDShadedDarkJoystickObjects2= [];
gdjs.rogueCode.GDShadedDarkJoystickObjects3= [];
gdjs.rogueCode.GDshootObjects1= [];
gdjs.rogueCode.GDshootObjects2= [];
gdjs.rogueCode.GDshootObjects3= [];


gdjs.rogueCode.mapOfEmptyGDplayer1Objects = Hashtable.newFrom({"player1": []});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsmasherObjects1Objects = Hashtable.newFrom({"smasher": gdjs.rogueCode.GDsmasherObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.rogueCode.GDbulletObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDclonObjects1Objects = Hashtable.newFrom({"clon": gdjs.rogueCode.GDclonObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.rogueCode.GDbulletObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.rogueCode.GDplayer1Objects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDhit_95959595boxObjects1Objects = Hashtable.newFrom({"hit_box": gdjs.rogueCode.GDhit_9595boxObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDhit_95959595boxObjects1Objects = Hashtable.newFrom({"hit_box": gdjs.rogueCode.GDhit_9595boxObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDblockerObjects1Objects = Hashtable.newFrom({"blocker": gdjs.rogueCode.GDblockerObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsmasherObjects1ObjectsGDgdjs_9546rogueCode_9546GDclonObjects1ObjectsGDgdjs_9546rogueCode_9546GDblast_95959595botObjects1ObjectsGDgdjs_9546rogueCode_9546GDdiverObjects1ObjectsGDgdjs_9546rogueCode_9546GDbossObjects1Objects = Hashtable.newFrom({"smasher": gdjs.rogueCode.GDsmasherObjects1, "clon": gdjs.rogueCode.GDclonObjects1, "blast_bot": gdjs.rogueCode.GDblast_9595botObjects1, "diver": gdjs.rogueCode.GDdiverObjects1, "boss": gdjs.rogueCode.GDbossObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.rogueCode.GDsensorObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.rogueCode.GDsensorObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.rogueCode.GDsensorObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.rogueCode.GDsensorObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.rogueCode.GDsensorObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.rogueCode.GDsensorObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects = Hashtable.newFrom({"cement_block_blue_side": gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects = Hashtable.newFrom({"cement_block_blue_side": gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects = Hashtable.newFrom({"cement_block_blue_side": gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects = Hashtable.newFrom({"cement_block_blue_side": gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects = Hashtable.newFrom({"cement_block_blue_side": gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwater_95959595particlees2Objects1Objects = Hashtable.newFrom({"water_particlees2": gdjs.rogueCode.GDwater_9595particlees2Objects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwater_95959595particlees2Objects1Objects = Hashtable.newFrom({"water_particlees2": gdjs.rogueCode.GDwater_9595particlees2Objects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwater_95959595particlees2Objects1Objects = Hashtable.newFrom({"water_particlees2": gdjs.rogueCode.GDwater_9595particlees2Objects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwater_95959595particlees2Objects1Objects = Hashtable.newFrom({"water_particlees2": gdjs.rogueCode.GDwater_9595particlees2Objects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwater_95959595particlees2Objects1Objects = Hashtable.newFrom({"water_particlees2": gdjs.rogueCode.GDwater_9595particlees2Objects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.rogueCode.GDbulletObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.rogueCode.GDbulletObjects1});
gdjs.rogueCode.mapOfEmptyGDrifleObjects = Hashtable.newFrom({"rifle": []});
gdjs.rogueCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level")) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level")) < 11;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue"), gdjs.rogueCode.GDcement_9595block_9595blueObjects2);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue2"), gdjs.rogueCode.GDcement_9595block_9595blue2Objects2);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue_side"), gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects2);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue_side2"), gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects2);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogueCode.GDclonObjects2);
gdjs.copyArray(runtimeScene.getObjects("door"), gdjs.rogueCode.GDdoorObjects2);
gdjs.copyArray(gdjs.rogueCode.GDhit_9595boxObjects1, gdjs.rogueCode.GDhit_9595boxObjects2);

gdjs.copyArray(runtimeScene.getObjects("pillar"), gdjs.rogueCode.GDpillarObjects2);
gdjs.copyArray(gdjs.rogueCode.GDplayer1Objects1, gdjs.rogueCode.GDplayer1Objects2);

gdjs.copyArray(gdjs.rogueCode.GDrifleObjects1, gdjs.rogueCode.GDrifleObjects2);

gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogueCode.GDsmasherObjects2);
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.rogueCode.GDwaterObjects2);
gdjs.copyArray(runtimeScene.getObjects("water_particlees"), gdjs.rogueCode.GDwater_9595particleesObjects2);
gdjs.copyArray(runtimeScene.getObjects("water_particlees2"), gdjs.rogueCode.GDwater_9595particlees2Objects2);
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDpillarObjects2.length ;i < len;++i) {
    gdjs.rogueCode.GDpillarObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDcement_9595block_9595blueObjects2.length ;i < len;++i) {
    gdjs.rogueCode.GDcement_9595block_9595blueObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDclonObjects2.length ;i < len;++i) {
    gdjs.rogueCode.GDclonObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDcement_9595block_9595blue2Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDcement_9595block_9595blue2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDsmasherObjects2.length ;i < len;++i) {
    gdjs.rogueCode.GDsmasherObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDdoorObjects2.length ;i < len;++i) {
    gdjs.rogueCode.GDdoorObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDrifleObjects2.length ;i < len;++i) {
    gdjs.rogueCode.GDrifleObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDhit_9595boxObjects2.length ;i < len;++i) {
    gdjs.rogueCode.GDhit_9595boxObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDwaterObjects2.length ;i < len;++i) {
    gdjs.rogueCode.GDwaterObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects2.length ;i < len;++i) {
    gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDwater_9595particleesObjects2.length ;i < len;++i) {
    gdjs.rogueCode.GDwater_9595particleesObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDwater_9595particlees2Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDwater_9595particlees2Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").getAsString(), 0, 0, 10);
}{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects2[i].setZOrder(200);
}
}{for(var i = 0, len = gdjs.rogueCode.GDrifleObjects2.length ;i < len;++i) {
    gdjs.rogueCode.GDrifleObjects2[i].setZOrder(201);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level")) > 10;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.rogueCode.GDplayer1Objects1, gdjs.rogueCode.GDplayer1Objects2);

gdjs.copyArray(gdjs.rogueCode.GDrifleObjects1, gdjs.rogueCode.GDrifleObjects2);

{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects2[i].setZOrder(200);
}
}{for(var i = 0, len = gdjs.rogueCode.GDrifleObjects2.length ;i < len;++i) {
    gdjs.rogueCode.GDrifleObjects2[i].setZOrder(201);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").setNumber(0);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.rogueCode.GDplayer1Objects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwaterObjects1Objects = Hashtable.newFrom({"water": gdjs.rogueCode.GDwaterObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.rogueCode.GDplayer1Objects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDcement_95959595block_95959595blueObjects1Objects = Hashtable.newFrom({"cement_block_blue": gdjs.rogueCode.GDcement_9595block_9595blueObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.rogueCode.GDplayer1Objects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsmasherObjects1ObjectsGDgdjs_9546rogueCode_9546GDclonObjects1ObjectsGDgdjs_9546rogueCode_9546GDblast_95959595botObjects1ObjectsGDgdjs_9546rogueCode_9546GDdiverObjects1ObjectsGDgdjs_9546rogueCode_9546GDbossObjects1Objects = Hashtable.newFrom({"smasher": gdjs.rogueCode.GDsmasherObjects1, "clon": gdjs.rogueCode.GDclonObjects1, "blast_bot": gdjs.rogueCode.GDblast_9595botObjects1, "diver": gdjs.rogueCode.GDdiverObjects1, "boss": gdjs.rogueCode.GDbossObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.rogueCode.GDplayer1Objects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDblockerObjects1Objects = Hashtable.newFrom({"blocker": gdjs.rogueCode.GDblockerObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsensor2Objects1Objects = Hashtable.newFrom({"sensor2": gdjs.rogueCode.GDsensor2Objects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDblockerObjects1Objects = Hashtable.newFrom({"blocker": gdjs.rogueCode.GDblockerObjects1});
gdjs.rogueCode.mapOfEmptyGDplayer1Objects = Hashtable.newFrom({"player1": []});
gdjs.rogueCode.mapOfEmptyGDsmasherObjectsEmptyGDclonObjectsEmptyGDblast_9595botObjectsEmptyGDdiverObjectsEmptyGDbossObjects = Hashtable.newFrom({"smasher": [], "clon": [], "blast_bot": [], "diver": [], "boss": []});
gdjs.rogueCode.mapOfEmptyGDsmasherObjectsEmptyGDclonObjectsEmptyGDblast_9595botObjectsEmptyGDdiverObjectsEmptyGDbossObjects = Hashtable.newFrom({"smasher": [], "clon": [], "blast_bot": [], "diver": [], "boss": []});
gdjs.rogueCode.mapOfEmptyGDbossObjects = Hashtable.newFrom({"boss": []});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDclonObjects1Objects = Hashtable.newFrom({"clon": gdjs.rogueCode.GDclonObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDclonObjects1Objects = Hashtable.newFrom({"clon": gdjs.rogueCode.GDclonObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDclonObjects1Objects = Hashtable.newFrom({"clon": gdjs.rogueCode.GDclonObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsmasherObjects1Objects = Hashtable.newFrom({"smasher": gdjs.rogueCode.GDsmasherObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDdiverObjects1Objects = Hashtable.newFrom({"diver": gdjs.rogueCode.GDdiverObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwaveObjects2Objects = Hashtable.newFrom({"wave": gdjs.rogueCode.GDwaveObjects2});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwater_95959595particlees2Objects2Objects = Hashtable.newFrom({"water_particlees2": gdjs.rogueCode.GDwater_9595particlees2Objects2});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwaveObjects2Objects = Hashtable.newFrom({"wave": gdjs.rogueCode.GDwaveObjects2});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwater_95959595particleesObjects2Objects = Hashtable.newFrom({"water_particlees": gdjs.rogueCode.GDwater_9595particleesObjects2});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwaveObjects2Objects = Hashtable.newFrom({"wave": gdjs.rogueCode.GDwaveObjects2});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects2Objects = Hashtable.newFrom({"player1": gdjs.rogueCode.GDplayer1Objects2});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwaveObjects1Objects = Hashtable.newFrom({"wave": gdjs.rogueCode.GDwaveObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.rogueCode.GDbulletObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDblast_95959595botObjects1Objects = Hashtable.newFrom({"blast_bot": gdjs.rogueCode.GDblast_9595botObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.rogueCode.GDbulletObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDdiverObjects1Objects = Hashtable.newFrom({"diver": gdjs.rogueCode.GDdiverObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.rogueCode.GDbulletObjects1});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbossObjects1Objects = Hashtable.newFrom({"boss": gdjs.rogueCode.GDbossObjects1});
gdjs.rogueCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogueCode.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.rogueCode.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("Up", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDShadedDarkJoystickObjects2[k] = gdjs.rogueCode.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.rogueCode.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects2);
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogueCode.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.rogueCode.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("Down", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDShadedDarkJoystickObjects2[k] = gdjs.rogueCode.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.rogueCode.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects2);
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogueCode.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.rogueCode.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDShadedDarkJoystickObjects2[k] = gdjs.rogueCode.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.rogueCode.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects2);
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogueCode.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.rogueCode.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDShadedDarkJoystickObjects2[k] = gdjs.rogueCode.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.rogueCode.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects2);
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogueCode.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.rogueCode.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("UpLeft", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDShadedDarkJoystickObjects2[k] = gdjs.rogueCode.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.rogueCode.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects2);
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogueCode.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.rogueCode.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("UpRight", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDShadedDarkJoystickObjects2[k] = gdjs.rogueCode.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.rogueCode.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects2);
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogueCode.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.rogueCode.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("DownLeft", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDShadedDarkJoystickObjects2[k] = gdjs.rogueCode.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.rogueCode.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects2);
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogueCode.GDShadedDarkJoystickObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDShadedDarkJoystickObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDShadedDarkJoystickObjects1[i].IsDirectionPushed8Way("DownRight", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDShadedDarkJoystickObjects1[k] = gdjs.rogueCode.GDShadedDarkJoystickObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDShadedDarkJoystickObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


};gdjs.rogueCode.mapOfEmptyGDplayer1Objects = Hashtable.newFrom({"player1": []});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwaveObjects2Objects = Hashtable.newFrom({"wave": gdjs.rogueCode.GDwaveObjects2});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects2Objects = Hashtable.newFrom({"player1": gdjs.rogueCode.GDplayer1Objects2});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDdiverObjects2Objects = Hashtable.newFrom({"diver": gdjs.rogueCode.GDdiverObjects2});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects2Objects = Hashtable.newFrom({"player1": gdjs.rogueCode.GDplayer1Objects2});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDstateObjects2Objects = Hashtable.newFrom({"state": gdjs.rogueCode.GDstateObjects2});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbackObjects2Objects = Hashtable.newFrom({"back": gdjs.rogueCode.GDbackObjects2});
gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDstateObjects2Objects = Hashtable.newFrom({"state": gdjs.rogueCode.GDstateObjects2});
gdjs.rogueCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.rogueCode.GDstateObjects2);
gdjs.copyArray(runtimeScene.getObjects("win_fail"), gdjs.rogueCode.GDwin_9595failObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDwin_9595failObjects2.length;i<l;++i) {
    if ( gdjs.rogueCode.GDwin_9595failObjects2[i].getBehavior("Text").getText() == "you win" ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDwin_9595failObjects2[k] = gdjs.rogueCode.GDwin_9595failObjects2[i];
        ++k;
    }
}
gdjs.rogueCode.GDwin_9595failObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDstateObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").add(1);
}{gdjs.evtTools.storage.writeNumberInJSONFile("sc", "sc", runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").getAsNumber());
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "rogue", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.rogueCode.GDbackObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbackObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeNumberInJSONFile("sc", "sc", runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").getAsNumber());
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level select", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.rogueCode.GDstateObjects2);
gdjs.copyArray(runtimeScene.getObjects("win_fail"), gdjs.rogueCode.GDwin_9595failObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDwin_9595failObjects2.length;i<l;++i) {
    if ( gdjs.rogueCode.GDwin_9595failObjects2[i].getBehavior("Text").getText() == "you fail" ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDwin_9595failObjects2[k] = gdjs.rogueCode.GDwin_9595failObjects2[i];
        ++k;
    }
}
gdjs.rogueCode.GDwin_9595failObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDstateObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "rogue", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("win_fail"), gdjs.rogueCode.GDwin_9595failObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDwin_9595failObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDwin_9595failObjects1[i].getBehavior("Text").getText() == "you fail" ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDwin_9595failObjects1[k] = gdjs.rogueCode.GDwin_9595failObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDwin_9595failObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.rogueCode.GDstateObjects1);
{for(var i = 0, len = gdjs.rogueCode.GDstateObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDstateObjects1[i].getBehavior("Text").setText("restart");
}
}}

}


};gdjs.rogueCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("touch"), false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogueCode.GDrifleObjects1);
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.rogueCode.GDshootObjects1);
{for(var i = 0, len = gdjs.rogueCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDrifleObjects1[i].rotateTowardAngle((( gdjs.rogueCode.GDshootObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDshootObjects1[0].StickAngle((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), 0, runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("touch"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogueCode.GDrifleObjects1);
{for(var i = 0, len = gdjs.rogueCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDrifleObjects1[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogueCode.mapOfEmptyGDplayer1Objects) > 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("life"), gdjs.rogueCode.GDlifeObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("reload2"), gdjs.rogueCode.GDreload2Objects1);
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.rogueCode.GDwaterObjects1);
gdjs.copyArray(runtimeScene.getObjects("water_particlees"), gdjs.rogueCode.GDwater_9595particleesObjects1);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "centre on player", (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getCenterXInScene()), (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getCenterYInScene()), "", "linear", 0.1);
}{for(var i = 0, len = gdjs.rogueCode.GDreload2Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDreload2Objects1[i].getBehavior("Resizable").setWidth(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) * 128);
}
}{for(var i = 0, len = gdjs.rogueCode.GDwaterObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDwaterObjects1[i].setXOffset(gdjs.rogueCode.GDwaterObjects1[i].getXOffset() + (0.4));
}
}{for(var i = 0, len = gdjs.rogueCode.GDwater_9595particleesObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDwater_9595particleesObjects1[i].setXOffset(gdjs.rogueCode.GDwater_9595particleesObjects1[i].getXOffset() + (0.4));
}
}{for(var i = 0, len = gdjs.rogueCode.GDlifeObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDlifeObjects1[i].getBehavior("Resizable").setWidth(((gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.rogueCode.GDplayer1Objects1[0].getVariables()).getFromIndex(0).getAsNumber() / 10 * (32));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.rogueCode.GDbulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogueCode.GDsmasherObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsmasherObjects1Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbulletObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDbulletObjects1 */
/* Reuse gdjs.rogueCode.GDsmasherObjects1 */
{for(var i = 0, len = gdjs.rogueCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDsmasherObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.rogueCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.rogueCode.GDbulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogueCode.GDclonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDclonObjects1Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbulletObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDbulletObjects1 */
/* Reuse gdjs.rogueCode.GDclonObjects1 */
{for(var i = 0, len = gdjs.rogueCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDclonObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.rogueCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogueCode.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogueCode.GDsmasherObjects1);
{for(var i = 0, len = gdjs.rogueCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDclonObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getPointX("")), (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.rogueCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDsmasherObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getPointX("")), (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getPointY("")));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) > 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("reload"), gdjs.rogueCode.GDreloadObjects1);
{for(var i = 0, len = gdjs.rogueCode.GDreloadObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDreloadObjects1[i].getBehavior("Text").setText("ready");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) < 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("reload"), gdjs.rogueCode.GDreloadObjects1);
{for(var i = 0, len = gdjs.rogueCode.GDreloadObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDreloadObjects1[i].getBehavior("Text").setText("reloading...");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hit_box"), gdjs.rogueCode.GDhit_9595boxObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects1Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDhit_95959595boxObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDhit_9595boxObjects1 */
/* Reuse gdjs.rogueCode.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDhit_95959595boxObjects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blocker"), gdjs.rogueCode.GDblockerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDblockerObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDblockerObjects1[i].getVariableBoolean(gdjs.rogueCode.GDblockerObjects1[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDblockerObjects1[k] = gdjs.rogueCode.GDblockerObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDblockerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDblockerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDblockerObjects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogueCode.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.rogueCode.GDbossObjects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogueCode.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogueCode.GDdiverObjects1);
gdjs.copyArray(runtimeScene.getObjects("sensor"), gdjs.rogueCode.GDsensorObjects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogueCode.GDsmasherObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsmasherObjects1ObjectsGDgdjs_9546rogueCode_9546GDclonObjects1ObjectsGDgdjs_9546rogueCode_9546GDblast_95959595botObjects1ObjectsGDgdjs_9546rogueCode_9546GDdiverObjects1ObjectsGDgdjs_9546rogueCode_9546GDbossObjects1Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsensorObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDblast_9595botObjects1 */
/* Reuse gdjs.rogueCode.GDbossObjects1 */
/* Reuse gdjs.rogueCode.GDclonObjects1 */
/* Reuse gdjs.rogueCode.GDdiverObjects1 */
/* Reuse gdjs.rogueCode.GDsensorObjects1 */
/* Reuse gdjs.rogueCode.GDsmasherObjects1 */
{for(var i = 0, len = gdjs.rogueCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDsmasherObjects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsensorObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogueCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDclonObjects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsensorObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogueCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDblast_9595botObjects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsensorObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogueCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDdiverObjects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsensorObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogueCode.GDbossObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDbossObjects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsensorObjects1Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogueCode.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.rogueCode.GDbossObjects1);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue_side"), gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogueCode.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogueCode.GDdiverObjects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogueCode.GDsmasherObjects1);
gdjs.copyArray(runtimeScene.getObjects("water_particlees2"), gdjs.rogueCode.GDwater_9595particlees2Objects1);
{for(var i = 0, len = gdjs.rogueCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDsmasherObjects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogueCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDclonObjects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogueCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDblast_9595botObjects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogueCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDdiverObjects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogueCode.GDbossObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDbossObjects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects, false);
}
}{for(var i = 0, len = gdjs.rogueCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDsmasherObjects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwater_95959595particlees2Objects1Objects, false);
}
for(var i = 0, len = gdjs.rogueCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDclonObjects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwater_95959595particlees2Objects1Objects, false);
}
for(var i = 0, len = gdjs.rogueCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDblast_9595botObjects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwater_95959595particlees2Objects1Objects, false);
}
for(var i = 0, len = gdjs.rogueCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDdiverObjects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwater_95959595particlees2Objects1Objects, false);
}
for(var i = 0, len = gdjs.rogueCode.GDbossObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDbossObjects1[i].separateFromObjectsList(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwater_95959595particlees2Objects1Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("level"), gdjs.rogueCode.GDlevelObjects1);
{for(var i = 0, len = gdjs.rogueCode.GDlevelObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDlevelObjects1[i].getBehavior("Text").setText("level: " + runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").getAsString());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) < (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getPointX(""));
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDplayer1Objects1 */
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogueCode.GDrifleObjects1);
{for(var i = 0, len = gdjs.rogueCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDrifleObjects1[i].getBehavior("Flippable").flipY(true);
}
}{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects1[i].getBehavior("Flippable").flipX(true);
}
}{for(var i = 0, len = gdjs.rogueCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDrifleObjects1[i].setPosition((( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getPointX("hand2")) - 8,(( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getPointY("hand2")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) > (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getPointX(""));
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDplayer1Objects1 */
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogueCode.GDrifleObjects1);
{for(var i = 0, len = gdjs.rogueCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDrifleObjects1[i].getBehavior("Flippable").flipY(false);
}
}{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects1[i].getBehavior("Flippable").flipX(false);
}
}{for(var i = 0, len = gdjs.rogueCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDrifleObjects1[i].setPosition((( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getPointX("hand")),(( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getPointY("hand")));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) > 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "fail"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("touch"), true);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogueCode.GDrifleObjects1);
gdjs.rogueCode.GDbulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbulletObjects1Objects, (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getAABBCenterX()), (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getAABBCenterY()), "");
}{for(var i = 0, len = gdjs.rogueCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDbulletObjects1[i].addPolarForce((( gdjs.rogueCode.GDrifleObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDrifleObjects1[0].getAngle()), 1000, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 40, gdjs.randomInRange(0.8, 1.2));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.55, 0.33, 0.50, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.rogueCode.GDshootObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.rogueCode.GDshootObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.rogueCode.GDshootObjects2.length = 0;

{gdjs.rogueCode.GDshootObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.rogueCode.GDshootObjects3);
for (var i = 0, k = 0, l = gdjs.rogueCode.GDshootObjects3.length;i<l;++i) {
    if ( gdjs.rogueCode.GDshootObjects3[i].StickForceX((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) > 0.3 ) {
        isConditionTrue_2 = true;
        gdjs.rogueCode.GDshootObjects3[k] = gdjs.rogueCode.GDshootObjects3[i];
        ++k;
    }
}
gdjs.rogueCode.GDshootObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.rogueCode.GDshootObjects3.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDshootObjects2_2final.indexOf(gdjs.rogueCode.GDshootObjects3[j]) === -1 )
            gdjs.rogueCode.GDshootObjects2_2final.push(gdjs.rogueCode.GDshootObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.rogueCode.GDshootObjects3);
for (var i = 0, k = 0, l = gdjs.rogueCode.GDshootObjects3.length;i<l;++i) {
    if ( gdjs.rogueCode.GDshootObjects3[i].StickForceY((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) > 0.3 ) {
        isConditionTrue_2 = true;
        gdjs.rogueCode.GDshootObjects3[k] = gdjs.rogueCode.GDshootObjects3[i];
        ++k;
    }
}
gdjs.rogueCode.GDshootObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.rogueCode.GDshootObjects3.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDshootObjects2_2final.indexOf(gdjs.rogueCode.GDshootObjects3[j]) === -1 )
            gdjs.rogueCode.GDshootObjects2_2final.push(gdjs.rogueCode.GDshootObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.rogueCode.GDshootObjects2_2final, gdjs.rogueCode.GDshootObjects2);
}
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogueCode.GDshootObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDshootObjects1_1final.indexOf(gdjs.rogueCode.GDshootObjects2[j]) === -1 )
            gdjs.rogueCode.GDshootObjects1_1final.push(gdjs.rogueCode.GDshootObjects2[j]);
    }
}
}
{
gdjs.rogueCode.GDshootObjects2.length = 0;

{gdjs.rogueCode.GDshootObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.rogueCode.GDshootObjects3);
for (var i = 0, k = 0, l = gdjs.rogueCode.GDshootObjects3.length;i<l;++i) {
    if ( gdjs.rogueCode.GDshootObjects3[i].StickForceX((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) < -(0.3) ) {
        isConditionTrue_2 = true;
        gdjs.rogueCode.GDshootObjects3[k] = gdjs.rogueCode.GDshootObjects3[i];
        ++k;
    }
}
gdjs.rogueCode.GDshootObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.rogueCode.GDshootObjects3.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDshootObjects2_2final.indexOf(gdjs.rogueCode.GDshootObjects3[j]) === -1 )
            gdjs.rogueCode.GDshootObjects2_2final.push(gdjs.rogueCode.GDshootObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.rogueCode.GDshootObjects3);
for (var i = 0, k = 0, l = gdjs.rogueCode.GDshootObjects3.length;i<l;++i) {
    if ( gdjs.rogueCode.GDshootObjects3[i].StickForceY((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) < -(0.3) ) {
        isConditionTrue_2 = true;
        gdjs.rogueCode.GDshootObjects3[k] = gdjs.rogueCode.GDshootObjects3[i];
        ++k;
    }
}
gdjs.rogueCode.GDshootObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.rogueCode.GDshootObjects3.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDshootObjects2_2final.indexOf(gdjs.rogueCode.GDshootObjects3[j]) === -1 )
            gdjs.rogueCode.GDshootObjects2_2final.push(gdjs.rogueCode.GDshootObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.rogueCode.GDshootObjects2_2final, gdjs.rogueCode.GDshootObjects2);
}
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogueCode.GDshootObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDshootObjects1_1final.indexOf(gdjs.rogueCode.GDshootObjects2[j]) === -1 )
            gdjs.rogueCode.GDshootObjects1_1final.push(gdjs.rogueCode.GDshootObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.rogueCode.GDshootObjects1_1final, gdjs.rogueCode.GDshootObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) > 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "fail"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("touch"), false);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogueCode.GDrifleObjects1);
gdjs.rogueCode.GDbulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbulletObjects1Objects, (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getAABBCenterX()), (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getAABBCenterY()), "");
}{for(var i = 0, len = gdjs.rogueCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDbulletObjects1[i].addPolarForce((( gdjs.rogueCode.GDrifleObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDrifleObjects1[0].getAngle()), 1000, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 40, gdjs.randomInRange(0.8, 1.2));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.55, 0.33, 0.50, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) < 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogueCode.mapOfEmptyGDrifleObjects) > 0;
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(0.05);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("cement_block_blue"), gdjs.rogueCode.GDcement_9595block_9595blueObjects1);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue2"), gdjs.rogueCode.GDcement_9595block_9595blue2Objects1);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue_side"), gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue_side2"), gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogueCode.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("door"), gdjs.rogueCode.GDdoorObjects1);
gdjs.copyArray(runtimeScene.getObjects("hit_box"), gdjs.rogueCode.GDhit_9595boxObjects1);
gdjs.copyArray(runtimeScene.getObjects("pillar"), gdjs.rogueCode.GDpillarObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogueCode.GDrifleObjects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogueCode.GDsmasherObjects1);
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.rogueCode.GDwaterObjects1);
gdjs.copyArray(runtimeScene.getObjects("water_particlees"), gdjs.rogueCode.GDwater_9595particleesObjects1);
gdjs.copyArray(runtimeScene.getObjects("water_particlees2"), gdjs.rogueCode.GDwater_9595particlees2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDplayer1Objects1[i].getZOrder() > (gdjs.rogueCode.GDplayer1Objects1[i].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDplayer1Objects1[k] = gdjs.rogueCode.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDplayer1Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDpillarObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDpillarObjects1[i].getZOrder() > (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDpillarObjects1[k] = gdjs.rogueCode.GDpillarObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDpillarObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDcement_9595block_9595blueObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDcement_9595block_9595blueObjects1[i].getZOrder() > (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDcement_9595block_9595blueObjects1[k] = gdjs.rogueCode.GDcement_9595block_9595blueObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDcement_9595block_9595blueObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDclonObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDclonObjects1[i].getZOrder() > (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDclonObjects1[k] = gdjs.rogueCode.GDclonObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDclonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDcement_9595block_9595blue2Objects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDcement_9595block_9595blue2Objects1[i].getZOrder() > (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDcement_9595block_9595blue2Objects1[k] = gdjs.rogueCode.GDcement_9595block_9595blue2Objects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDcement_9595block_9595blue2Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDsmasherObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDsmasherObjects1[i].getZOrder() > (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDsmasherObjects1[k] = gdjs.rogueCode.GDsmasherObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDsmasherObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDdoorObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDdoorObjects1[i].getZOrder() > (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDdoorObjects1[k] = gdjs.rogueCode.GDdoorObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDdoorObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDrifleObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDrifleObjects1[i].getZOrder() > (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDrifleObjects1[k] = gdjs.rogueCode.GDrifleObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDrifleObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDhit_9595boxObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDhit_9595boxObjects1[i].getZOrder() > (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDhit_9595boxObjects1[k] = gdjs.rogueCode.GDhit_9595boxObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDhit_9595boxObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDwaterObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDwaterObjects1[i].getZOrder() > (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDwaterObjects1[k] = gdjs.rogueCode.GDwaterObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDwaterObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1[i].getZOrder() > (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1[k] = gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects1[i].getZOrder() > (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects1[k] = gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDwater_9595particleesObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDwater_9595particleesObjects1[i].getZOrder() > (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDwater_9595particleesObjects1[k] = gdjs.rogueCode.GDwater_9595particleesObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDwater_9595particleesObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDwater_9595particlees2Objects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDwater_9595particlees2Objects1[i].getZOrder() > (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDwater_9595particlees2Objects1[k] = gdjs.rogueCode.GDwater_9595particlees2Objects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDwater_9595particlees2Objects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogueCode.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.rogueCode.GDbossObjects1);
/* Reuse gdjs.rogueCode.GDcement_9595block_9595blueObjects1 */
/* Reuse gdjs.rogueCode.GDcement_9595block_9595blue2Objects1 */
/* Reuse gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1 */
/* Reuse gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects1 */
/* Reuse gdjs.rogueCode.GDclonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogueCode.GDdiverObjects1);
/* Reuse gdjs.rogueCode.GDdoorObjects1 */
/* Reuse gdjs.rogueCode.GDhit_9595boxObjects1 */
/* Reuse gdjs.rogueCode.GDpillarObjects1 */
/* Reuse gdjs.rogueCode.GDplayer1Objects1 */
/* Reuse gdjs.rogueCode.GDrifleObjects1 */
/* Reuse gdjs.rogueCode.GDsmasherObjects1 */
/* Reuse gdjs.rogueCode.GDwaterObjects1 */
/* Reuse gdjs.rogueCode.GDwater_9595particleesObjects1 */
/* Reuse gdjs.rogueCode.GDwater_9595particlees2Objects1 */
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogueCode.GDpillarObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDpillarObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogueCode.GDcement_9595block_9595blueObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDcement_9595block_9595blueObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogueCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDclonObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogueCode.GDcement_9595block_9595blue2Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDcement_9595block_9595blue2Objects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogueCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDsmasherObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogueCode.GDdoorObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDdoorObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogueCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDrifleObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogueCode.GDhit_9595boxObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDhit_9595boxObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogueCode.GDwaterObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDwaterObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogueCode.GDwater_9595particleesObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDwater_9595particleesObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogueCode.GDwater_9595particlees2Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDwater_9595particlees2Objects1[i].setZOrder(7);
}
}{for(var i = 0, len = gdjs.rogueCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDsmasherObjects1[i].setZOrder(9);
}
for(var i = 0, len = gdjs.rogueCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDclonObjects1[i].setZOrder(9);
}
for(var i = 0, len = gdjs.rogueCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDblast_9595botObjects1[i].setZOrder(9);
}
for(var i = 0, len = gdjs.rogueCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDdiverObjects1[i].setZOrder(9);
}
for(var i = 0, len = gdjs.rogueCode.GDbossObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDbossObjects1[i].setZOrder(9);
}
}{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects1[i].setZOrder(200);
}
}{for(var i = 0, len = gdjs.rogueCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDrifleObjects1[i].setZOrder(201);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogueCode.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("blocker"), gdjs.rogueCode.GDblockerObjects1);
gdjs.copyArray(runtimeScene.getObjects("hit_box"), gdjs.rogueCode.GDhit_9595boxObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogueCode.GDrifleObjects1);
gdjs.copyArray(runtimeScene.getObjects("sensor"), gdjs.rogueCode.GDsensorObjects1);
gdjs.copyArray(runtimeScene.getObjects("sensor2"), gdjs.rogueCode.GDsensor2Objects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}{for(var i = 0, len = gdjs.rogueCode.GDhit_9595boxObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDhit_9595boxObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.rogueCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDrifleObjects1[i].setZOrder(101);
}
}{for(var i = 0, len = gdjs.rogueCode.GDsensorObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDsensorObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.rogueCode.GDblockerObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDblockerObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.rogueCode.GDsensor2Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDsensor2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.rogueCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDblast_9595botObjects1[i].resetTimer("blast");
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("sc", "sc", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(1));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").setNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber());
}
{ //Subevents
gdjs.rogueCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("sensor"), gdjs.rogueCode.GDsensorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDsensorObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDsensorObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDsensorObjects1[k] = gdjs.rogueCode.GDsensorObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDsensorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDsensorObjects1 */
{for(var i = 0, len = gdjs.rogueCode.GDsensorObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDsensorObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hit_box"), gdjs.rogueCode.GDhit_9595boxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDhit_9595boxObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDhit_9595boxObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDhit_9595boxObjects1[k] = gdjs.rogueCode.GDhit_9595boxObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDhit_9595boxObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDhit_9595boxObjects1 */
{for(var i = 0, len = gdjs.rogueCode.GDhit_9595boxObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDhit_9595boxObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDplayer1Objects1[i].getVariableNumber(gdjs.rogueCode.GDplayer1Objects1[i].getVariables().getFromIndex(0)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDplayer1Objects1[k] = gdjs.rogueCode.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDplayer1Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("cement_block_blue"), gdjs.rogueCode.GDcement_9595block_9595blueObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.rogueCode.GDwaterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects1Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwaterObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects1Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDcement_95959595block_95959595blueObjects1Objects, true, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogueCode.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.rogueCode.GDbossObjects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogueCode.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogueCode.GDdiverObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogueCode.GDsmasherObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects1Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsmasherObjects1ObjectsGDgdjs_9546rogueCode_9546GDclonObjects1ObjectsGDgdjs_9546rogueCode_9546GDblast_95959595botObjects1ObjectsGDgdjs_9546rogueCode_9546GDdiverObjects1ObjectsGDgdjs_9546rogueCode_9546GDbossObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDsmasherObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDsmasherObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDsmasherObjects1[k] = gdjs.rogueCode.GDsmasherObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDsmasherObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDclonObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDclonObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDclonObjects1[k] = gdjs.rogueCode.GDclonObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDclonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDblast_9595botObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDblast_9595botObjects1[k] = gdjs.rogueCode.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDblast_9595botObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDdiverObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDdiverObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDdiverObjects1[k] = gdjs.rogueCode.GDdiverObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDdiverObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDbossObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDbossObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDbossObjects1[k] = gdjs.rogueCode.GDbossObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDbossObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15947956);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects1[i].returnVariable(gdjs.rogueCode.GDplayer1Objects1[i].getVariables().getFromIndex(0)).sub(16);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blocker"), gdjs.rogueCode.GDblockerObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("sensor2"), gdjs.rogueCode.GDsensor2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects1Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDblockerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsensor2Objects1Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDblockerObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDblockerObjects1 */
{for(var i = 0, len = gdjs.rogueCode.GDblockerObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDblockerObjects1[i].setVariableBoolean(gdjs.rogueCode.GDblockerObjects1[i].getVariables().getFromIndex(0), true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogueCode.mapOfEmptyGDplayer1Objects) < 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.rogueCode.GDstateObjects1);
gdjs.copyArray(runtimeScene.getObjects("win_fail"), gdjs.rogueCode.GDwin_9595failObjects1);
{gdjs.evtTools.camera.showLayer(runtimeScene, "fail");
}{for(var i = 0, len = gdjs.rogueCode.GDwin_9595failObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDwin_9595failObjects1[i].getBehavior("Text").setText("you fail");
}
}{for(var i = 0, len = gdjs.rogueCode.GDstateObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDstateObjects1[i].getBehavior("Text").setText("restart");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogueCode.mapOfEmptyGDsmasherObjectsEmptyGDclonObjectsEmptyGDblast_9595botObjectsEmptyGDdiverObjectsEmptyGDbossObjects) < 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level")) <= 9;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.rogueCode.GDstateObjects1);
gdjs.copyArray(runtimeScene.getObjects("win_fail"), gdjs.rogueCode.GDwin_9595failObjects1);
{gdjs.evtTools.camera.showLayer(runtimeScene, "fail");
}{for(var i = 0, len = gdjs.rogueCode.GDwin_9595failObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDwin_9595failObjects1[i].getBehavior("Text").setText("you win");
}
}{for(var i = 0, len = gdjs.rogueCode.GDstateObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDstateObjects1[i].getBehavior("Text").setText("next");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level")) > 9;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogueCode.mapOfEmptyGDsmasherObjectsEmptyGDclonObjectsEmptyGDblast_9595botObjectsEmptyGDdiverObjectsEmptyGDbossObjects) < 1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.rogueCode.GDstateObjects1);
gdjs.copyArray(runtimeScene.getObjects("win_fail"), gdjs.rogueCode.GDwin_9595failObjects1);
{gdjs.evtTools.camera.showLayer(runtimeScene, "fail");
}{for(var i = 0, len = gdjs.rogueCode.GDwin_9595failObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDwin_9595failObjects1[i].getBehavior("Text").setText("you win");
}
}{for(var i = 0, len = gdjs.rogueCode.GDstateObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDstateObjects1[i].getBehavior("Text").setText("level complete");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15955132);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogueCode.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogueCode.GDdiverObjects1);
{for(var i = 0, len = gdjs.rogueCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDblast_9595botObjects1[i].resetTimer("blast");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "dive");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "spawn");
}{for(var i = 0, len = gdjs.rogueCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDdiverObjects1[i].setZOrder(300);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "dive") >= 4;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogueCode.GDdiverObjects1);
{for(var i = 0, len = gdjs.rogueCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDdiverObjects1[i].getBehavior("Animation").setAnimationName("ready");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "dive") >= 6;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogueCode.GDdiverObjects1);
{for(var i = 0, len = gdjs.rogueCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDdiverObjects1[i].getBehavior("Animation").setAnimationName("targeting");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "dive");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogueCode.mapOfEmptyGDbossObjects) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "spawn") >= 8;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15958996);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.rogueCode.GDbossObjects1);
gdjs.rogueCode.GDclonObjects1.length = 0;

gdjs.rogueCode.GDdiverObjects1.length = 0;

gdjs.rogueCode.GDsmasherObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDclonObjects1Objects, (( gdjs.rogueCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDbossObjects1[0].getPointX("")) + gdjs.randomInRange(100, 400), (( gdjs.rogueCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDbossObjects1[0].getPointY("")) + gdjs.randomInRange((( gdjs.rogueCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDbossObjects1[0].getPointY("")), 300), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDclonObjects1Objects, (( gdjs.rogueCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDbossObjects1[0].getPointX("")) + gdjs.randomInRange(100, 400), (( gdjs.rogueCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDbossObjects1[0].getPointY("")) + gdjs.randomInRange((( gdjs.rogueCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDbossObjects1[0].getPointY("")), 300), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDclonObjects1Objects, (( gdjs.rogueCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDbossObjects1[0].getPointX("")) + gdjs.randomInRange(100, 400), (( gdjs.rogueCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDbossObjects1[0].getPointY("")) + gdjs.randomInRange((( gdjs.rogueCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDbossObjects1[0].getPointY("")), 300), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDsmasherObjects1Objects, (( gdjs.rogueCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDbossObjects1[0].getPointX("")) + gdjs.randomInRange(100, 400), (( gdjs.rogueCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDbossObjects1[0].getPointY("")) + gdjs.randomInRange((( gdjs.rogueCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDbossObjects1[0].getPointY("")), 300), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDdiverObjects1Objects, (( gdjs.rogueCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDbossObjects1[0].getPointX("")) + gdjs.randomInRange(100, 400), (( gdjs.rogueCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDbossObjects1[0].getPointY("")) + gdjs.randomInRange((( gdjs.rogueCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDbossObjects1[0].getPointY("")), 300), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "spawn");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogueCode.GDdiverObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDdiverObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDdiverObjects1[i].getBehavior("Animation").getAnimationName() == "ready" ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDdiverObjects1[k] = gdjs.rogueCode.GDdiverObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDdiverObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15963844);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDdiverObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);
{for(var i = 0, len = gdjs.rogueCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDdiverObjects1[i].rotateTowardPosition((( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getCenterXInScene()), (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getCenterYInScene()), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.rogueCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDdiverObjects1[i].addPolarForce((gdjs.rogueCode.GDdiverObjects1[i].getAngle()), 450, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogueCode.GDdiverObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDdiverObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDdiverObjects1[i].getBehavior("Animation").getAnimationName() == "targeting" ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDdiverObjects1[k] = gdjs.rogueCode.GDdiverObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDdiverObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDdiverObjects1 */
{for(var i = 0, len = gdjs.rogueCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDdiverObjects1[i].clearForces();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogueCode.GDblast_9595botObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDblast_9595botObjects1[i].getTimerElapsedTimeInSecondsOrNaN("blast") >= 3 ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDblast_9595botObjects1[k] = gdjs.rogueCode.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDblast_9595botObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDblast_9595botObjects1 */
{for(var i = 0, len = gdjs.rogueCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDblast_9595botObjects1[i].getBehavior("Animation").setAnimationName("bot_jump");
}
}}

}


{

gdjs.rogueCode.GDplayer1Objects1.length = 0;

gdjs.rogueCode.GDwater_9595particleesObjects1.length = 0;

gdjs.rogueCode.GDwater_9595particlees2Objects1.length = 0;

gdjs.rogueCode.GDwaveObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.rogueCode.GDplayer1Objects1_1final.length = 0;
gdjs.rogueCode.GDwater_9595particleesObjects1_1final.length = 0;
gdjs.rogueCode.GDwater_9595particlees2Objects1_1final.length = 0;
gdjs.rogueCode.GDwaveObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("water_particlees2"), gdjs.rogueCode.GDwater_9595particlees2Objects2);
gdjs.copyArray(runtimeScene.getObjects("wave"), gdjs.rogueCode.GDwaveObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwaveObjects2Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwater_95959595particlees2Objects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogueCode.GDwater_9595particlees2Objects2.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDwater_9595particlees2Objects1_1final.indexOf(gdjs.rogueCode.GDwater_9595particlees2Objects2[j]) === -1 )
            gdjs.rogueCode.GDwater_9595particlees2Objects1_1final.push(gdjs.rogueCode.GDwater_9595particlees2Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.rogueCode.GDwaveObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDwaveObjects1_1final.indexOf(gdjs.rogueCode.GDwaveObjects2[j]) === -1 )
            gdjs.rogueCode.GDwaveObjects1_1final.push(gdjs.rogueCode.GDwaveObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("water_particlees"), gdjs.rogueCode.GDwater_9595particleesObjects2);
gdjs.copyArray(runtimeScene.getObjects("wave"), gdjs.rogueCode.GDwaveObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwaveObjects2Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwater_95959595particleesObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogueCode.GDwater_9595particleesObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDwater_9595particleesObjects1_1final.indexOf(gdjs.rogueCode.GDwater_9595particleesObjects2[j]) === -1 )
            gdjs.rogueCode.GDwater_9595particleesObjects1_1final.push(gdjs.rogueCode.GDwater_9595particleesObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.rogueCode.GDwaveObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDwaveObjects1_1final.indexOf(gdjs.rogueCode.GDwaveObjects2[j]) === -1 )
            gdjs.rogueCode.GDwaveObjects1_1final.push(gdjs.rogueCode.GDwaveObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects2);
gdjs.copyArray(runtimeScene.getObjects("wave"), gdjs.rogueCode.GDwaveObjects2);
isConditionTrue_1 = gdjs.evtTools.object.distanceTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwaveObjects2Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects2Objects, 4000, true);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogueCode.GDplayer1Objects2.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDplayer1Objects1_1final.indexOf(gdjs.rogueCode.GDplayer1Objects2[j]) === -1 )
            gdjs.rogueCode.GDplayer1Objects1_1final.push(gdjs.rogueCode.GDplayer1Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.rogueCode.GDwaveObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDwaveObjects1_1final.indexOf(gdjs.rogueCode.GDwaveObjects2[j]) === -1 )
            gdjs.rogueCode.GDwaveObjects1_1final.push(gdjs.rogueCode.GDwaveObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.rogueCode.GDplayer1Objects1_1final, gdjs.rogueCode.GDplayer1Objects1);
gdjs.copyArray(gdjs.rogueCode.GDwater_9595particleesObjects1_1final, gdjs.rogueCode.GDwater_9595particleesObjects1);
gdjs.copyArray(gdjs.rogueCode.GDwater_9595particlees2Objects1_1final, gdjs.rogueCode.GDwater_9595particlees2Objects1);
gdjs.copyArray(gdjs.rogueCode.GDwaveObjects1_1final, gdjs.rogueCode.GDwaveObjects1);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDwaveObjects1 */
{for(var i = 0, len = gdjs.rogueCode.GDwaveObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDwaveObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogueCode.GDblast_9595botObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDblast_9595botObjects1[i].getBehavior("Animation").getAnimationName() == "bot_jump" ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDblast_9595botObjects1[k] = gdjs.rogueCode.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDblast_9595botObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDblast_9595botObjects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDblast_9595botObjects1[k] = gdjs.rogueCode.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDblast_9595botObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDblast_9595botObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);
gdjs.rogueCode.GDwaveObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwaveObjects1Objects, (( gdjs.rogueCode.GDblast_9595botObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDblast_9595botObjects1[0].getCenterXInScene()), (( gdjs.rogueCode.GDblast_9595botObjects1.length === 0 ) ? 0 :gdjs.rogueCode.GDblast_9595botObjects1[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.rogueCode.GDwaveObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDwaveObjects1[i].rotateTowardPosition((( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getCenterXInScene()), (( gdjs.rogueCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogueCode.GDplayer1Objects1[0].getCenterYInScene()), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.rogueCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDblast_9595botObjects1[i].getBehavior("Animation").setAnimationName("bot_idle");
}
}{for(var i = 0, len = gdjs.rogueCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDblast_9595botObjects1[i].resetTimer("blast");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogueCode.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.rogueCode.GDbulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbulletObjects1Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDblast_95959595botObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDblast_9595botObjects1 */
/* Reuse gdjs.rogueCode.GDbulletObjects1 */
{for(var i = 0, len = gdjs.rogueCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDblast_9595botObjects1[i].returnVariable(gdjs.rogueCode.GDblast_9595botObjects1[i].getVariables().getFromIndex(0)).sub(25);
}
}{for(var i = 0, len = gdjs.rogueCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 40, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.rogueCode.GDbulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogueCode.GDdiverObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbulletObjects1Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDdiverObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDbulletObjects1 */
/* Reuse gdjs.rogueCode.GDdiverObjects1 */
{for(var i = 0, len = gdjs.rogueCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDdiverObjects1[i].returnVariable(gdjs.rogueCode.GDdiverObjects1[i].getVariables().getFromIndex(0)).sub(25);
}
}{for(var i = 0, len = gdjs.rogueCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 40, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.rogueCode.GDbossObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.rogueCode.GDbulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbulletObjects1Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDbossObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDbossObjects1 */
/* Reuse gdjs.rogueCode.GDbulletObjects1 */
{for(var i = 0, len = gdjs.rogueCode.GDbossObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDbossObjects1[i].returnVariable(gdjs.rogueCode.GDbossObjects1[i].getVariables().getFromIndex(0)).sub(10);
}
}{for(var i = 0, len = gdjs.rogueCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 40, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogueCode.GDblast_9595botObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDblast_9595botObjects1[i].getVariableNumber(gdjs.rogueCode.GDblast_9595botObjects1[i].getVariables().getFromIndex(0)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDblast_9595botObjects1[k] = gdjs.rogueCode.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDblast_9595botObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDblast_9595botObjects1 */
{for(var i = 0, len = gdjs.rogueCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDblast_9595botObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogueCode.GDdiverObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDdiverObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDdiverObjects1[i].getVariableNumber(gdjs.rogueCode.GDdiverObjects1[i].getVariables().getFromIndex(0)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDdiverObjects1[k] = gdjs.rogueCode.GDdiverObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDdiverObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDdiverObjects1 */
{for(var i = 0, len = gdjs.rogueCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDdiverObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.rogueCode.GDbossObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDbossObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDbossObjects1[i].getVariableNumber(gdjs.rogueCode.GDbossObjects1[i].getVariables().getFromIndex(0)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDbossObjects1[k] = gdjs.rogueCode.GDbossObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDbossObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogueCode.GDblast_9595botObjects1);
/* Reuse gdjs.rogueCode.GDbossObjects1 */
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogueCode.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogueCode.GDdiverObjects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogueCode.GDsmasherObjects1);
{for(var i = 0, len = gdjs.rogueCode.GDbossObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDbossObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.rogueCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDsmasherObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDclonObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDblast_9595botObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDdiverObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogueCode.GDbossObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDbossObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.rogueCode.eventsList1(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDplayer1Objects1[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDplayer1Objects1[k] = gdjs.rogueCode.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDplayer1Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15991796);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "walk", 3, true, 40, 0.3);
}}

}


{

gdjs.rogueCode.GDplayer1Objects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.rogueCode.GDplayer1Objects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects2);
for (var i = 0, k = 0, l = gdjs.rogueCode.GDplayer1Objects2.length;i<l;++i) {
    if ( !(gdjs.rogueCode.GDplayer1Objects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_1 = true;
        gdjs.rogueCode.GDplayer1Objects2[k] = gdjs.rogueCode.GDplayer1Objects2[i];
        ++k;
    }
}
gdjs.rogueCode.GDplayer1Objects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogueCode.GDplayer1Objects2.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDplayer1Objects1_1final.indexOf(gdjs.rogueCode.GDplayer1Objects2[j]) === -1 )
            gdjs.rogueCode.GDplayer1Objects1_1final.push(gdjs.rogueCode.GDplayer1Objects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogueCode.mapOfEmptyGDplayer1Objects) < 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.rogueCode.GDplayer1Objects1_1final, gdjs.rogueCode.GDplayer1Objects1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 3);
}}

}


{

gdjs.rogueCode.GDdiverObjects1.length = 0;

gdjs.rogueCode.GDplayer1Objects1.length = 0;

gdjs.rogueCode.GDwaveObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.rogueCode.GDdiverObjects1_1final.length = 0;
gdjs.rogueCode.GDplayer1Objects1_1final.length = 0;
gdjs.rogueCode.GDwaveObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects2);
gdjs.copyArray(runtimeScene.getObjects("wave"), gdjs.rogueCode.GDwaveObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDwaveObjects2Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogueCode.GDplayer1Objects2.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDplayer1Objects1_1final.indexOf(gdjs.rogueCode.GDplayer1Objects2[j]) === -1 )
            gdjs.rogueCode.GDplayer1Objects1_1final.push(gdjs.rogueCode.GDplayer1Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.rogueCode.GDwaveObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDwaveObjects1_1final.indexOf(gdjs.rogueCode.GDwaveObjects2[j]) === -1 )
            gdjs.rogueCode.GDwaveObjects1_1final.push(gdjs.rogueCode.GDwaveObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogueCode.GDdiverObjects2);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogueCode.GDplayer1Objects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDdiverObjects2Objects, gdjs.rogueCode.mapOfGDgdjs_9546rogueCode_9546GDplayer1Objects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogueCode.GDdiverObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDdiverObjects1_1final.indexOf(gdjs.rogueCode.GDdiverObjects2[j]) === -1 )
            gdjs.rogueCode.GDdiverObjects1_1final.push(gdjs.rogueCode.GDdiverObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.rogueCode.GDplayer1Objects2.length; j < jLen ; ++j) {
        if ( gdjs.rogueCode.GDplayer1Objects1_1final.indexOf(gdjs.rogueCode.GDplayer1Objects2[j]) === -1 )
            gdjs.rogueCode.GDplayer1Objects1_1final.push(gdjs.rogueCode.GDplayer1Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.rogueCode.GDdiverObjects1_1final, gdjs.rogueCode.GDdiverObjects1);
gdjs.copyArray(gdjs.rogueCode.GDplayer1Objects1_1final, gdjs.rogueCode.GDplayer1Objects1);
gdjs.copyArray(gdjs.rogueCode.GDwaveObjects1_1final, gdjs.rogueCode.GDwaveObjects1);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.rogueCode.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.rogueCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogueCode.GDplayer1Objects1[i].returnVariable(gdjs.rogueCode.GDplayer1Objects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogueCode.GDblast_9595botObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogueCode.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.rogueCode.GDblast_9595botObjects1[i].getBehavior("Animation").getAnimationName() == "bot_idle" ) {
        isConditionTrue_0 = true;
        gdjs.rogueCode.GDblast_9595botObjects1[k] = gdjs.rogueCode.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.rogueCode.GDblast_9595botObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("wave"), gdjs.rogueCode.GDwaveObjects1);
{for(var i = 0, len = gdjs.rogueCode.GDwaveObjects1.length ;i < len;++i) {
    gdjs.rogueCode.GDwaveObjects1[i].addPolarForce((gdjs.rogueCode.GDwaveObjects1[i].getAngle()), 300, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "fail");
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 3);
}
{ //Subevents
gdjs.rogueCode.eventsList2(runtimeScene);} //End of subevents
}

}


};

gdjs.rogueCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.rogueCode.GDplayer1Objects1.length = 0;
gdjs.rogueCode.GDplayer1Objects2.length = 0;
gdjs.rogueCode.GDplayer1Objects3.length = 0;
gdjs.rogueCode.GDpillarObjects1.length = 0;
gdjs.rogueCode.GDpillarObjects2.length = 0;
gdjs.rogueCode.GDpillarObjects3.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blueObjects1.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blueObjects2.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blueObjects3.length = 0;
gdjs.rogueCode.GDclonObjects1.length = 0;
gdjs.rogueCode.GDclonObjects2.length = 0;
gdjs.rogueCode.GDclonObjects3.length = 0;
gdjs.rogueCode.GDsmasherObjects1.length = 0;
gdjs.rogueCode.GDsmasherObjects2.length = 0;
gdjs.rogueCode.GDsmasherObjects3.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue2Objects1.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue2Objects2.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue2Objects3.length = 0;
gdjs.rogueCode.GDdoorObjects1.length = 0;
gdjs.rogueCode.GDdoorObjects2.length = 0;
gdjs.rogueCode.GDdoorObjects3.length = 0;
gdjs.rogueCode.GDrifleObjects1.length = 0;
gdjs.rogueCode.GDrifleObjects2.length = 0;
gdjs.rogueCode.GDrifleObjects3.length = 0;
gdjs.rogueCode.GDhit_9595boxObjects1.length = 0;
gdjs.rogueCode.GDhit_9595boxObjects2.length = 0;
gdjs.rogueCode.GDhit_9595boxObjects3.length = 0;
gdjs.rogueCode.GDbulletObjects1.length = 0;
gdjs.rogueCode.GDbulletObjects2.length = 0;
gdjs.rogueCode.GDbulletObjects3.length = 0;
gdjs.rogueCode.GDreloadObjects1.length = 0;
gdjs.rogueCode.GDreloadObjects2.length = 0;
gdjs.rogueCode.GDreloadObjects3.length = 0;
gdjs.rogueCode.GDreload2Objects1.length = 0;
gdjs.rogueCode.GDreload2Objects2.length = 0;
gdjs.rogueCode.GDreload2Objects3.length = 0;
gdjs.rogueCode.GDwaterObjects1.length = 0;
gdjs.rogueCode.GDwaterObjects2.length = 0;
gdjs.rogueCode.GDwaterObjects3.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects2.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects3.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects1.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects2.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects3.length = 0;
gdjs.rogueCode.GDwater_9595particleesObjects1.length = 0;
gdjs.rogueCode.GDwater_9595particleesObjects2.length = 0;
gdjs.rogueCode.GDwater_9595particleesObjects3.length = 0;
gdjs.rogueCode.GDwater_9595particlees2Objects1.length = 0;
gdjs.rogueCode.GDwater_9595particlees2Objects2.length = 0;
gdjs.rogueCode.GDwater_9595particlees2Objects3.length = 0;
gdjs.rogueCode.GDlifeObjects1.length = 0;
gdjs.rogueCode.GDlifeObjects2.length = 0;
gdjs.rogueCode.GDlifeObjects3.length = 0;
gdjs.rogueCode.GDbackgroundObjects1.length = 0;
gdjs.rogueCode.GDbackgroundObjects2.length = 0;
gdjs.rogueCode.GDbackgroundObjects3.length = 0;
gdjs.rogueCode.GDwin_9595failObjects1.length = 0;
gdjs.rogueCode.GDwin_9595failObjects2.length = 0;
gdjs.rogueCode.GDwin_9595failObjects3.length = 0;
gdjs.rogueCode.GDstateObjects1.length = 0;
gdjs.rogueCode.GDstateObjects2.length = 0;
gdjs.rogueCode.GDstateObjects3.length = 0;
gdjs.rogueCode.GDlineObjects1.length = 0;
gdjs.rogueCode.GDlineObjects2.length = 0;
gdjs.rogueCode.GDlineObjects3.length = 0;
gdjs.rogueCode.GDsensorObjects1.length = 0;
gdjs.rogueCode.GDsensorObjects2.length = 0;
gdjs.rogueCode.GDsensorObjects3.length = 0;
gdjs.rogueCode.GDblockerObjects1.length = 0;
gdjs.rogueCode.GDblockerObjects2.length = 0;
gdjs.rogueCode.GDblockerObjects3.length = 0;
gdjs.rogueCode.GDsensor2Objects1.length = 0;
gdjs.rogueCode.GDsensor2Objects2.length = 0;
gdjs.rogueCode.GDsensor2Objects3.length = 0;
gdjs.rogueCode.GDsmasher_9595aObjects1.length = 0;
gdjs.rogueCode.GDsmasher_9595aObjects2.length = 0;
gdjs.rogueCode.GDsmasher_9595aObjects3.length = 0;
gdjs.rogueCode.GDblast_9595botObjects1.length = 0;
gdjs.rogueCode.GDblast_9595botObjects2.length = 0;
gdjs.rogueCode.GDblast_9595botObjects3.length = 0;
gdjs.rogueCode.GDwaveObjects1.length = 0;
gdjs.rogueCode.GDwaveObjects2.length = 0;
gdjs.rogueCode.GDwaveObjects3.length = 0;
gdjs.rogueCode.GDdiverObjects1.length = 0;
gdjs.rogueCode.GDdiverObjects2.length = 0;
gdjs.rogueCode.GDdiverObjects3.length = 0;
gdjs.rogueCode.GDlevelObjects1.length = 0;
gdjs.rogueCode.GDlevelObjects2.length = 0;
gdjs.rogueCode.GDlevelObjects3.length = 0;
gdjs.rogueCode.GDbossObjects1.length = 0;
gdjs.rogueCode.GDbossObjects2.length = 0;
gdjs.rogueCode.GDbossObjects3.length = 0;
gdjs.rogueCode.GDbackObjects1.length = 0;
gdjs.rogueCode.GDbackObjects2.length = 0;
gdjs.rogueCode.GDbackObjects3.length = 0;
gdjs.rogueCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.rogueCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.rogueCode.GDShadedDarkJoystickObjects3.length = 0;
gdjs.rogueCode.GDshootObjects1.length = 0;
gdjs.rogueCode.GDshootObjects2.length = 0;
gdjs.rogueCode.GDshootObjects3.length = 0;

gdjs.rogueCode.eventsList3(runtimeScene);
gdjs.rogueCode.GDplayer1Objects1.length = 0;
gdjs.rogueCode.GDplayer1Objects2.length = 0;
gdjs.rogueCode.GDplayer1Objects3.length = 0;
gdjs.rogueCode.GDpillarObjects1.length = 0;
gdjs.rogueCode.GDpillarObjects2.length = 0;
gdjs.rogueCode.GDpillarObjects3.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blueObjects1.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blueObjects2.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blueObjects3.length = 0;
gdjs.rogueCode.GDclonObjects1.length = 0;
gdjs.rogueCode.GDclonObjects2.length = 0;
gdjs.rogueCode.GDclonObjects3.length = 0;
gdjs.rogueCode.GDsmasherObjects1.length = 0;
gdjs.rogueCode.GDsmasherObjects2.length = 0;
gdjs.rogueCode.GDsmasherObjects3.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue2Objects1.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue2Objects2.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue2Objects3.length = 0;
gdjs.rogueCode.GDdoorObjects1.length = 0;
gdjs.rogueCode.GDdoorObjects2.length = 0;
gdjs.rogueCode.GDdoorObjects3.length = 0;
gdjs.rogueCode.GDrifleObjects1.length = 0;
gdjs.rogueCode.GDrifleObjects2.length = 0;
gdjs.rogueCode.GDrifleObjects3.length = 0;
gdjs.rogueCode.GDhit_9595boxObjects1.length = 0;
gdjs.rogueCode.GDhit_9595boxObjects2.length = 0;
gdjs.rogueCode.GDhit_9595boxObjects3.length = 0;
gdjs.rogueCode.GDbulletObjects1.length = 0;
gdjs.rogueCode.GDbulletObjects2.length = 0;
gdjs.rogueCode.GDbulletObjects3.length = 0;
gdjs.rogueCode.GDreloadObjects1.length = 0;
gdjs.rogueCode.GDreloadObjects2.length = 0;
gdjs.rogueCode.GDreloadObjects3.length = 0;
gdjs.rogueCode.GDreload2Objects1.length = 0;
gdjs.rogueCode.GDreload2Objects2.length = 0;
gdjs.rogueCode.GDreload2Objects3.length = 0;
gdjs.rogueCode.GDwaterObjects1.length = 0;
gdjs.rogueCode.GDwaterObjects2.length = 0;
gdjs.rogueCode.GDwaterObjects3.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects1.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects2.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue_9595sideObjects3.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects1.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects2.length = 0;
gdjs.rogueCode.GDcement_9595block_9595blue_9595side2Objects3.length = 0;
gdjs.rogueCode.GDwater_9595particleesObjects1.length = 0;
gdjs.rogueCode.GDwater_9595particleesObjects2.length = 0;
gdjs.rogueCode.GDwater_9595particleesObjects3.length = 0;
gdjs.rogueCode.GDwater_9595particlees2Objects1.length = 0;
gdjs.rogueCode.GDwater_9595particlees2Objects2.length = 0;
gdjs.rogueCode.GDwater_9595particlees2Objects3.length = 0;
gdjs.rogueCode.GDlifeObjects1.length = 0;
gdjs.rogueCode.GDlifeObjects2.length = 0;
gdjs.rogueCode.GDlifeObjects3.length = 0;
gdjs.rogueCode.GDbackgroundObjects1.length = 0;
gdjs.rogueCode.GDbackgroundObjects2.length = 0;
gdjs.rogueCode.GDbackgroundObjects3.length = 0;
gdjs.rogueCode.GDwin_9595failObjects1.length = 0;
gdjs.rogueCode.GDwin_9595failObjects2.length = 0;
gdjs.rogueCode.GDwin_9595failObjects3.length = 0;
gdjs.rogueCode.GDstateObjects1.length = 0;
gdjs.rogueCode.GDstateObjects2.length = 0;
gdjs.rogueCode.GDstateObjects3.length = 0;
gdjs.rogueCode.GDlineObjects1.length = 0;
gdjs.rogueCode.GDlineObjects2.length = 0;
gdjs.rogueCode.GDlineObjects3.length = 0;
gdjs.rogueCode.GDsensorObjects1.length = 0;
gdjs.rogueCode.GDsensorObjects2.length = 0;
gdjs.rogueCode.GDsensorObjects3.length = 0;
gdjs.rogueCode.GDblockerObjects1.length = 0;
gdjs.rogueCode.GDblockerObjects2.length = 0;
gdjs.rogueCode.GDblockerObjects3.length = 0;
gdjs.rogueCode.GDsensor2Objects1.length = 0;
gdjs.rogueCode.GDsensor2Objects2.length = 0;
gdjs.rogueCode.GDsensor2Objects3.length = 0;
gdjs.rogueCode.GDsmasher_9595aObjects1.length = 0;
gdjs.rogueCode.GDsmasher_9595aObjects2.length = 0;
gdjs.rogueCode.GDsmasher_9595aObjects3.length = 0;
gdjs.rogueCode.GDblast_9595botObjects1.length = 0;
gdjs.rogueCode.GDblast_9595botObjects2.length = 0;
gdjs.rogueCode.GDblast_9595botObjects3.length = 0;
gdjs.rogueCode.GDwaveObjects1.length = 0;
gdjs.rogueCode.GDwaveObjects2.length = 0;
gdjs.rogueCode.GDwaveObjects3.length = 0;
gdjs.rogueCode.GDdiverObjects1.length = 0;
gdjs.rogueCode.GDdiverObjects2.length = 0;
gdjs.rogueCode.GDdiverObjects3.length = 0;
gdjs.rogueCode.GDlevelObjects1.length = 0;
gdjs.rogueCode.GDlevelObjects2.length = 0;
gdjs.rogueCode.GDlevelObjects3.length = 0;
gdjs.rogueCode.GDbossObjects1.length = 0;
gdjs.rogueCode.GDbossObjects2.length = 0;
gdjs.rogueCode.GDbossObjects3.length = 0;
gdjs.rogueCode.GDbackObjects1.length = 0;
gdjs.rogueCode.GDbackObjects2.length = 0;
gdjs.rogueCode.GDbackObjects3.length = 0;
gdjs.rogueCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.rogueCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.rogueCode.GDShadedDarkJoystickObjects3.length = 0;
gdjs.rogueCode.GDshootObjects1.length = 0;
gdjs.rogueCode.GDshootObjects2.length = 0;
gdjs.rogueCode.GDshootObjects3.length = 0;


return;

}

gdjs['rogueCode'] = gdjs.rogueCode;
