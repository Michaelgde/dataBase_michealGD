gdjs.splashCode = {};
gdjs.splashCode.localVariables = [];
gdjs.splashCode.GDsplashObjects1= [];
gdjs.splashCode.GDsplashObjects2= [];


gdjs.splashCode.asyncCallback15515260 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.splashCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level select", false);
}gdjs.splashCode.localVariables.length = 0;
}
gdjs.splashCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.splashCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.splashCode.asyncCallback15515260(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.splashCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("splash"), gdjs.splashCode.GDsplashObjects1);
{for(var i = 0, len = gdjs.splashCode.GDsplashObjects1.length ;i < len;++i) {
    gdjs.splashCode.GDsplashObjects1[i].getBehavior("Tween").addObjectPositionXTween2("xx", gdjs.evtTools.window.getWindowInnerWidth() / 2 - (gdjs.splashCode.GDsplashObjects1[i].getWidth()) / 2, "linear", 1, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("splash"), gdjs.splashCode.GDsplashObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.splashCode.GDsplashObjects1.length;i<l;++i) {
    if ( gdjs.splashCode.GDsplashObjects1[i].getBehavior("Tween").hasFinished("xx") ) {
        isConditionTrue_0 = true;
        gdjs.splashCode.GDsplashObjects1[k] = gdjs.splashCode.GDsplashObjects1[i];
        ++k;
    }
}
gdjs.splashCode.GDsplashObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.splashCode.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.splashCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.splashCode.GDsplashObjects1.length = 0;
gdjs.splashCode.GDsplashObjects2.length = 0;

gdjs.splashCode.eventsList1(runtimeScene);
gdjs.splashCode.GDsplashObjects1.length = 0;
gdjs.splashCode.GDsplashObjects2.length = 0;


return;

}

gdjs['splashCode'] = gdjs.splashCode;
