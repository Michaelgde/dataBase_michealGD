gdjs.join_47hostCode = {};
gdjs.join_47hostCode.localVariables = [];
gdjs.join_47hostCode.GDbuttomObjects1= [];
gdjs.join_47hostCode.GDbuttomObjects2= [];
gdjs.join_47hostCode.GDbuttomObjects3= [];
gdjs.join_47hostCode.GDhostObjects1= [];
gdjs.join_47hostCode.GDhostObjects2= [];
gdjs.join_47hostCode.GDhostObjects3= [];
gdjs.join_47hostCode.GDJOINObjects1= [];
gdjs.join_47hostCode.GDJOINObjects2= [];
gdjs.join_47hostCode.GDJOINObjects3= [];
gdjs.join_47hostCode.GDfriends_9595idObjects1= [];
gdjs.join_47hostCode.GDfriends_9595idObjects2= [];
gdjs.join_47hostCode.GDfriends_9595idObjects3= [];
gdjs.join_47hostCode.GDur_9595idObjects1= [];
gdjs.join_47hostCode.GDur_9595idObjects2= [];
gdjs.join_47hostCode.GDur_9595idObjects3= [];
gdjs.join_47hostCode.GDpasteObjects1= [];
gdjs.join_47hostCode.GDpasteObjects2= [];
gdjs.join_47hostCode.GDpasteObjects3= [];
gdjs.join_47hostCode.GDcopyObjects1= [];
gdjs.join_47hostCode.GDcopyObjects2= [];
gdjs.join_47hostCode.GDcopyObjects3= [];
gdjs.join_47hostCode.GDinfoObjects1= [];
gdjs.join_47hostCode.GDinfoObjects2= [];
gdjs.join_47hostCode.GDinfoObjects3= [];
gdjs.join_47hostCode.GDdebugObjects1= [];
gdjs.join_47hostCode.GDdebugObjects2= [];
gdjs.join_47hostCode.GDdebugObjects3= [];
gdjs.join_47hostCode.GDconnectObjects1= [];
gdjs.join_47hostCode.GDconnectObjects2= [];
gdjs.join_47hostCode.GDconnectObjects3= [];


gdjs.join_47hostCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("info"), gdjs.join_47hostCode.GDinfoObjects2);
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "HOST", 0, 0, 0);
}{for(var i = 0, len = gdjs.join_47hostCode.GDinfoObjects2.length ;i < len;++i) {
    gdjs.join_47hostCode.GDinfoObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.join_47hostCode.mapOfGDgdjs_9546join_959547hostCode_9546GDpasteObjects2Objects = Hashtable.newFrom({"paste": gdjs.join_47hostCode.GDpasteObjects2});
gdjs.join_47hostCode.mapOfGDgdjs_9546join_959547hostCode_9546GDbuttomObjects2Objects = Hashtable.newFrom({"buttom": gdjs.join_47hostCode.GDbuttomObjects2});
gdjs.join_47hostCode.mapOfGDgdjs_9546join_959547hostCode_9546GDconnectObjects1Objects = Hashtable.newFrom({"connect": gdjs.join_47hostCode.GDconnectObjects1});
gdjs.join_47hostCode.mapOfGDgdjs_9546join_959547hostCode_9546GDbuttomObjects1Objects = Hashtable.newFrom({"buttom": gdjs.join_47hostCode.GDbuttomObjects1});
gdjs.join_47hostCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("buttom"), gdjs.join_47hostCode.GDbuttomObjects2);
gdjs.copyArray(runtimeScene.getObjects("paste"), gdjs.join_47hostCode.GDpasteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.join_47hostCode.mapOfGDgdjs_9546join_959547hostCode_9546GDpasteObjects2Objects, gdjs.join_47hostCode.mapOfGDgdjs_9546join_959547hostCode_9546GDbuttomObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.join_47hostCode.GDbuttomObjects2 */
/* Reuse gdjs.join_47hostCode.GDpasteObjects2 */
{for(var i = 0, len = gdjs.join_47hostCode.GDbuttomObjects2.length ;i < len;++i) {
    gdjs.join_47hostCode.GDbuttomObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.join_47hostCode.GDpasteObjects2.length ;i < len;++i) {
    gdjs.join_47hostCode.GDpasteObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("buttom"), gdjs.join_47hostCode.GDbuttomObjects1);
gdjs.copyArray(runtimeScene.getObjects("connect"), gdjs.join_47hostCode.GDconnectObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.join_47hostCode.mapOfGDgdjs_9546join_959547hostCode_9546GDconnectObjects1Objects, gdjs.join_47hostCode.mapOfGDgdjs_9546join_959547hostCode_9546GDbuttomObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.join_47hostCode.GDbuttomObjects1 */
/* Reuse gdjs.join_47hostCode.GDconnectObjects1 */
{for(var i = 0, len = gdjs.join_47hostCode.GDconnectObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDconnectObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.join_47hostCode.GDbuttomObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDbuttomObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.join_47hostCode.mapOfGDgdjs_9546join_959547hostCode_9546GDcopyObjects1Objects = Hashtable.newFrom({"copy": gdjs.join_47hostCode.GDcopyObjects1});
gdjs.join_47hostCode.mapOfGDgdjs_9546join_959547hostCode_9546GDbuttomObjects1Objects = Hashtable.newFrom({"buttom": gdjs.join_47hostCode.GDbuttomObjects1});
gdjs.join_47hostCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("buttom"), gdjs.join_47hostCode.GDbuttomObjects1);
gdjs.copyArray(runtimeScene.getObjects("copy"), gdjs.join_47hostCode.GDcopyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.join_47hostCode.mapOfGDgdjs_9546join_959547hostCode_9546GDcopyObjects1Objects, gdjs.join_47hostCode.mapOfGDgdjs_9546join_959547hostCode_9546GDbuttomObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.join_47hostCode.GDbuttomObjects1 */
/* Reuse gdjs.join_47hostCode.GDcopyObjects1 */
{for(var i = 0, len = gdjs.join_47hostCode.GDbuttomObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDbuttomObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.join_47hostCode.GDcopyObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDcopyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.join_47hostCode.mapOfEmptyGDhostObjects = Hashtable.newFrom({"host": []});
gdjs.join_47hostCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.join_47hostCode.GDdebugObjects1 */
{for(var i = 0, len = gdjs.join_47hostCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDdebugObjects1[i].getBehavior("Text").setText(gdjs.join_47hostCode.GDdebugObjects1[i].getBehavior("Text").getText() + ("\nhello"));
}
}}

}


};gdjs.join_47hostCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.p2p.onConnection();
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.join_47hostCode.GDdebugObjects1, gdjs.join_47hostCode.GDdebugObjects2);

gdjs.copyArray(runtimeScene.getObjects("friends_id"), gdjs.join_47hostCode.GDfriends_9595idObjects2);
{for(var i = 0, len = gdjs.join_47hostCode.GDdebugObjects2.length ;i < len;++i) {
    gdjs.join_47hostCode.GDdebugObjects2[i].getBehavior("Text").setText(gdjs.join_47hostCode.GDdebugObjects2[i].getBehavior("Text").getText() + ("connected to " + (( gdjs.join_47hostCode.GDfriends_9595idObjects2.length === 0 ) ? "" :gdjs.join_47hostCode.GDfriends_9595idObjects2[0].getText())));
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.join_47hostCode.GDdebugObjects1 */
{for(var i = 0, len = gdjs.join_47hostCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDdebugObjects1[i].getBehavior("Text").setText(gdjs.join_47hostCode.GDdebugObjects1[i].getBehavior("Text").getText() + ("\nhello"));
}
}}

}


};gdjs.join_47hostCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.join_47hostCode.GDfriends_9595idObjects1, gdjs.join_47hostCode.GDfriends_9595idObjects2);

{gdjs.evtsExt__THNK_P2P__ConnectToServer.func(runtimeScene, (( gdjs.join_47hostCode.GDfriends_9595idObjects2.length === 0 ) ? "" :gdjs.join_47hostCode.GDfriends_9595idObjects2[0].getText()), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.join_47hostCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{



}


};gdjs.join_47hostCode.asyncCallback15625924 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.join_47hostCode.localVariables);

{ //Subevents
gdjs.join_47hostCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.join_47hostCode.localVariables.length = 0;
}
gdjs.join_47hostCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.join_47hostCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.join_47hostCode.asyncCallback15625924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.join_47hostCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ur_id"), gdjs.join_47hostCode.GDur_9595idObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.join_47hostCode.GDur_9595idObjects1.length;i<l;++i) {
    if ( !(gdjs.join_47hostCode.GDur_9595idObjects1[i].isReadOnly()) ) {
        isConditionTrue_0 = true;
        gdjs.join_47hostCode.GDur_9595idObjects1[k] = gdjs.join_47hostCode.GDur_9595idObjects1[i];
        ++k;
    }
}
gdjs.join_47hostCode.GDur_9595idObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.join_47hostCode.GDur_9595idObjects1 */
{for(var i = 0, len = gdjs.join_47hostCode.GDur_9595idObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDur_9595idObjects1[i].setReadOnly(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("JOIN"), gdjs.join_47hostCode.GDJOINObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.join_47hostCode.GDJOINObjects1.length;i<l;++i) {
    if ( gdjs.join_47hostCode.GDJOINObjects1[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.join_47hostCode.GDJOINObjects1[k] = gdjs.join_47hostCode.GDJOINObjects1[i];
        ++k;
    }
}
gdjs.join_47hostCode.GDJOINObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.join_47hostCode.GDJOINObjects1 */
gdjs.copyArray(runtimeScene.getObjects("buttom"), gdjs.join_47hostCode.GDbuttomObjects1);
gdjs.copyArray(runtimeScene.getObjects("host"), gdjs.join_47hostCode.GDhostObjects1);
{for(var i = 0, len = gdjs.join_47hostCode.GDhostObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDhostObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.join_47hostCode.GDJOINObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDJOINObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.join_47hostCode.GDbuttomObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDbuttomObjects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}
{ //Subevents
gdjs.join_47hostCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("friends_id"), gdjs.join_47hostCode.GDfriends_9595idObjects1);
{for(var i = 0, len = gdjs.join_47hostCode.GDfriends_9595idObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDfriends_9595idObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.join_47hostCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("info"), gdjs.join_47hostCode.GDinfoObjects1);
{for(var i = 0, len = gdjs.join_47hostCode.GDinfoObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDinfoObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.join_47hostCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ur_id"), gdjs.join_47hostCode.GDur_9595idObjects1);
{for(var i = 0, len = gdjs.join_47hostCode.GDur_9595idObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDur_9595idObjects1[i].getBehavior("Text").setText(gdjs.evtTools.p2p.getCurrentId());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ur_id"), gdjs.join_47hostCode.GDur_9595idObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen((( gdjs.join_47hostCode.GDur_9595idObjects1.length === 0 ) ? "" :gdjs.join_47hostCode.GDur_9595idObjects1[0].getText())) < 2);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.join_47hostCode.mapOfEmptyGDhostObjects) == 0;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.join_47hostCode.GDdebugObjects1);
{for(var i = 0, len = gdjs.join_47hostCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDdebugObjects1[i].getBehavior("Text").setText("error: can't get id make sure you have a proper internet connection or\n you are connected to a proper server");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ur_id"), gdjs.join_47hostCode.GDur_9595idObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen((( gdjs.join_47hostCode.GDur_9595idObjects1.length === 0 ) ? "" :gdjs.join_47hostCode.GDur_9595idObjects1[0].getText())) > 2);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.p2p.onConnection();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.join_47hostCode.GDdebugObjects1);
{for(var i = 0, len = gdjs.join_47hostCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDdebugObjects1[i].getBehavior("Text").setText("connected to server");
}
}{for(var i = 0, len = gdjs.join_47hostCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDdebugObjects1[i].setColor("126;211;33");
}
}{for(var i = 0, len = gdjs.join_47hostCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDdebugObjects1[i].getBehavior("Text").setText(gdjs.join_47hostCode.GDdebugObjects1[i].getBehavior("Text").getText() + (gdjs.evtTools.string.newLine() + "connected to " + gdjs.evtTools.p2p.getConnectedPeer()));
}
}
{ //Subevents
gdjs.join_47hostCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ur_id"), gdjs.join_47hostCode.GDur_9595idObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen((( gdjs.join_47hostCode.GDur_9595idObjects1.length === 0 ) ? "" :gdjs.join_47hostCode.GDur_9595idObjects1[0].getText())) > 2);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.p2p.onConnection());
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.join_47hostCode.GDdebugObjects1);
{for(var i = 0, len = gdjs.join_47hostCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDdebugObjects1[i].getBehavior("Text").setText("connected to server");
}
}{for(var i = 0, len = gdjs.join_47hostCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.join_47hostCode.GDdebugObjects1[i].setColor("126;211;33");
}
}
{ //Subevents
gdjs.join_47hostCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.p2p.isReady());
if (isConditionTrue_0) {
{gdjs.evtTools.p2p.useCustomBrokerServer("localhost", 9000, "/", "", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("connect"), gdjs.join_47hostCode.GDconnectObjects1);
gdjs.copyArray(runtimeScene.getObjects("friends_id"), gdjs.join_47hostCode.GDfriends_9595idObjects1);
gdjs.copyArray(runtimeScene.getObjects("ur_id"), gdjs.join_47hostCode.GDur_9595idObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.join_47hostCode.GDconnectObjects1.length;i<l;++i) {
    if ( gdjs.join_47hostCode.GDconnectObjects1[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.join_47hostCode.GDconnectObjects1[k] = gdjs.join_47hostCode.GDconnectObjects1[i];
        ++k;
    }
}
gdjs.join_47hostCode.GDconnectObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen((( gdjs.join_47hostCode.GDur_9595idObjects1.length === 0 ) ? "" :gdjs.join_47hostCode.GDur_9595idObjects1[0].getText())) > 2);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen((( gdjs.join_47hostCode.GDfriends_9595idObjects1.length === 0 ) ? "" :gdjs.join_47hostCode.GDfriends_9595idObjects1[0].getText())) > 5);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.join_47hostCode.GDfriends_9595idObjects1 */
{gdjs.evtTools.p2p.connect((( gdjs.join_47hostCode.GDfriends_9595idObjects1.length === 0 ) ? "" :gdjs.join_47hostCode.GDfriends_9595idObjects1[0].getText()));
}
{ //Subevents
gdjs.join_47hostCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("host"), gdjs.join_47hostCode.GDhostObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.join_47hostCode.GDhostObjects1.length;i<l;++i) {
    if ( gdjs.join_47hostCode.GDhostObjects1[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.join_47hostCode.GDhostObjects1[k] = gdjs.join_47hostCode.GDhostObjects1[i];
        ++k;
    }
}
gdjs.join_47hostCode.GDhostObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.p2p.isReady();
}
if (isConditionTrue_0) {
{gdjs.evtsExt__THNK_P2P__StartServer.func(runtimeScene, "multiplayer", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.join_47hostCode.eventsList7(runtimeScene);} //End of subevents
}

}


};

gdjs.join_47hostCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.join_47hostCode.GDbuttomObjects1.length = 0;
gdjs.join_47hostCode.GDbuttomObjects2.length = 0;
gdjs.join_47hostCode.GDbuttomObjects3.length = 0;
gdjs.join_47hostCode.GDhostObjects1.length = 0;
gdjs.join_47hostCode.GDhostObjects2.length = 0;
gdjs.join_47hostCode.GDhostObjects3.length = 0;
gdjs.join_47hostCode.GDJOINObjects1.length = 0;
gdjs.join_47hostCode.GDJOINObjects2.length = 0;
gdjs.join_47hostCode.GDJOINObjects3.length = 0;
gdjs.join_47hostCode.GDfriends_9595idObjects1.length = 0;
gdjs.join_47hostCode.GDfriends_9595idObjects2.length = 0;
gdjs.join_47hostCode.GDfriends_9595idObjects3.length = 0;
gdjs.join_47hostCode.GDur_9595idObjects1.length = 0;
gdjs.join_47hostCode.GDur_9595idObjects2.length = 0;
gdjs.join_47hostCode.GDur_9595idObjects3.length = 0;
gdjs.join_47hostCode.GDpasteObjects1.length = 0;
gdjs.join_47hostCode.GDpasteObjects2.length = 0;
gdjs.join_47hostCode.GDpasteObjects3.length = 0;
gdjs.join_47hostCode.GDcopyObjects1.length = 0;
gdjs.join_47hostCode.GDcopyObjects2.length = 0;
gdjs.join_47hostCode.GDcopyObjects3.length = 0;
gdjs.join_47hostCode.GDinfoObjects1.length = 0;
gdjs.join_47hostCode.GDinfoObjects2.length = 0;
gdjs.join_47hostCode.GDinfoObjects3.length = 0;
gdjs.join_47hostCode.GDdebugObjects1.length = 0;
gdjs.join_47hostCode.GDdebugObjects2.length = 0;
gdjs.join_47hostCode.GDdebugObjects3.length = 0;
gdjs.join_47hostCode.GDconnectObjects1.length = 0;
gdjs.join_47hostCode.GDconnectObjects2.length = 0;
gdjs.join_47hostCode.GDconnectObjects3.length = 0;

gdjs.join_47hostCode.eventsList8(runtimeScene);
gdjs.join_47hostCode.GDbuttomObjects1.length = 0;
gdjs.join_47hostCode.GDbuttomObjects2.length = 0;
gdjs.join_47hostCode.GDbuttomObjects3.length = 0;
gdjs.join_47hostCode.GDhostObjects1.length = 0;
gdjs.join_47hostCode.GDhostObjects2.length = 0;
gdjs.join_47hostCode.GDhostObjects3.length = 0;
gdjs.join_47hostCode.GDJOINObjects1.length = 0;
gdjs.join_47hostCode.GDJOINObjects2.length = 0;
gdjs.join_47hostCode.GDJOINObjects3.length = 0;
gdjs.join_47hostCode.GDfriends_9595idObjects1.length = 0;
gdjs.join_47hostCode.GDfriends_9595idObjects2.length = 0;
gdjs.join_47hostCode.GDfriends_9595idObjects3.length = 0;
gdjs.join_47hostCode.GDur_9595idObjects1.length = 0;
gdjs.join_47hostCode.GDur_9595idObjects2.length = 0;
gdjs.join_47hostCode.GDur_9595idObjects3.length = 0;
gdjs.join_47hostCode.GDpasteObjects1.length = 0;
gdjs.join_47hostCode.GDpasteObjects2.length = 0;
gdjs.join_47hostCode.GDpasteObjects3.length = 0;
gdjs.join_47hostCode.GDcopyObjects1.length = 0;
gdjs.join_47hostCode.GDcopyObjects2.length = 0;
gdjs.join_47hostCode.GDcopyObjects3.length = 0;
gdjs.join_47hostCode.GDinfoObjects1.length = 0;
gdjs.join_47hostCode.GDinfoObjects2.length = 0;
gdjs.join_47hostCode.GDinfoObjects3.length = 0;
gdjs.join_47hostCode.GDdebugObjects1.length = 0;
gdjs.join_47hostCode.GDdebugObjects2.length = 0;
gdjs.join_47hostCode.GDdebugObjects3.length = 0;
gdjs.join_47hostCode.GDconnectObjects1.length = 0;
gdjs.join_47hostCode.GDconnectObjects2.length = 0;
gdjs.join_47hostCode.GDconnectObjects3.length = 0;


return;

}

gdjs['join_47hostCode'] = gdjs.join_47hostCode;
