gdjs.levelsCode = {};
gdjs.levelsCode.localVariables = [];
gdjs.levelsCode.forEachIndex3 = 0;

gdjs.levelsCode.forEachObjects3 = [];

gdjs.levelsCode.forEachTemporary3 = null;

gdjs.levelsCode.forEachTotalCount3 = 0;

gdjs.levelsCode.GDsilver_9595coin_9595uiObjects1= [];
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects2= [];
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects3= [];
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects4= [];
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects5= [];
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects6= [];
gdjs.levelsCode.GDsilver_9595coin_9595countObjects1= [];
gdjs.levelsCode.GDsilver_9595coin_9595countObjects2= [];
gdjs.levelsCode.GDsilver_9595coin_9595countObjects3= [];
gdjs.levelsCode.GDsilver_9595coin_9595countObjects4= [];
gdjs.levelsCode.GDsilver_9595coin_9595countObjects5= [];
gdjs.levelsCode.GDsilver_9595coin_9595countObjects6= [];
gdjs.levelsCode.GDgold_9595coin_9595uiObjects1= [];
gdjs.levelsCode.GDgold_9595coin_9595uiObjects2= [];
gdjs.levelsCode.GDgold_9595coin_9595uiObjects3= [];
gdjs.levelsCode.GDgold_9595coin_9595uiObjects4= [];
gdjs.levelsCode.GDgold_9595coin_9595uiObjects5= [];
gdjs.levelsCode.GDgold_9595coin_9595uiObjects6= [];
gdjs.levelsCode.GDhealthObjects1= [];
gdjs.levelsCode.GDhealthObjects2= [];
gdjs.levelsCode.GDhealthObjects3= [];
gdjs.levelsCode.GDhealthObjects4= [];
gdjs.levelsCode.GDhealthObjects5= [];
gdjs.levelsCode.GDhealthObjects6= [];
gdjs.levelsCode.GDcharacterObjects1= [];
gdjs.levelsCode.GDcharacterObjects2= [];
gdjs.levelsCode.GDcharacterObjects3= [];
gdjs.levelsCode.GDcharacterObjects4= [];
gdjs.levelsCode.GDcharacterObjects5= [];
gdjs.levelsCode.GDcharacterObjects6= [];
gdjs.levelsCode.GDsandObjects1= [];
gdjs.levelsCode.GDsandObjects2= [];
gdjs.levelsCode.GDsandObjects3= [];
gdjs.levelsCode.GDsandObjects4= [];
gdjs.levelsCode.GDsandObjects5= [];
gdjs.levelsCode.GDsandObjects6= [];
gdjs.levelsCode.GDNewSpriteObjects1= [];
gdjs.levelsCode.GDNewSpriteObjects2= [];
gdjs.levelsCode.GDNewSpriteObjects3= [];
gdjs.levelsCode.GDNewSpriteObjects4= [];
gdjs.levelsCode.GDNewSpriteObjects5= [];
gdjs.levelsCode.GDNewSpriteObjects6= [];
gdjs.levelsCode.GDwaterObjects1= [];
gdjs.levelsCode.GDwaterObjects2= [];
gdjs.levelsCode.GDwaterObjects3= [];
gdjs.levelsCode.GDwaterObjects4= [];
gdjs.levelsCode.GDwaterObjects5= [];
gdjs.levelsCode.GDwaterObjects6= [];
gdjs.levelsCode.GDNewSprite2Objects1= [];
gdjs.levelsCode.GDNewSprite2Objects2= [];
gdjs.levelsCode.GDNewSprite2Objects3= [];
gdjs.levelsCode.GDNewSprite2Objects4= [];
gdjs.levelsCode.GDNewSprite2Objects5= [];
gdjs.levelsCode.GDNewSprite2Objects6= [];
gdjs.levelsCode.GDwater_9595Objects1= [];
gdjs.levelsCode.GDwater_9595Objects2= [];
gdjs.levelsCode.GDwater_9595Objects3= [];
gdjs.levelsCode.GDwater_9595Objects4= [];
gdjs.levelsCode.GDwater_9595Objects5= [];
gdjs.levelsCode.GDwater_9595Objects6= [];
gdjs.levelsCode.GDjust_9595an_9595objObjects1= [];
gdjs.levelsCode.GDjust_9595an_9595objObjects2= [];
gdjs.levelsCode.GDjust_9595an_9595objObjects3= [];
gdjs.levelsCode.GDjust_9595an_9595objObjects4= [];
gdjs.levelsCode.GDjust_9595an_9595objObjects5= [];
gdjs.levelsCode.GDjust_9595an_9595objObjects6= [];
gdjs.levelsCode.GDskyObjects1= [];
gdjs.levelsCode.GDskyObjects2= [];
gdjs.levelsCode.GDskyObjects3= [];
gdjs.levelsCode.GDskyObjects4= [];
gdjs.levelsCode.GDskyObjects5= [];
gdjs.levelsCode.GDskyObjects6= [];
gdjs.levelsCode.GDwood_9595logObjects1= [];
gdjs.levelsCode.GDwood_9595logObjects2= [];
gdjs.levelsCode.GDwood_9595logObjects3= [];
gdjs.levelsCode.GDwood_9595logObjects4= [];
gdjs.levelsCode.GDwood_9595logObjects5= [];
gdjs.levelsCode.GDwood_9595logObjects6= [];
gdjs.levelsCode.GDclonObjects1= [];
gdjs.levelsCode.GDclonObjects2= [];
gdjs.levelsCode.GDclonObjects3= [];
gdjs.levelsCode.GDclonObjects4= [];
gdjs.levelsCode.GDclonObjects5= [];
gdjs.levelsCode.GDclonObjects6= [];
gdjs.levelsCode.GDNewSprite3Objects1= [];
gdjs.levelsCode.GDNewSprite3Objects2= [];
gdjs.levelsCode.GDNewSprite3Objects3= [];
gdjs.levelsCode.GDNewSprite3Objects4= [];
gdjs.levelsCode.GDNewSprite3Objects5= [];
gdjs.levelsCode.GDNewSprite3Objects6= [];
gdjs.levelsCode.GDlifeObjects1= [];
gdjs.levelsCode.GDlifeObjects2= [];
gdjs.levelsCode.GDlifeObjects3= [];
gdjs.levelsCode.GDlifeObjects4= [];
gdjs.levelsCode.GDlifeObjects5= [];
gdjs.levelsCode.GDlifeObjects6= [];
gdjs.levelsCode.GDturnObjects1= [];
gdjs.levelsCode.GDturnObjects2= [];
gdjs.levelsCode.GDturnObjects3= [];
gdjs.levelsCode.GDturnObjects4= [];
gdjs.levelsCode.GDturnObjects5= [];
gdjs.levelsCode.GDturnObjects6= [];
gdjs.levelsCode.GDsurviverObjects1= [];
gdjs.levelsCode.GDsurviverObjects2= [];
gdjs.levelsCode.GDsurviverObjects3= [];
gdjs.levelsCode.GDsurviverObjects4= [];
gdjs.levelsCode.GDsurviverObjects5= [];
gdjs.levelsCode.GDsurviverObjects6= [];


gdjs.levelsCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("level")) < 1;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "level 1", 0, 0, 2);
}}

}


};gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDcharacterObjects3Objects = Hashtable.newFrom({"character": gdjs.levelsCode.GDcharacterObjects3});
gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDwater_95959595Objects3Objects = Hashtable.newFrom({"water_": gdjs.levelsCode.GDwater_9595Objects3});
gdjs.levelsCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{

gdjs.copyArray(asyncObjectsList.getObjects("character"), gdjs.levelsCode.GDcharacterObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("water_"), gdjs.levelsCode.GDwater_9595Objects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects4.length;i<l;++i) {
    if ( gdjs.levelsCode.GDcharacterObjects4[i].getY() > (( gdjs.levelsCode.GDwater_9595Objects4.length === 0 ) ? 0 :gdjs.levelsCode.GDwater_9595Objects4[0].getY()) + (gdjs.levelsCode.GDcharacterObjects4[i].getHeight()) - 3 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects4[k] = gdjs.levelsCode.GDcharacterObjects4[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDcharacterObjects4 */
{for(var i = 0, len = gdjs.levelsCode.GDcharacterObjects4.length ;i < len;++i) {
    gdjs.levelsCode.GDcharacterObjects4[i].returnVariable(gdjs.levelsCode.GDcharacterObjects4[i].getVariables().getFromIndex(0)).sub(100);
}
}}

}


};gdjs.levelsCode.asyncCallback15586652 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.levelsCode.localVariables);

{ //Subevents
gdjs.levelsCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.levelsCode.localVariables.length = 0;
}
gdjs.levelsCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.levelsCode.localVariables);
for (const obj of gdjs.levelsCode.GDcharacterObjects3) asyncObjectsList.addObject("character", obj);
for (const obj of gdjs.levelsCode.GDwater_9595Objects3) asyncObjectsList.addObject("water_", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.levelsCode.asyncCallback15586652(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDcharacterObjects3Objects = Hashtable.newFrom({"character": gdjs.levelsCode.GDcharacterObjects3});
gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDclonObjects3Objects = Hashtable.newFrom({"clon": gdjs.levelsCode.GDclonObjects3});
gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDcharacterObjects3Objects = Hashtable.newFrom({"character": gdjs.levelsCode.GDcharacterObjects3});
gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDlifeObjects3Objects = Hashtable.newFrom({"life": gdjs.levelsCode.GDlifeObjects3});
gdjs.levelsCode.eventsList3 = function(runtimeScene) {

};gdjs.levelsCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("character"), gdjs.levelsCode.GDcharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("water_"), gdjs.levelsCode.GDwater_9595Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDcharacterObjects3Objects, gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDwater_95959595Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.levelsCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("character"), gdjs.levelsCode.GDcharacterObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects3.length;i<l;++i) {
    if ( gdjs.levelsCode.GDcharacterObjects3[i].getVariableNumber(gdjs.levelsCode.GDcharacterObjects3[i].getVariables().getFromIndex(0)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects3[k] = gdjs.levelsCode.GDcharacterObjects3[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects3.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levels", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("character"), gdjs.levelsCode.GDcharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.levelsCode.GDclonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDcharacterObjects3Objects, gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDclonObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDclonObjects3.length;i<l;++i) {
    if ( gdjs.levelsCode.GDclonObjects3[i].getAnimationFrame() == 2 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDclonObjects3[k] = gdjs.levelsCode.GDclonObjects3[i];
        ++k;
    }
}
gdjs.levelsCode.GDclonObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15589052);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDcharacterObjects3 */
{for(var i = 0, len = gdjs.levelsCode.GDcharacterObjects3.length ;i < len;++i) {
    gdjs.levelsCode.GDcharacterObjects3[i].returnVariable(gdjs.levelsCode.GDcharacterObjects3[i].getVariables().getFromIndex(0)).sub(32);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("character"), gdjs.levelsCode.GDcharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("life"), gdjs.levelsCode.GDlifeObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDcharacterObjects3Objects, gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDlifeObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDcharacterObjects3 */
/* Reuse gdjs.levelsCode.GDlifeObjects3 */
{for(var i = 0, len = gdjs.levelsCode.GDcharacterObjects3.length ;i < len;++i) {
    gdjs.levelsCode.GDcharacterObjects3[i].returnVariable(gdjs.levelsCode.GDcharacterObjects3[i].getVariables().getFromIndex(0)).add(40);
}
}{for(var i = 0, len = gdjs.levelsCode.GDlifeObjects3.length ;i < len;++i) {
    gdjs.levelsCode.GDlifeObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "b");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("character"), gdjs.levelsCode.GDcharacterObjects3);
{for(var i = 0, len = gdjs.levelsCode.GDcharacterObjects3.length ;i < len;++i) {
    gdjs.levelsCode.GDcharacterObjects3[i].getBehavior("Animation").setAnimationName("fight");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.levelsCode.GDclonObjects2);

for (gdjs.levelsCode.forEachIndex3 = 0;gdjs.levelsCode.forEachIndex3 < gdjs.levelsCode.GDclonObjects2.length;++gdjs.levelsCode.forEachIndex3) {
gdjs.levelsCode.GDclonObjects3.length = 0;


gdjs.levelsCode.forEachTemporary3 = gdjs.levelsCode.GDclonObjects2[gdjs.levelsCode.forEachIndex3];
gdjs.levelsCode.GDclonObjects3.push(gdjs.levelsCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
}
}

}


};gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDcharacterObjects1Objects = Hashtable.newFrom({"character": gdjs.levelsCode.GDcharacterObjects1});
gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDclonObjects1Objects = Hashtable.newFrom({"clon": gdjs.levelsCode.GDclonObjects1});
gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDlifeObjects2Objects = Hashtable.newFrom({"life": gdjs.levelsCode.GDlifeObjects2});
gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDlifeObjects1Objects = Hashtable.newFrom({"life": gdjs.levelsCode.GDlifeObjects1});
gdjs.levelsCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.levelsCode.GDcharacterObjects1, gdjs.levelsCode.GDcharacterObjects2);

gdjs.copyArray(gdjs.levelsCode.GDclonObjects1, gdjs.levelsCode.GDclonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects2.length;i<l;++i) {
    if ( !(gdjs.levelsCode.GDcharacterObjects2[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects2[k] = gdjs.levelsCode.GDcharacterObjects2[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.levelsCode.GDcharacterObjects2.length === 0 ) ? 0 :gdjs.levelsCode.GDcharacterObjects2[0].getPointX("")) < (( gdjs.levelsCode.GDclonObjects2.length === 0 ) ? 0 :gdjs.levelsCode.GDclonObjects2[0].getPointX("")));
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDclonObjects2 */
gdjs.levelsCode.GDlifeObjects2.length = 0;

{for(var i = 0, len = gdjs.levelsCode.GDclonObjects2.length ;i < len;++i) {
    gdjs.levelsCode.GDclonObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDlifeObjects2Objects, (( gdjs.levelsCode.GDclonObjects2.length === 0 ) ? 0 :gdjs.levelsCode.GDclonObjects2[0].getPointX("")), (( gdjs.levelsCode.GDclonObjects2.length === 0 ) ? 0 :gdjs.levelsCode.GDclonObjects2[0].getPointY("")), "");
}}

}


{

/* Reuse gdjs.levelsCode.GDcharacterObjects1 */
/* Reuse gdjs.levelsCode.GDclonObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDcharacterObjects1[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects1[k] = gdjs.levelsCode.GDcharacterObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.levelsCode.GDcharacterObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDcharacterObjects1[0].getPointX("")) > (( gdjs.levelsCode.GDclonObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDclonObjects1[0].getPointX("")));
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDclonObjects1 */
gdjs.levelsCode.GDlifeObjects1.length = 0;

{for(var i = 0, len = gdjs.levelsCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDclonObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDlifeObjects1Objects, (( gdjs.levelsCode.GDclonObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDclonObjects1[0].getPointX("")), (( gdjs.levelsCode.GDclonObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDclonObjects1[0].getPointY("")), "");
}}

}


};gdjs.levelsCode.eventsList6 = function(runtimeScene) {

{


gdjs.levelsCode.eventsList4(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("character"), gdjs.levelsCode.GDcharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.levelsCode.GDclonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDcharacterObjects1Objects, gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDclonObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDcharacterObjects1[i].getBehavior("Animation").getAnimationName() == "fight" ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects1[k] = gdjs.levelsCode.GDcharacterObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDcharacterObjects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects1[k] = gdjs.levelsCode.GDcharacterObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects1.length = k;
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.levelsCode.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.levelsCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.levelsCode.GDcharacterObjects3, gdjs.levelsCode.GDcharacterObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects4.length;i<l;++i) {
    if ( gdjs.levelsCode.GDcharacterObjects4[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects4[k] = gdjs.levelsCode.GDcharacterObjects4[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDcharacterObjects4 */
{for(var i = 0, len = gdjs.levelsCode.GDcharacterObjects4.length ;i < len;++i) {
    gdjs.levelsCode.GDcharacterObjects4[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

/* Reuse gdjs.levelsCode.GDcharacterObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects3.length;i<l;++i) {
    if ( gdjs.levelsCode.GDcharacterObjects3[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects3[k] = gdjs.levelsCode.GDcharacterObjects3[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDcharacterObjects3 */
{for(var i = 0, len = gdjs.levelsCode.GDcharacterObjects3.length ;i < len;++i) {
    gdjs.levelsCode.GDcharacterObjects3[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.levelsCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.levelsCode.GDcharacterObjects2, gdjs.levelsCode.GDcharacterObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects3.length;i<l;++i) {
    if ( gdjs.levelsCode.GDcharacterObjects3[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects3[k] = gdjs.levelsCode.GDcharacterObjects3[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects3.length;i<l;++i) {
    if ( gdjs.levelsCode.GDcharacterObjects3[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects3[k] = gdjs.levelsCode.GDcharacterObjects3[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDcharacterObjects3 */
{for(var i = 0, len = gdjs.levelsCode.GDcharacterObjects3.length ;i < len;++i) {
    gdjs.levelsCode.GDcharacterObjects3[i].getBehavior("Animation").setAnimationName("run");
}
}
{ //Subevents
gdjs.levelsCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.levelsCode.GDcharacterObjects2, gdjs.levelsCode.GDcharacterObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects3.length;i<l;++i) {
    if ( gdjs.levelsCode.GDcharacterObjects3[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects3[k] = gdjs.levelsCode.GDcharacterObjects3[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDcharacterObjects3 */
{for(var i = 0, len = gdjs.levelsCode.GDcharacterObjects3.length ;i < len;++i) {
    gdjs.levelsCode.GDcharacterObjects3[i].getBehavior("Animation").setAnimationName("jump_start");
}
}}

}


{

gdjs.copyArray(gdjs.levelsCode.GDcharacterObjects2, gdjs.levelsCode.GDcharacterObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects3.length;i<l;++i) {
    if ( !(gdjs.levelsCode.GDcharacterObjects3[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects3[k] = gdjs.levelsCode.GDcharacterObjects3[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects3.length;i<l;++i) {
    if ( gdjs.levelsCode.GDcharacterObjects3[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects3[k] = gdjs.levelsCode.GDcharacterObjects3[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects3.length;i<l;++i) {
    if ( gdjs.levelsCode.GDcharacterObjects3[i].getBehavior("Animation").getAnimationName() == "fight" ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects3[k] = gdjs.levelsCode.GDcharacterObjects3[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDcharacterObjects3 */
{for(var i = 0, len = gdjs.levelsCode.GDcharacterObjects3.length ;i < len;++i) {
    gdjs.levelsCode.GDcharacterObjects3[i].getBehavior("Animation").setAnimationName("idle");
}
}}

}


{

/* Reuse gdjs.levelsCode.GDcharacterObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects2.length;i<l;++i) {
    if ( !(gdjs.levelsCode.GDcharacterObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects2[k] = gdjs.levelsCode.GDcharacterObjects2[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDcharacterObjects2.length;i<l;++i) {
    if ( !(gdjs.levelsCode.GDcharacterObjects2[i].getBehavior("Animation").getAnimationName() == "fight") ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDcharacterObjects2[k] = gdjs.levelsCode.GDcharacterObjects2[i];
        ++k;
    }
}
gdjs.levelsCode.GDcharacterObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.wasKeyReleased(runtimeScene, "b"));
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDcharacterObjects2 */
{for(var i = 0, len = gdjs.levelsCode.GDcharacterObjects2.length ;i < len;++i) {
    gdjs.levelsCode.GDcharacterObjects2[i].getBehavior("Animation").setAnimationName("idle");
}
}}

}


};gdjs.levelsCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("character"), gdjs.levelsCode.GDcharacterObjects2);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "camera_follow", (( gdjs.levelsCode.GDcharacterObjects2.length === 0 ) ? 0 :gdjs.levelsCode.GDcharacterObjects2[0].getPointX("")), (( gdjs.levelsCode.GDcharacterObjects2.length === 0 ) ? 0 :gdjs.levelsCode.GDcharacterObjects2[0].getPointY("")), "", "linear", 0.1);
}
{ //Subevents
gdjs.levelsCode.eventsList8(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("turn"), gdjs.levelsCode.GDturnObjects2);
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.levelsCode.GDwaterObjects2);
gdjs.copyArray(runtimeScene.getObjects("water_"), gdjs.levelsCode.GDwater_9595Objects2);
{gdjs.evtTools.tween.tweenCameraZoom2(runtimeScene, "camera zoom", 2, "", "easeInCubic", 1);
}{for(var i = 0, len = gdjs.levelsCode.GDwaterObjects2.length ;i < len;++i) {
    gdjs.levelsCode.GDwaterObjects2[i].getBehavior("Opacity").setOpacity(100);
}
}{for(var i = 0, len = gdjs.levelsCode.GDwater_9595Objects2.length ;i < len;++i) {
    gdjs.levelsCode.GDwater_9595Objects2[i].getBehavior("Opacity").setOpacity(100);
}
}{for(var i = 0, len = gdjs.levelsCode.GDwaterObjects2.length ;i < len;++i) {
    gdjs.levelsCode.GDwaterObjects2[i].returnVariable(gdjs.levelsCode.GDwaterObjects2[i].getVariables().getFromIndex(0)).setNumber((gdjs.levelsCode.GDwaterObjects2[i].getY()));
}
}{for(var i = 0, len = gdjs.levelsCode.GDwaterObjects2.length ;i < len;++i) {
    gdjs.levelsCode.GDwaterObjects2[i].resetTimer("wave");
}
}{for(var i = 0, len = gdjs.levelsCode.GDturnObjects2.length ;i < len;++i) {
    gdjs.levelsCode.GDturnObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("character"), gdjs.levelsCode.GDcharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("health"), gdjs.levelsCode.GDhealthObjects2);
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.levelsCode.GDwaterObjects2);
gdjs.copyArray(runtimeScene.getObjects("water_"), gdjs.levelsCode.GDwater_9595Objects2);
{for(var i = 0, len = gdjs.levelsCode.GDwaterObjects2.length ;i < len;++i) {
    gdjs.levelsCode.GDwaterObjects2[i].setXOffset(gdjs.levelsCode.GDwaterObjects2[i].getXOffset() - (1));
}
}{for(var i = 0, len = gdjs.levelsCode.GDwater_9595Objects2.length ;i < len;++i) {
    gdjs.levelsCode.GDwater_9595Objects2[i].setXOffset(gdjs.levelsCode.GDwater_9595Objects2[i].getXOffset() - (1));
}
}{for(var i = 0, len = gdjs.levelsCode.GDhealthObjects2.length ;i < len;++i) {
    gdjs.levelsCode.GDhealthObjects2[i].getBehavior("Resizable").setWidth(((gdjs.levelsCode.GDcharacterObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.levelsCode.GDcharacterObjects2[0].getVariables()).getFromIndex(0).getAsNumber());
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDclonObjects4Objects = Hashtable.newFrom({"clon": gdjs.levelsCode.GDclonObjects4});
gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDturnObjects4Objects = Hashtable.newFrom({"turn": gdjs.levelsCode.GDturnObjects4});
gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDturnObjects5Objects = Hashtable.newFrom({"turn": gdjs.levelsCode.GDturnObjects5});
gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDturnObjects5Objects = Hashtable.newFrom({"turn": gdjs.levelsCode.GDturnObjects5});
gdjs.levelsCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.levelsCode.GDclonObjects4, gdjs.levelsCode.GDclonObjects5);

gdjs.copyArray(gdjs.levelsCode.GDturnObjects4, gdjs.levelsCode.GDturnObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDturnObjects5Objects, (( gdjs.levelsCode.GDclonObjects5.length === 0 ) ? 0 :gdjs.levelsCode.GDclonObjects5[0].getPointX("")) + 16, (( gdjs.levelsCode.GDclonObjects5.length === 0 ) ? 0 :gdjs.levelsCode.GDclonObjects5[0].getPointY("")) + 8, 180, 10, gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, false);
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDclonObjects5 */
{for(var i = 0, len = gdjs.levelsCode.GDclonObjects5.length ;i < len;++i) {
    gdjs.levelsCode.GDclonObjects5[i].setVariableBoolean(gdjs.levelsCode.GDclonObjects5[i].getVariables().getFromIndex(0), true);
}
}}

}


{

gdjs.copyArray(gdjs.levelsCode.GDclonObjects4, gdjs.levelsCode.GDclonObjects5);

gdjs.copyArray(gdjs.levelsCode.GDturnObjects4, gdjs.levelsCode.GDturnObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDturnObjects5Objects, (( gdjs.levelsCode.GDclonObjects5.length === 0 ) ? 0 :gdjs.levelsCode.GDclonObjects5[0].getPointX("")), (( gdjs.levelsCode.GDclonObjects5.length === 0 ) ? 0 :gdjs.levelsCode.GDclonObjects5[0].getPointY("")) + 8, 180, 10, gdjs.VariablesContainer.badVariable, gdjs.VariablesContainer.badVariable, false);
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDclonObjects5 */
{for(var i = 0, len = gdjs.levelsCode.GDclonObjects5.length ;i < len;++i) {
    gdjs.levelsCode.GDclonObjects5[i].setVariableBoolean(gdjs.levelsCode.GDclonObjects5[i].getVariables().getFromIndex(0), false);
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.levelsCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.levelsCode.GDclonObjects3, gdjs.levelsCode.GDclonObjects4);

gdjs.copyArray(runtimeScene.getObjects("turn"), gdjs.levelsCode.GDturnObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDclonObjects4Objects, gdjs.levelsCode.mapOfGDgdjs_9546levelsCode_9546GDturnObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.levelsCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.levelsCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.levelsCode.GDclonObjects2);

for (gdjs.levelsCode.forEachIndex3 = 0;gdjs.levelsCode.forEachIndex3 < gdjs.levelsCode.GDclonObjects2.length;++gdjs.levelsCode.forEachIndex3) {
gdjs.levelsCode.GDclonObjects3.length = 0;


gdjs.levelsCode.forEachTemporary3 = gdjs.levelsCode.GDclonObjects2[gdjs.levelsCode.forEachIndex3];
gdjs.levelsCode.GDclonObjects3.push(gdjs.levelsCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.levelsCode.eventsList11(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.levelsCode.GDclonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDclonObjects2.length;i<l;++i) {
    if ( gdjs.levelsCode.GDclonObjects2[i].getVariableBoolean(gdjs.levelsCode.GDclonObjects2[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDclonObjects2[k] = gdjs.levelsCode.GDclonObjects2[i];
        ++k;
    }
}
gdjs.levelsCode.GDclonObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDclonObjects2 */
{for(var i = 0, len = gdjs.levelsCode.GDclonObjects2.length ;i < len;++i) {
    gdjs.levelsCode.GDclonObjects2[i].addPolarForce(180, 8, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.levelsCode.GDclonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDclonObjects2.length;i<l;++i) {
    if ( gdjs.levelsCode.GDclonObjects2[i].getVariableBoolean(gdjs.levelsCode.GDclonObjects2[i].getVariables().getFromIndex(0), false) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDclonObjects2[k] = gdjs.levelsCode.GDclonObjects2[i];
        ++k;
    }
}
gdjs.levelsCode.GDclonObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDclonObjects2 */
{for(var i = 0, len = gdjs.levelsCode.GDclonObjects2.length ;i < len;++i) {
    gdjs.levelsCode.GDclonObjects2[i].addPolarForce(0, 8, 0);
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.levelsCode.eventsList13 = function(runtimeScene) {

{



}


};gdjs.levelsCode.eventsList14 = function(runtimeScene) {

{


gdjs.levelsCode.eventsList0(runtimeScene);
}


{


gdjs.levelsCode.eventsList6(runtimeScene);
}


{


gdjs.levelsCode.eventsList9(runtimeScene);
}


{


gdjs.levelsCode.eventsList12(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15615404);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.levelsCode.eventsList13(runtimeScene);} //End of subevents
}

}


};

gdjs.levelsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.levelsCode.GDsilver_9595coin_9595uiObjects1.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects2.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects3.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects4.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects5.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects6.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595countObjects1.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595countObjects2.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595countObjects3.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595countObjects4.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595countObjects5.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595countObjects6.length = 0;
gdjs.levelsCode.GDgold_9595coin_9595uiObjects1.length = 0;
gdjs.levelsCode.GDgold_9595coin_9595uiObjects2.length = 0;
gdjs.levelsCode.GDgold_9595coin_9595uiObjects3.length = 0;
gdjs.levelsCode.GDgold_9595coin_9595uiObjects4.length = 0;
gdjs.levelsCode.GDgold_9595coin_9595uiObjects5.length = 0;
gdjs.levelsCode.GDgold_9595coin_9595uiObjects6.length = 0;
gdjs.levelsCode.GDhealthObjects1.length = 0;
gdjs.levelsCode.GDhealthObjects2.length = 0;
gdjs.levelsCode.GDhealthObjects3.length = 0;
gdjs.levelsCode.GDhealthObjects4.length = 0;
gdjs.levelsCode.GDhealthObjects5.length = 0;
gdjs.levelsCode.GDhealthObjects6.length = 0;
gdjs.levelsCode.GDcharacterObjects1.length = 0;
gdjs.levelsCode.GDcharacterObjects2.length = 0;
gdjs.levelsCode.GDcharacterObjects3.length = 0;
gdjs.levelsCode.GDcharacterObjects4.length = 0;
gdjs.levelsCode.GDcharacterObjects5.length = 0;
gdjs.levelsCode.GDcharacterObjects6.length = 0;
gdjs.levelsCode.GDsandObjects1.length = 0;
gdjs.levelsCode.GDsandObjects2.length = 0;
gdjs.levelsCode.GDsandObjects3.length = 0;
gdjs.levelsCode.GDsandObjects4.length = 0;
gdjs.levelsCode.GDsandObjects5.length = 0;
gdjs.levelsCode.GDsandObjects6.length = 0;
gdjs.levelsCode.GDNewSpriteObjects1.length = 0;
gdjs.levelsCode.GDNewSpriteObjects2.length = 0;
gdjs.levelsCode.GDNewSpriteObjects3.length = 0;
gdjs.levelsCode.GDNewSpriteObjects4.length = 0;
gdjs.levelsCode.GDNewSpriteObjects5.length = 0;
gdjs.levelsCode.GDNewSpriteObjects6.length = 0;
gdjs.levelsCode.GDwaterObjects1.length = 0;
gdjs.levelsCode.GDwaterObjects2.length = 0;
gdjs.levelsCode.GDwaterObjects3.length = 0;
gdjs.levelsCode.GDwaterObjects4.length = 0;
gdjs.levelsCode.GDwaterObjects5.length = 0;
gdjs.levelsCode.GDwaterObjects6.length = 0;
gdjs.levelsCode.GDNewSprite2Objects1.length = 0;
gdjs.levelsCode.GDNewSprite2Objects2.length = 0;
gdjs.levelsCode.GDNewSprite2Objects3.length = 0;
gdjs.levelsCode.GDNewSprite2Objects4.length = 0;
gdjs.levelsCode.GDNewSprite2Objects5.length = 0;
gdjs.levelsCode.GDNewSprite2Objects6.length = 0;
gdjs.levelsCode.GDwater_9595Objects1.length = 0;
gdjs.levelsCode.GDwater_9595Objects2.length = 0;
gdjs.levelsCode.GDwater_9595Objects3.length = 0;
gdjs.levelsCode.GDwater_9595Objects4.length = 0;
gdjs.levelsCode.GDwater_9595Objects5.length = 0;
gdjs.levelsCode.GDwater_9595Objects6.length = 0;
gdjs.levelsCode.GDjust_9595an_9595objObjects1.length = 0;
gdjs.levelsCode.GDjust_9595an_9595objObjects2.length = 0;
gdjs.levelsCode.GDjust_9595an_9595objObjects3.length = 0;
gdjs.levelsCode.GDjust_9595an_9595objObjects4.length = 0;
gdjs.levelsCode.GDjust_9595an_9595objObjects5.length = 0;
gdjs.levelsCode.GDjust_9595an_9595objObjects6.length = 0;
gdjs.levelsCode.GDskyObjects1.length = 0;
gdjs.levelsCode.GDskyObjects2.length = 0;
gdjs.levelsCode.GDskyObjects3.length = 0;
gdjs.levelsCode.GDskyObjects4.length = 0;
gdjs.levelsCode.GDskyObjects5.length = 0;
gdjs.levelsCode.GDskyObjects6.length = 0;
gdjs.levelsCode.GDwood_9595logObjects1.length = 0;
gdjs.levelsCode.GDwood_9595logObjects2.length = 0;
gdjs.levelsCode.GDwood_9595logObjects3.length = 0;
gdjs.levelsCode.GDwood_9595logObjects4.length = 0;
gdjs.levelsCode.GDwood_9595logObjects5.length = 0;
gdjs.levelsCode.GDwood_9595logObjects6.length = 0;
gdjs.levelsCode.GDclonObjects1.length = 0;
gdjs.levelsCode.GDclonObjects2.length = 0;
gdjs.levelsCode.GDclonObjects3.length = 0;
gdjs.levelsCode.GDclonObjects4.length = 0;
gdjs.levelsCode.GDclonObjects5.length = 0;
gdjs.levelsCode.GDclonObjects6.length = 0;
gdjs.levelsCode.GDNewSprite3Objects1.length = 0;
gdjs.levelsCode.GDNewSprite3Objects2.length = 0;
gdjs.levelsCode.GDNewSprite3Objects3.length = 0;
gdjs.levelsCode.GDNewSprite3Objects4.length = 0;
gdjs.levelsCode.GDNewSprite3Objects5.length = 0;
gdjs.levelsCode.GDNewSprite3Objects6.length = 0;
gdjs.levelsCode.GDlifeObjects1.length = 0;
gdjs.levelsCode.GDlifeObjects2.length = 0;
gdjs.levelsCode.GDlifeObjects3.length = 0;
gdjs.levelsCode.GDlifeObjects4.length = 0;
gdjs.levelsCode.GDlifeObjects5.length = 0;
gdjs.levelsCode.GDlifeObjects6.length = 0;
gdjs.levelsCode.GDturnObjects1.length = 0;
gdjs.levelsCode.GDturnObjects2.length = 0;
gdjs.levelsCode.GDturnObjects3.length = 0;
gdjs.levelsCode.GDturnObjects4.length = 0;
gdjs.levelsCode.GDturnObjects5.length = 0;
gdjs.levelsCode.GDturnObjects6.length = 0;
gdjs.levelsCode.GDsurviverObjects1.length = 0;
gdjs.levelsCode.GDsurviverObjects2.length = 0;
gdjs.levelsCode.GDsurviverObjects3.length = 0;
gdjs.levelsCode.GDsurviverObjects4.length = 0;
gdjs.levelsCode.GDsurviverObjects5.length = 0;
gdjs.levelsCode.GDsurviverObjects6.length = 0;

gdjs.levelsCode.eventsList14(runtimeScene);
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects1.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects2.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects3.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects4.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects5.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595uiObjects6.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595countObjects1.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595countObjects2.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595countObjects3.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595countObjects4.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595countObjects5.length = 0;
gdjs.levelsCode.GDsilver_9595coin_9595countObjects6.length = 0;
gdjs.levelsCode.GDgold_9595coin_9595uiObjects1.length = 0;
gdjs.levelsCode.GDgold_9595coin_9595uiObjects2.length = 0;
gdjs.levelsCode.GDgold_9595coin_9595uiObjects3.length = 0;
gdjs.levelsCode.GDgold_9595coin_9595uiObjects4.length = 0;
gdjs.levelsCode.GDgold_9595coin_9595uiObjects5.length = 0;
gdjs.levelsCode.GDgold_9595coin_9595uiObjects6.length = 0;
gdjs.levelsCode.GDhealthObjects1.length = 0;
gdjs.levelsCode.GDhealthObjects2.length = 0;
gdjs.levelsCode.GDhealthObjects3.length = 0;
gdjs.levelsCode.GDhealthObjects4.length = 0;
gdjs.levelsCode.GDhealthObjects5.length = 0;
gdjs.levelsCode.GDhealthObjects6.length = 0;
gdjs.levelsCode.GDcharacterObjects1.length = 0;
gdjs.levelsCode.GDcharacterObjects2.length = 0;
gdjs.levelsCode.GDcharacterObjects3.length = 0;
gdjs.levelsCode.GDcharacterObjects4.length = 0;
gdjs.levelsCode.GDcharacterObjects5.length = 0;
gdjs.levelsCode.GDcharacterObjects6.length = 0;
gdjs.levelsCode.GDsandObjects1.length = 0;
gdjs.levelsCode.GDsandObjects2.length = 0;
gdjs.levelsCode.GDsandObjects3.length = 0;
gdjs.levelsCode.GDsandObjects4.length = 0;
gdjs.levelsCode.GDsandObjects5.length = 0;
gdjs.levelsCode.GDsandObjects6.length = 0;
gdjs.levelsCode.GDNewSpriteObjects1.length = 0;
gdjs.levelsCode.GDNewSpriteObjects2.length = 0;
gdjs.levelsCode.GDNewSpriteObjects3.length = 0;
gdjs.levelsCode.GDNewSpriteObjects4.length = 0;
gdjs.levelsCode.GDNewSpriteObjects5.length = 0;
gdjs.levelsCode.GDNewSpriteObjects6.length = 0;
gdjs.levelsCode.GDwaterObjects1.length = 0;
gdjs.levelsCode.GDwaterObjects2.length = 0;
gdjs.levelsCode.GDwaterObjects3.length = 0;
gdjs.levelsCode.GDwaterObjects4.length = 0;
gdjs.levelsCode.GDwaterObjects5.length = 0;
gdjs.levelsCode.GDwaterObjects6.length = 0;
gdjs.levelsCode.GDNewSprite2Objects1.length = 0;
gdjs.levelsCode.GDNewSprite2Objects2.length = 0;
gdjs.levelsCode.GDNewSprite2Objects3.length = 0;
gdjs.levelsCode.GDNewSprite2Objects4.length = 0;
gdjs.levelsCode.GDNewSprite2Objects5.length = 0;
gdjs.levelsCode.GDNewSprite2Objects6.length = 0;
gdjs.levelsCode.GDwater_9595Objects1.length = 0;
gdjs.levelsCode.GDwater_9595Objects2.length = 0;
gdjs.levelsCode.GDwater_9595Objects3.length = 0;
gdjs.levelsCode.GDwater_9595Objects4.length = 0;
gdjs.levelsCode.GDwater_9595Objects5.length = 0;
gdjs.levelsCode.GDwater_9595Objects6.length = 0;
gdjs.levelsCode.GDjust_9595an_9595objObjects1.length = 0;
gdjs.levelsCode.GDjust_9595an_9595objObjects2.length = 0;
gdjs.levelsCode.GDjust_9595an_9595objObjects3.length = 0;
gdjs.levelsCode.GDjust_9595an_9595objObjects4.length = 0;
gdjs.levelsCode.GDjust_9595an_9595objObjects5.length = 0;
gdjs.levelsCode.GDjust_9595an_9595objObjects6.length = 0;
gdjs.levelsCode.GDskyObjects1.length = 0;
gdjs.levelsCode.GDskyObjects2.length = 0;
gdjs.levelsCode.GDskyObjects3.length = 0;
gdjs.levelsCode.GDskyObjects4.length = 0;
gdjs.levelsCode.GDskyObjects5.length = 0;
gdjs.levelsCode.GDskyObjects6.length = 0;
gdjs.levelsCode.GDwood_9595logObjects1.length = 0;
gdjs.levelsCode.GDwood_9595logObjects2.length = 0;
gdjs.levelsCode.GDwood_9595logObjects3.length = 0;
gdjs.levelsCode.GDwood_9595logObjects4.length = 0;
gdjs.levelsCode.GDwood_9595logObjects5.length = 0;
gdjs.levelsCode.GDwood_9595logObjects6.length = 0;
gdjs.levelsCode.GDclonObjects1.length = 0;
gdjs.levelsCode.GDclonObjects2.length = 0;
gdjs.levelsCode.GDclonObjects3.length = 0;
gdjs.levelsCode.GDclonObjects4.length = 0;
gdjs.levelsCode.GDclonObjects5.length = 0;
gdjs.levelsCode.GDclonObjects6.length = 0;
gdjs.levelsCode.GDNewSprite3Objects1.length = 0;
gdjs.levelsCode.GDNewSprite3Objects2.length = 0;
gdjs.levelsCode.GDNewSprite3Objects3.length = 0;
gdjs.levelsCode.GDNewSprite3Objects4.length = 0;
gdjs.levelsCode.GDNewSprite3Objects5.length = 0;
gdjs.levelsCode.GDNewSprite3Objects6.length = 0;
gdjs.levelsCode.GDlifeObjects1.length = 0;
gdjs.levelsCode.GDlifeObjects2.length = 0;
gdjs.levelsCode.GDlifeObjects3.length = 0;
gdjs.levelsCode.GDlifeObjects4.length = 0;
gdjs.levelsCode.GDlifeObjects5.length = 0;
gdjs.levelsCode.GDlifeObjects6.length = 0;
gdjs.levelsCode.GDturnObjects1.length = 0;
gdjs.levelsCode.GDturnObjects2.length = 0;
gdjs.levelsCode.GDturnObjects3.length = 0;
gdjs.levelsCode.GDturnObjects4.length = 0;
gdjs.levelsCode.GDturnObjects5.length = 0;
gdjs.levelsCode.GDturnObjects6.length = 0;
gdjs.levelsCode.GDsurviverObjects1.length = 0;
gdjs.levelsCode.GDsurviverObjects2.length = 0;
gdjs.levelsCode.GDsurviverObjects3.length = 0;
gdjs.levelsCode.GDsurviverObjects4.length = 0;
gdjs.levelsCode.GDsurviverObjects5.length = 0;
gdjs.levelsCode.GDsurviverObjects6.length = 0;


return;

}

gdjs['levelsCode'] = gdjs.levelsCode;
