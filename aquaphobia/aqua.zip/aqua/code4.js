gdjs.shopCode = {};
gdjs.shopCode.localVariables = [];
gdjs.shopCode.GDNewSpriteObjects1= [];
gdjs.shopCode.GDNewSpriteObjects2= [];
gdjs.shopCode.GDrifleObjects1= [];
gdjs.shopCode.GDrifleObjects2= [];
gdjs.shopCode.GDprotectorObjects1= [];
gdjs.shopCode.GDprotectorObjects2= [];
gdjs.shopCode.GDrifle2Objects1= [];
gdjs.shopCode.GDrifle2Objects2= [];
gdjs.shopCode.GDdroneObjects1= [];
gdjs.shopCode.GDdroneObjects2= [];
gdjs.shopCode.GDsubcribeObjects1= [];
gdjs.shopCode.GDsubcribeObjects2= [];
gdjs.shopCode.GDSHINEObjects1= [];
gdjs.shopCode.GDSHINEObjects2= [];
gdjs.shopCode.GDyellowObjects1= [];
gdjs.shopCode.GDyellowObjects2= [];
gdjs.shopCode.GDhealth_9595kitObjects1= [];
gdjs.shopCode.GDhealth_9595kitObjects2= [];
gdjs.shopCode.GDpriceObjects1= [];
gdjs.shopCode.GDpriceObjects2= [];
gdjs.shopCode.GDbackObjects1= [];
gdjs.shopCode.GDbackObjects2= [];
gdjs.shopCode.GDNewSprite2Objects1= [];
gdjs.shopCode.GDNewSprite2Objects2= [];
gdjs.shopCode.GDNewTiledSpriteObjects1= [];
gdjs.shopCode.GDNewTiledSpriteObjects2= [];
gdjs.shopCode.GDshop_9595backObjects1= [];
gdjs.shopCode.GDshop_9595backObjects2= [];


gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDpriceObjects1Objects = Hashtable.newFrom({"price": gdjs.shopCode.GDpriceObjects1});
gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDrifle2Objects1Objects = Hashtable.newFrom({"rifle2": gdjs.shopCode.GDrifle2Objects1});
gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDpriceObjects1Objects = Hashtable.newFrom({"price": gdjs.shopCode.GDpriceObjects1});
gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDhealth_95959595kitObjects1Objects = Hashtable.newFrom({"health_kit": gdjs.shopCode.GDhealth_9595kitObjects1});
gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDpriceObjects1Objects = Hashtable.newFrom({"price": gdjs.shopCode.GDpriceObjects1});
gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDprotectorObjects1Objects = Hashtable.newFrom({"protector": gdjs.shopCode.GDprotectorObjects1});
gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDpriceObjects1Objects = Hashtable.newFrom({"price": gdjs.shopCode.GDpriceObjects1});
gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDdroneObjects1Objects = Hashtable.newFrom({"drone": gdjs.shopCode.GDdroneObjects1});
gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDsubcribeObjects1Objects = Hashtable.newFrom({"subcribe": gdjs.shopCode.GDsubcribeObjects1});
gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDbackObjects1Objects = Hashtable.newFrom({"back": gdjs.shopCode.GDbackObjects1});
gdjs.shopCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level select", true);
}}

}


};gdjs.shopCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("SHINE"), gdjs.shopCode.GDSHINEObjects1);
{for(var i = 0, len = gdjs.shopCode.GDSHINEObjects1.length ;i < len;++i) {
    gdjs.shopCode.GDSHINEObjects1[i].setXOffset(gdjs.shopCode.GDSHINEObjects1[i].getXOffset() - (1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("price"), gdjs.shopCode.GDpriceObjects1);
gdjs.copyArray(runtimeScene.getObjects("rifle2"), gdjs.shopCode.GDrifle2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDpriceObjects1Objects, gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDrifle2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.shopCode.GDpriceObjects1 */
{for(var i = 0, len = gdjs.shopCode.GDpriceObjects1.length ;i < len;++i) {
    gdjs.shopCode.GDpriceObjects1[i].getBehavior("Text").setText("1000$");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("health_kit"), gdjs.shopCode.GDhealth_9595kitObjects1);
gdjs.copyArray(runtimeScene.getObjects("price"), gdjs.shopCode.GDpriceObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDpriceObjects1Objects, gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDhealth_95959595kitObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.shopCode.GDpriceObjects1 */
{for(var i = 0, len = gdjs.shopCode.GDpriceObjects1.length ;i < len;++i) {
    gdjs.shopCode.GDpriceObjects1[i].getBehavior("Text").setText("100$");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("price"), gdjs.shopCode.GDpriceObjects1);
gdjs.copyArray(runtimeScene.getObjects("protector"), gdjs.shopCode.GDprotectorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDpriceObjects1Objects, gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDprotectorObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.shopCode.GDpriceObjects1 */
{for(var i = 0, len = gdjs.shopCode.GDpriceObjects1.length ;i < len;++i) {
    gdjs.shopCode.GDpriceObjects1[i].getBehavior("Text").setText("25$");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("drone"), gdjs.shopCode.GDdroneObjects1);
gdjs.copyArray(runtimeScene.getObjects("price"), gdjs.shopCode.GDpriceObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDpriceObjects1Objects, gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDdroneObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.shopCode.GDpriceObjects1 */
{for(var i = 0, len = gdjs.shopCode.GDpriceObjects1.length ;i < len;++i) {
    gdjs.shopCode.GDpriceObjects1[i].getBehavior("Text").setText("100$");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SHINE"), gdjs.shopCode.GDSHINEObjects1);
{for(var i = 0, len = gdjs.shopCode.GDSHINEObjects1.length ;i < len;++i) {
    gdjs.shopCode.GDSHINEObjects1[i].getBehavior("Opacity").setOpacity(100);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("subcribe"), gdjs.shopCode.GDsubcribeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDsubcribeObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "activ");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.shopCode.GDbackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.shopCode.mapOfGDgdjs_9546shopCode_9546GDbackObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}
{ //Subevents
gdjs.shopCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.shopCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.shopCode.GDNewSpriteObjects1.length = 0;
gdjs.shopCode.GDNewSpriteObjects2.length = 0;
gdjs.shopCode.GDrifleObjects1.length = 0;
gdjs.shopCode.GDrifleObjects2.length = 0;
gdjs.shopCode.GDprotectorObjects1.length = 0;
gdjs.shopCode.GDprotectorObjects2.length = 0;
gdjs.shopCode.GDrifle2Objects1.length = 0;
gdjs.shopCode.GDrifle2Objects2.length = 0;
gdjs.shopCode.GDdroneObjects1.length = 0;
gdjs.shopCode.GDdroneObjects2.length = 0;
gdjs.shopCode.GDsubcribeObjects1.length = 0;
gdjs.shopCode.GDsubcribeObjects2.length = 0;
gdjs.shopCode.GDSHINEObjects1.length = 0;
gdjs.shopCode.GDSHINEObjects2.length = 0;
gdjs.shopCode.GDyellowObjects1.length = 0;
gdjs.shopCode.GDyellowObjects2.length = 0;
gdjs.shopCode.GDhealth_9595kitObjects1.length = 0;
gdjs.shopCode.GDhealth_9595kitObjects2.length = 0;
gdjs.shopCode.GDpriceObjects1.length = 0;
gdjs.shopCode.GDpriceObjects2.length = 0;
gdjs.shopCode.GDbackObjects1.length = 0;
gdjs.shopCode.GDbackObjects2.length = 0;
gdjs.shopCode.GDNewSprite2Objects1.length = 0;
gdjs.shopCode.GDNewSprite2Objects2.length = 0;
gdjs.shopCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.shopCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.shopCode.GDshop_9595backObjects1.length = 0;
gdjs.shopCode.GDshop_9595backObjects2.length = 0;

gdjs.shopCode.eventsList1(runtimeScene);
gdjs.shopCode.GDNewSpriteObjects1.length = 0;
gdjs.shopCode.GDNewSpriteObjects2.length = 0;
gdjs.shopCode.GDrifleObjects1.length = 0;
gdjs.shopCode.GDrifleObjects2.length = 0;
gdjs.shopCode.GDprotectorObjects1.length = 0;
gdjs.shopCode.GDprotectorObjects2.length = 0;
gdjs.shopCode.GDrifle2Objects1.length = 0;
gdjs.shopCode.GDrifle2Objects2.length = 0;
gdjs.shopCode.GDdroneObjects1.length = 0;
gdjs.shopCode.GDdroneObjects2.length = 0;
gdjs.shopCode.GDsubcribeObjects1.length = 0;
gdjs.shopCode.GDsubcribeObjects2.length = 0;
gdjs.shopCode.GDSHINEObjects1.length = 0;
gdjs.shopCode.GDSHINEObjects2.length = 0;
gdjs.shopCode.GDyellowObjects1.length = 0;
gdjs.shopCode.GDyellowObjects2.length = 0;
gdjs.shopCode.GDhealth_9595kitObjects1.length = 0;
gdjs.shopCode.GDhealth_9595kitObjects2.length = 0;
gdjs.shopCode.GDpriceObjects1.length = 0;
gdjs.shopCode.GDpriceObjects2.length = 0;
gdjs.shopCode.GDbackObjects1.length = 0;
gdjs.shopCode.GDbackObjects2.length = 0;
gdjs.shopCode.GDNewSprite2Objects1.length = 0;
gdjs.shopCode.GDNewSprite2Objects2.length = 0;
gdjs.shopCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.shopCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.shopCode.GDshop_9595backObjects1.length = 0;
gdjs.shopCode.GDshop_9595backObjects2.length = 0;


return;

}

gdjs['shopCode'] = gdjs.shopCode;
