gdjs.level_32selectCode = {};
gdjs.level_32selectCode.localVariables = [];
gdjs.level_32selectCode.GDaquaphobiaObjects1= [];
gdjs.level_32selectCode.GDaquaphobiaObjects2= [];
gdjs.level_32selectCode.GDplayObjects1= [];
gdjs.level_32selectCode.GDplayObjects2= [];
gdjs.level_32selectCode.GDbuttonObjects1= [];
gdjs.level_32selectCode.GDbuttonObjects2= [];
gdjs.level_32selectCode.GDbackObjects1= [];
gdjs.level_32selectCode.GDbackObjects2= [];
gdjs.level_32selectCode.GDwaterObjects1= [];
gdjs.level_32selectCode.GDwaterObjects2= [];
gdjs.level_32selectCode.GDplayer1Objects1= [];
gdjs.level_32selectCode.GDplayer1Objects2= [];
gdjs.level_32selectCode.GDcement_9595block_9595blueObjects1= [];
gdjs.level_32selectCode.GDcement_9595block_9595blueObjects2= [];
gdjs.level_32selectCode.GDwater_9595particleesObjects1= [];
gdjs.level_32selectCode.GDwater_9595particleesObjects2= [];
gdjs.level_32selectCode.GDcement_9595block_9595blue_9595sideObjects1= [];
gdjs.level_32selectCode.GDcement_9595block_9595blue_9595sideObjects2= [];
gdjs.level_32selectCode.GDwater_9595particlees2Objects1= [];
gdjs.level_32selectCode.GDwater_9595particlees2Objects2= [];
gdjs.level_32selectCode.GDrifleObjects1= [];
gdjs.level_32selectCode.GDrifleObjects2= [];
gdjs.level_32selectCode.GDshopObjects1= [];
gdjs.level_32selectCode.GDshopObjects2= [];
gdjs.level_32selectCode.GDmultiplayerObjects1= [];
gdjs.level_32selectCode.GDmultiplayerObjects2= [];


gdjs.level_32selectCode.mapOfEmptyGDplayer1Objects = Hashtable.newFrom({"player1": []});
gdjs.level_32selectCode.mapOfGDgdjs_9546level_959532selectCode_9546GDplayObjects1Objects = Hashtable.newFrom({"play": gdjs.level_32selectCode.GDplayObjects1});
gdjs.level_32selectCode.mapOfGDgdjs_9546level_959532selectCode_9546GDshopObjects1Objects = Hashtable.newFrom({"shop": gdjs.level_32selectCode.GDshopObjects1});
gdjs.level_32selectCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level_32selectCode.mapOfEmptyGDplayer1Objects) > 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.level_32selectCode.GDwaterObjects1);
gdjs.copyArray(runtimeScene.getObjects("water_particlees"), gdjs.level_32selectCode.GDwater_9595particleesObjects1);
gdjs.copyArray(runtimeScene.getObjects("water_particlees2"), gdjs.level_32selectCode.GDwater_9595particlees2Objects1);
{for(var i = 0, len = gdjs.level_32selectCode.GDwaterObjects1.length ;i < len;++i) {
    gdjs.level_32selectCode.GDwaterObjects1[i].setXOffset(gdjs.level_32selectCode.GDwaterObjects1[i].getXOffset() + (0.7));
}
}{for(var i = 0, len = gdjs.level_32selectCode.GDwater_9595particleesObjects1.length ;i < len;++i) {
    gdjs.level_32selectCode.GDwater_9595particleesObjects1[i].setXOffset(gdjs.level_32selectCode.GDwater_9595particleesObjects1[i].getXOffset() + (0.7));
}
}{for(var i = 0, len = gdjs.level_32selectCode.GDwater_9595particlees2Objects1.length ;i < len;++i) {
    gdjs.level_32selectCode.GDwater_9595particlees2Objects1[i].setYOffset(gdjs.level_32selectCode.GDwater_9595particlees2Objects1[i].getYOffset() + (0.7));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.level_32selectCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.level_32selectCode.GDrifleObjects1);
{for(var i = 0, len = gdjs.level_32selectCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.level_32selectCode.GDrifleObjects1[i].setPosition((( gdjs.level_32selectCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.level_32selectCode.GDplayer1Objects1[0].getPointX("hand")),(( gdjs.level_32selectCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.level_32selectCode.GDplayer1Objects1[0].getPointY("hand")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.level_32selectCode.GDplayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.level_32selectCode.mapOfGDgdjs_9546level_959532selectCode_9546GDplayObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "rogue", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("shop"), gdjs.level_32selectCode.GDshopObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.level_32selectCode.mapOfGDgdjs_9546level_959532selectCode_9546GDshopObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "shop", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "HIP-HOP20240519053630.ogg", false, 60, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("touch"), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("touch"), true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.adMob.isBannerErrored();
if (isConditionTrue_0) {
{gdjs.adMob.setupBanner("ca-app-pub-7377576469196405/3886255873", "", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.adMob.isBannerConfigured();
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15534164);
}
}
if (isConditionTrue_0) {
{gdjs.adMob.showBanner();
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15531156);
}
if (isConditionTrue_0) {
{gdjs.adMob.setupBanner("ca-app-pub-7377576469196405/3886255873", "", false);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.level_32selectCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.level_32selectCode.GDaquaphobiaObjects1.length = 0;
gdjs.level_32selectCode.GDaquaphobiaObjects2.length = 0;
gdjs.level_32selectCode.GDplayObjects1.length = 0;
gdjs.level_32selectCode.GDplayObjects2.length = 0;
gdjs.level_32selectCode.GDbuttonObjects1.length = 0;
gdjs.level_32selectCode.GDbuttonObjects2.length = 0;
gdjs.level_32selectCode.GDbackObjects1.length = 0;
gdjs.level_32selectCode.GDbackObjects2.length = 0;
gdjs.level_32selectCode.GDwaterObjects1.length = 0;
gdjs.level_32selectCode.GDwaterObjects2.length = 0;
gdjs.level_32selectCode.GDplayer1Objects1.length = 0;
gdjs.level_32selectCode.GDplayer1Objects2.length = 0;
gdjs.level_32selectCode.GDcement_9595block_9595blueObjects1.length = 0;
gdjs.level_32selectCode.GDcement_9595block_9595blueObjects2.length = 0;
gdjs.level_32selectCode.GDwater_9595particleesObjects1.length = 0;
gdjs.level_32selectCode.GDwater_9595particleesObjects2.length = 0;
gdjs.level_32selectCode.GDcement_9595block_9595blue_9595sideObjects1.length = 0;
gdjs.level_32selectCode.GDcement_9595block_9595blue_9595sideObjects2.length = 0;
gdjs.level_32selectCode.GDwater_9595particlees2Objects1.length = 0;
gdjs.level_32selectCode.GDwater_9595particlees2Objects2.length = 0;
gdjs.level_32selectCode.GDrifleObjects1.length = 0;
gdjs.level_32selectCode.GDrifleObjects2.length = 0;
gdjs.level_32selectCode.GDshopObjects1.length = 0;
gdjs.level_32selectCode.GDshopObjects2.length = 0;
gdjs.level_32selectCode.GDmultiplayerObjects1.length = 0;
gdjs.level_32selectCode.GDmultiplayerObjects2.length = 0;

gdjs.level_32selectCode.eventsList0(runtimeScene);
gdjs.level_32selectCode.GDaquaphobiaObjects1.length = 0;
gdjs.level_32selectCode.GDaquaphobiaObjects2.length = 0;
gdjs.level_32selectCode.GDplayObjects1.length = 0;
gdjs.level_32selectCode.GDplayObjects2.length = 0;
gdjs.level_32selectCode.GDbuttonObjects1.length = 0;
gdjs.level_32selectCode.GDbuttonObjects2.length = 0;
gdjs.level_32selectCode.GDbackObjects1.length = 0;
gdjs.level_32selectCode.GDbackObjects2.length = 0;
gdjs.level_32selectCode.GDwaterObjects1.length = 0;
gdjs.level_32selectCode.GDwaterObjects2.length = 0;
gdjs.level_32selectCode.GDplayer1Objects1.length = 0;
gdjs.level_32selectCode.GDplayer1Objects2.length = 0;
gdjs.level_32selectCode.GDcement_9595block_9595blueObjects1.length = 0;
gdjs.level_32selectCode.GDcement_9595block_9595blueObjects2.length = 0;
gdjs.level_32selectCode.GDwater_9595particleesObjects1.length = 0;
gdjs.level_32selectCode.GDwater_9595particleesObjects2.length = 0;
gdjs.level_32selectCode.GDcement_9595block_9595blue_9595sideObjects1.length = 0;
gdjs.level_32selectCode.GDcement_9595block_9595blue_9595sideObjects2.length = 0;
gdjs.level_32selectCode.GDwater_9595particlees2Objects1.length = 0;
gdjs.level_32selectCode.GDwater_9595particlees2Objects2.length = 0;
gdjs.level_32selectCode.GDrifleObjects1.length = 0;
gdjs.level_32selectCode.GDrifleObjects2.length = 0;
gdjs.level_32selectCode.GDshopObjects1.length = 0;
gdjs.level_32selectCode.GDshopObjects2.length = 0;
gdjs.level_32selectCode.GDmultiplayerObjects1.length = 0;
gdjs.level_32selectCode.GDmultiplayerObjects2.length = 0;


return;

}

gdjs['level_32selectCode'] = gdjs.level_32selectCode;
