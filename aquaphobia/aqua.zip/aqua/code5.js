gdjs.piratey_32storyCode = {};
gdjs.piratey_32storyCode.localVariables = [];
gdjs.piratey_32storyCode.GDanimationObjects1= [];
gdjs.piratey_32storyCode.GDanimationObjects2= [];
gdjs.piratey_32storyCode.GDglowObjects1= [];
gdjs.piratey_32storyCode.GDglowObjects2= [];
gdjs.piratey_32storyCode.GDbackgroundObjects1= [];
gdjs.piratey_32storyCode.GDbackgroundObjects2= [];
gdjs.piratey_32storyCode.GDcursorObjects1= [];
gdjs.piratey_32storyCode.GDcursorObjects2= [];
gdjs.piratey_32storyCode.GDUnnamedObjects1= [];
gdjs.piratey_32storyCode.GDUnnamedObjects2= [];
gdjs.piratey_32storyCode.GDball_9595pictureObjects1= [];
gdjs.piratey_32storyCode.GDball_9595pictureObjects2= [];
gdjs.piratey_32storyCode.GDfileObjects1= [];
gdjs.piratey_32storyCode.GDfileObjects2= [];
gdjs.piratey_32storyCode.GDrecycleObjects1= [];
gdjs.piratey_32storyCode.GDrecycleObjects2= [];
gdjs.piratey_32storyCode.GDtextObjects1= [];
gdjs.piratey_32storyCode.GDtextObjects2= [];
gdjs.piratey_32storyCode.GDpirateObjects1= [];
gdjs.piratey_32storyCode.GDpirateObjects2= [];
gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1= [];
gdjs.piratey_32storyCode.GDinstaller_9595fileObjects2= [];
gdjs.piratey_32storyCode.GDoutboxObjects1= [];
gdjs.piratey_32storyCode.GDoutboxObjects2= [];
gdjs.piratey_32storyCode.GDball_9595picObjects1= [];
gdjs.piratey_32storyCode.GDball_9595picObjects2= [];
gdjs.piratey_32storyCode.GDwindow_9595showObjects1= [];
gdjs.piratey_32storyCode.GDwindow_9595showObjects2= [];
gdjs.piratey_32storyCode.GDtestObjects1= [];
gdjs.piratey_32storyCode.GDtestObjects2= [];
gdjs.piratey_32storyCode.GDwhiteObjects1= [];
gdjs.piratey_32storyCode.GDwhiteObjects2= [];
gdjs.piratey_32storyCode.GDbadObjects1= [];
gdjs.piratey_32storyCode.GDbadObjects2= [];
gdjs.piratey_32storyCode.GDfile_9595uiObjects1= [];
gdjs.piratey_32storyCode.GDfile_9595uiObjects2= [];


gdjs.piratey_32storyCode.mapOfGDgdjs_9546piratey_959532storyCode_9546GDcursorObjects1Objects = Hashtable.newFrom({"cursor": gdjs.piratey_32storyCode.GDcursorObjects1});
gdjs.piratey_32storyCode.mapOfGDgdjs_9546piratey_959532storyCode_9546GDball_95959595pictureObjects1ObjectsGDgdjs_9546piratey_959532storyCode_9546GDfileObjects1ObjectsGDgdjs_9546piratey_959532storyCode_9546GDrecycleObjects1ObjectsGDgdjs_9546piratey_959532storyCode_9546GDtextObjects1ObjectsGDgdjs_9546piratey_959532storyCode_9546GDpirateObjects1ObjectsGDgdjs_9546piratey_959532storyCode_9546GDinstaller_95959595fileObjects1Objects = Hashtable.newFrom({"ball_picture": gdjs.piratey_32storyCode.GDball_9595pictureObjects1, "file": gdjs.piratey_32storyCode.GDfileObjects1, "recycle": gdjs.piratey_32storyCode.GDrecycleObjects1, "text": gdjs.piratey_32storyCode.GDtextObjects1, "pirate": gdjs.piratey_32storyCode.GDpirateObjects1, "installer_file": gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1});
gdjs.piratey_32storyCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.piratey_32storyCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ball_picture"), gdjs.piratey_32storyCode.GDball_9595pictureObjects1);
gdjs.copyArray(runtimeScene.getObjects("file"), gdjs.piratey_32storyCode.GDfileObjects1);
gdjs.copyArray(runtimeScene.getObjects("installer_file"), gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1);
gdjs.copyArray(runtimeScene.getObjects("pirate"), gdjs.piratey_32storyCode.GDpirateObjects1);
gdjs.copyArray(runtimeScene.getObjects("recycle"), gdjs.piratey_32storyCode.GDrecycleObjects1);
gdjs.copyArray(runtimeScene.getObjects("text"), gdjs.piratey_32storyCode.GDtextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.piratey_32storyCode.GDball_9595pictureObjects1.length;i<l;++i) {
    if ( gdjs.piratey_32storyCode.GDball_9595pictureObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.piratey_32storyCode.GDball_9595pictureObjects1[k] = gdjs.piratey_32storyCode.GDball_9595pictureObjects1[i];
        ++k;
    }
}
gdjs.piratey_32storyCode.GDball_9595pictureObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.piratey_32storyCode.GDfileObjects1.length;i<l;++i) {
    if ( gdjs.piratey_32storyCode.GDfileObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.piratey_32storyCode.GDfileObjects1[k] = gdjs.piratey_32storyCode.GDfileObjects1[i];
        ++k;
    }
}
gdjs.piratey_32storyCode.GDfileObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.piratey_32storyCode.GDrecycleObjects1.length;i<l;++i) {
    if ( gdjs.piratey_32storyCode.GDrecycleObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.piratey_32storyCode.GDrecycleObjects1[k] = gdjs.piratey_32storyCode.GDrecycleObjects1[i];
        ++k;
    }
}
gdjs.piratey_32storyCode.GDrecycleObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.piratey_32storyCode.GDtextObjects1.length;i<l;++i) {
    if ( gdjs.piratey_32storyCode.GDtextObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.piratey_32storyCode.GDtextObjects1[k] = gdjs.piratey_32storyCode.GDtextObjects1[i];
        ++k;
    }
}
gdjs.piratey_32storyCode.GDtextObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.piratey_32storyCode.GDpirateObjects1.length;i<l;++i) {
    if ( gdjs.piratey_32storyCode.GDpirateObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.piratey_32storyCode.GDpirateObjects1[k] = gdjs.piratey_32storyCode.GDpirateObjects1[i];
        ++k;
    }
}
gdjs.piratey_32storyCode.GDpirateObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1.length;i<l;++i) {
    if ( gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1[k] = gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1[i];
        ++k;
    }
}
gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.piratey_32storyCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.piratey_32storyCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("animation"), gdjs.piratey_32storyCode.GDanimationObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.piratey_32storyCode.GDanimationObjects1.length;i<l;++i) {
    if ( gdjs.piratey_32storyCode.GDanimationObjects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.piratey_32storyCode.GDanimationObjects1[k] = gdjs.piratey_32storyCode.GDanimationObjects1[i];
        ++k;
    }
}
gdjs.piratey_32storyCode.GDanimationObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.piratey_32storyCode.GDanimationObjects1.length;i<l;++i) {
    if ( gdjs.piratey_32storyCode.GDanimationObjects1[i].getBehavior("Animation").getAnimationName() == "os loading" ) {
        isConditionTrue_0 = true;
        gdjs.piratey_32storyCode.GDanimationObjects1[k] = gdjs.piratey_32storyCode.GDanimationObjects1[i];
        ++k;
    }
}
gdjs.piratey_32storyCode.GDanimationObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.piratey_32storyCode.GDanimationObjects1 */
gdjs.copyArray(runtimeScene.getObjects("glow"), gdjs.piratey_32storyCode.GDglowObjects1);
{for(var i = 0, len = gdjs.piratey_32storyCode.GDanimationObjects1.length ;i < len;++i) {
    gdjs.piratey_32storyCode.GDanimationObjects1[i].getBehavior("Animation").setAnimationName("loading desktop");
}
}{for(var i = 0, len = gdjs.piratey_32storyCode.GDglowObjects1.length ;i < len;++i) {
    gdjs.piratey_32storyCode.GDglowObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.piratey_32storyCode.GDanimationObjects1.length ;i < len;++i) {
    gdjs.piratey_32storyCode.GDanimationObjects1[i].getBehavior("Resizable").setSize(1280, 710);
}
}{for(var i = 0, len = gdjs.piratey_32storyCode.GDanimationObjects1.length ;i < len;++i) {
    gdjs.piratey_32storyCode.GDanimationObjects1[i].setPosition(0,0);
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("animation"), gdjs.piratey_32storyCode.GDanimationObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.piratey_32storyCode.GDanimationObjects1.length;i<l;++i) {
    if ( gdjs.piratey_32storyCode.GDanimationObjects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.piratey_32storyCode.GDanimationObjects1[k] = gdjs.piratey_32storyCode.GDanimationObjects1[i];
        ++k;
    }
}
gdjs.piratey_32storyCode.GDanimationObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.piratey_32storyCode.GDanimationObjects1.length;i<l;++i) {
    if ( gdjs.piratey_32storyCode.GDanimationObjects1[i].getBehavior("Animation").getAnimationName() == "loading desktop" ) {
        isConditionTrue_0 = true;
        gdjs.piratey_32storyCode.GDanimationObjects1[k] = gdjs.piratey_32storyCode.GDanimationObjects1[i];
        ++k;
    }
}
gdjs.piratey_32storyCode.GDanimationObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.piratey_32storyCode.GDanimationObjects1 */
gdjs.copyArray(runtimeScene.getObjects("glow"), gdjs.piratey_32storyCode.GDglowObjects1);
{for(var i = 0, len = gdjs.piratey_32storyCode.GDanimationObjects1.length ;i < len;++i) {
    gdjs.piratey_32storyCode.GDanimationObjects1[i].getBehavior("Animation").setAnimationName("loading desktop");
}
}{for(var i = 0, len = gdjs.piratey_32storyCode.GDglowObjects1.length ;i < len;++i) {
    gdjs.piratey_32storyCode.GDglowObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.piratey_32storyCode.GDanimationObjects1.length ;i < len;++i) {
    gdjs.piratey_32storyCode.GDanimationObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("animation"), gdjs.piratey_32storyCode.GDanimationObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.piratey_32storyCode.GDanimationObjects1.length;i<l;++i) {
    if ( !(gdjs.piratey_32storyCode.GDanimationObjects1[i].getBehavior("Animation").hasAnimationEnded()) ) {
        isConditionTrue_0 = true;
        gdjs.piratey_32storyCode.GDanimationObjects1[k] = gdjs.piratey_32storyCode.GDanimationObjects1[i];
        ++k;
    }
}
gdjs.piratey_32storyCode.GDanimationObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.piratey_32storyCode.GDanimationObjects1.length;i<l;++i) {
    if ( gdjs.piratey_32storyCode.GDanimationObjects1[i].getBehavior("Animation").getAnimationName() == "os loading" ) {
        isConditionTrue_0 = true;
        gdjs.piratey_32storyCode.GDanimationObjects1[k] = gdjs.piratey_32storyCode.GDanimationObjects1[i];
        ++k;
    }
}
gdjs.piratey_32storyCode.GDanimationObjects1.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("outbox"), gdjs.piratey_32storyCode.GDoutboxObjects1);
{for(var i = 0, len = gdjs.piratey_32storyCode.GDoutboxObjects1.length ;i < len;++i) {
    gdjs.piratey_32storyCode.GDoutboxObjects1[i].getBehavior("Opacity").setOpacity(100);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ball_picture"), gdjs.piratey_32storyCode.GDball_9595pictureObjects1);
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.piratey_32storyCode.GDcursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("file"), gdjs.piratey_32storyCode.GDfileObjects1);
gdjs.copyArray(runtimeScene.getObjects("installer_file"), gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1);
gdjs.copyArray(runtimeScene.getObjects("pirate"), gdjs.piratey_32storyCode.GDpirateObjects1);
gdjs.copyArray(runtimeScene.getObjects("recycle"), gdjs.piratey_32storyCode.GDrecycleObjects1);
gdjs.copyArray(runtimeScene.getObjects("text"), gdjs.piratey_32storyCode.GDtextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.piratey_32storyCode.mapOfGDgdjs_9546piratey_959532storyCode_9546GDcursorObjects1Objects, gdjs.piratey_32storyCode.mapOfGDgdjs_9546piratey_959532storyCode_9546GDball_95959595pictureObjects1ObjectsGDgdjs_9546piratey_959532storyCode_9546GDfileObjects1ObjectsGDgdjs_9546piratey_959532storyCode_9546GDrecycleObjects1ObjectsGDgdjs_9546piratey_959532storyCode_9546GDtextObjects1ObjectsGDgdjs_9546piratey_959532storyCode_9546GDpirateObjects1ObjectsGDgdjs_9546piratey_959532storyCode_9546GDinstaller_95959595fileObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.piratey_32storyCode.GDball_9595pictureObjects1 */
/* Reuse gdjs.piratey_32storyCode.GDfileObjects1 */
/* Reuse gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1 */
gdjs.copyArray(runtimeScene.getObjects("outbox"), gdjs.piratey_32storyCode.GDoutboxObjects1);
/* Reuse gdjs.piratey_32storyCode.GDpirateObjects1 */
/* Reuse gdjs.piratey_32storyCode.GDrecycleObjects1 */
/* Reuse gdjs.piratey_32storyCode.GDtextObjects1 */
{for(var i = 0, len = gdjs.piratey_32storyCode.GDoutboxObjects1.length ;i < len;++i) {
    gdjs.piratey_32storyCode.GDoutboxObjects1[i].setPosition((( gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1.length === 0 ) ? (( gdjs.piratey_32storyCode.GDpirateObjects1.length === 0 ) ? (( gdjs.piratey_32storyCode.GDtextObjects1.length === 0 ) ? (( gdjs.piratey_32storyCode.GDrecycleObjects1.length === 0 ) ? (( gdjs.piratey_32storyCode.GDfileObjects1.length === 0 ) ? (( gdjs.piratey_32storyCode.GDball_9595pictureObjects1.length === 0 ) ? 0 :gdjs.piratey_32storyCode.GDball_9595pictureObjects1[0].getPointX("")) :gdjs.piratey_32storyCode.GDfileObjects1[0].getPointX("")) :gdjs.piratey_32storyCode.GDrecycleObjects1[0].getPointX("")) :gdjs.piratey_32storyCode.GDtextObjects1[0].getPointX("")) :gdjs.piratey_32storyCode.GDpirateObjects1[0].getPointX("")) :gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1[0].getPointX("")),(( gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1.length === 0 ) ? (( gdjs.piratey_32storyCode.GDpirateObjects1.length === 0 ) ? (( gdjs.piratey_32storyCode.GDtextObjects1.length === 0 ) ? (( gdjs.piratey_32storyCode.GDrecycleObjects1.length === 0 ) ? (( gdjs.piratey_32storyCode.GDfileObjects1.length === 0 ) ? (( gdjs.piratey_32storyCode.GDball_9595pictureObjects1.length === 0 ) ? 0 :gdjs.piratey_32storyCode.GDball_9595pictureObjects1[0].getPointY("")) :gdjs.piratey_32storyCode.GDfileObjects1[0].getPointY("")) :gdjs.piratey_32storyCode.GDrecycleObjects1[0].getPointY("")) :gdjs.piratey_32storyCode.GDtextObjects1[0].getPointY("")) :gdjs.piratey_32storyCode.GDpirateObjects1[0].getPointY("")) :gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1[0].getPointY("")));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.piratey_32storyCode.GDcursorObjects1);
{for(var i = 0, len = gdjs.piratey_32storyCode.GDcursorObjects1.length ;i < len;++i) {
    gdjs.piratey_32storyCode.GDcursorObjects1[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{gdjs.evtTools.input.hideCursor(runtimeScene);
}}

}


{


gdjs.piratey_32storyCode.eventsList1(runtimeScene);
}


};

gdjs.piratey_32storyCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.piratey_32storyCode.GDanimationObjects1.length = 0;
gdjs.piratey_32storyCode.GDanimationObjects2.length = 0;
gdjs.piratey_32storyCode.GDglowObjects1.length = 0;
gdjs.piratey_32storyCode.GDglowObjects2.length = 0;
gdjs.piratey_32storyCode.GDbackgroundObjects1.length = 0;
gdjs.piratey_32storyCode.GDbackgroundObjects2.length = 0;
gdjs.piratey_32storyCode.GDcursorObjects1.length = 0;
gdjs.piratey_32storyCode.GDcursorObjects2.length = 0;
gdjs.piratey_32storyCode.GDUnnamedObjects1.length = 0;
gdjs.piratey_32storyCode.GDUnnamedObjects2.length = 0;
gdjs.piratey_32storyCode.GDball_9595pictureObjects1.length = 0;
gdjs.piratey_32storyCode.GDball_9595pictureObjects2.length = 0;
gdjs.piratey_32storyCode.GDfileObjects1.length = 0;
gdjs.piratey_32storyCode.GDfileObjects2.length = 0;
gdjs.piratey_32storyCode.GDrecycleObjects1.length = 0;
gdjs.piratey_32storyCode.GDrecycleObjects2.length = 0;
gdjs.piratey_32storyCode.GDtextObjects1.length = 0;
gdjs.piratey_32storyCode.GDtextObjects2.length = 0;
gdjs.piratey_32storyCode.GDpirateObjects1.length = 0;
gdjs.piratey_32storyCode.GDpirateObjects2.length = 0;
gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1.length = 0;
gdjs.piratey_32storyCode.GDinstaller_9595fileObjects2.length = 0;
gdjs.piratey_32storyCode.GDoutboxObjects1.length = 0;
gdjs.piratey_32storyCode.GDoutboxObjects2.length = 0;
gdjs.piratey_32storyCode.GDball_9595picObjects1.length = 0;
gdjs.piratey_32storyCode.GDball_9595picObjects2.length = 0;
gdjs.piratey_32storyCode.GDwindow_9595showObjects1.length = 0;
gdjs.piratey_32storyCode.GDwindow_9595showObjects2.length = 0;
gdjs.piratey_32storyCode.GDtestObjects1.length = 0;
gdjs.piratey_32storyCode.GDtestObjects2.length = 0;
gdjs.piratey_32storyCode.GDwhiteObjects1.length = 0;
gdjs.piratey_32storyCode.GDwhiteObjects2.length = 0;
gdjs.piratey_32storyCode.GDbadObjects1.length = 0;
gdjs.piratey_32storyCode.GDbadObjects2.length = 0;
gdjs.piratey_32storyCode.GDfile_9595uiObjects1.length = 0;
gdjs.piratey_32storyCode.GDfile_9595uiObjects2.length = 0;

gdjs.piratey_32storyCode.eventsList2(runtimeScene);
gdjs.piratey_32storyCode.GDanimationObjects1.length = 0;
gdjs.piratey_32storyCode.GDanimationObjects2.length = 0;
gdjs.piratey_32storyCode.GDglowObjects1.length = 0;
gdjs.piratey_32storyCode.GDglowObjects2.length = 0;
gdjs.piratey_32storyCode.GDbackgroundObjects1.length = 0;
gdjs.piratey_32storyCode.GDbackgroundObjects2.length = 0;
gdjs.piratey_32storyCode.GDcursorObjects1.length = 0;
gdjs.piratey_32storyCode.GDcursorObjects2.length = 0;
gdjs.piratey_32storyCode.GDUnnamedObjects1.length = 0;
gdjs.piratey_32storyCode.GDUnnamedObjects2.length = 0;
gdjs.piratey_32storyCode.GDball_9595pictureObjects1.length = 0;
gdjs.piratey_32storyCode.GDball_9595pictureObjects2.length = 0;
gdjs.piratey_32storyCode.GDfileObjects1.length = 0;
gdjs.piratey_32storyCode.GDfileObjects2.length = 0;
gdjs.piratey_32storyCode.GDrecycleObjects1.length = 0;
gdjs.piratey_32storyCode.GDrecycleObjects2.length = 0;
gdjs.piratey_32storyCode.GDtextObjects1.length = 0;
gdjs.piratey_32storyCode.GDtextObjects2.length = 0;
gdjs.piratey_32storyCode.GDpirateObjects1.length = 0;
gdjs.piratey_32storyCode.GDpirateObjects2.length = 0;
gdjs.piratey_32storyCode.GDinstaller_9595fileObjects1.length = 0;
gdjs.piratey_32storyCode.GDinstaller_9595fileObjects2.length = 0;
gdjs.piratey_32storyCode.GDoutboxObjects1.length = 0;
gdjs.piratey_32storyCode.GDoutboxObjects2.length = 0;
gdjs.piratey_32storyCode.GDball_9595picObjects1.length = 0;
gdjs.piratey_32storyCode.GDball_9595picObjects2.length = 0;
gdjs.piratey_32storyCode.GDwindow_9595showObjects1.length = 0;
gdjs.piratey_32storyCode.GDwindow_9595showObjects2.length = 0;
gdjs.piratey_32storyCode.GDtestObjects1.length = 0;
gdjs.piratey_32storyCode.GDtestObjects2.length = 0;
gdjs.piratey_32storyCode.GDwhiteObjects1.length = 0;
gdjs.piratey_32storyCode.GDwhiteObjects2.length = 0;
gdjs.piratey_32storyCode.GDbadObjects1.length = 0;
gdjs.piratey_32storyCode.GDbadObjects2.length = 0;
gdjs.piratey_32storyCode.GDfile_9595uiObjects1.length = 0;
gdjs.piratey_32storyCode.GDfile_9595uiObjects2.length = 0;


return;

}

gdjs['piratey_32storyCode'] = gdjs.piratey_32storyCode;
