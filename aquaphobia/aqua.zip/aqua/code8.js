gdjs.multiplayerCode = {};
gdjs.multiplayerCode.localVariables = [];
gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final = [];

gdjs.multiplayerCode.GDdiverObjects1_1final = [];

gdjs.multiplayerCode.GDplayer1Objects1_1final = [];

gdjs.multiplayerCode.GDshootObjects1_1final = [];

gdjs.multiplayerCode.GDshootObjects2_2final = [];

gdjs.multiplayerCode.GDwater_9595particlees2Objects1_1final = [];

gdjs.multiplayerCode.GDwater_9595particleesObjects1_1final = [];

gdjs.multiplayerCode.GDwaveObjects1_1final = [];

gdjs.multiplayerCode.GDplayer1Objects1= [];
gdjs.multiplayerCode.GDplayer1Objects2= [];
gdjs.multiplayerCode.GDplayer1Objects3= [];
gdjs.multiplayerCode.GDplayer1Objects4= [];
gdjs.multiplayerCode.GDpillarObjects1= [];
gdjs.multiplayerCode.GDpillarObjects2= [];
gdjs.multiplayerCode.GDpillarObjects3= [];
gdjs.multiplayerCode.GDpillarObjects4= [];
gdjs.multiplayerCode.GDcement_9595block_9595blueObjects1= [];
gdjs.multiplayerCode.GDcement_9595block_9595blueObjects2= [];
gdjs.multiplayerCode.GDcement_9595block_9595blueObjects3= [];
gdjs.multiplayerCode.GDcement_9595block_9595blueObjects4= [];
gdjs.multiplayerCode.GDclonObjects1= [];
gdjs.multiplayerCode.GDclonObjects2= [];
gdjs.multiplayerCode.GDclonObjects3= [];
gdjs.multiplayerCode.GDclonObjects4= [];
gdjs.multiplayerCode.GDsmasherObjects1= [];
gdjs.multiplayerCode.GDsmasherObjects2= [];
gdjs.multiplayerCode.GDsmasherObjects3= [];
gdjs.multiplayerCode.GDsmasherObjects4= [];
gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects1= [];
gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects2= [];
gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects3= [];
gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects4= [];
gdjs.multiplayerCode.GDdoorObjects1= [];
gdjs.multiplayerCode.GDdoorObjects2= [];
gdjs.multiplayerCode.GDdoorObjects3= [];
gdjs.multiplayerCode.GDdoorObjects4= [];
gdjs.multiplayerCode.GDrifleObjects1= [];
gdjs.multiplayerCode.GDrifleObjects2= [];
gdjs.multiplayerCode.GDrifleObjects3= [];
gdjs.multiplayerCode.GDrifleObjects4= [];
gdjs.multiplayerCode.GDhit_9595boxObjects1= [];
gdjs.multiplayerCode.GDhit_9595boxObjects2= [];
gdjs.multiplayerCode.GDhit_9595boxObjects3= [];
gdjs.multiplayerCode.GDhit_9595boxObjects4= [];
gdjs.multiplayerCode.GDbulletObjects1= [];
gdjs.multiplayerCode.GDbulletObjects2= [];
gdjs.multiplayerCode.GDbulletObjects3= [];
gdjs.multiplayerCode.GDbulletObjects4= [];
gdjs.multiplayerCode.GDreloadObjects1= [];
gdjs.multiplayerCode.GDreloadObjects2= [];
gdjs.multiplayerCode.GDreloadObjects3= [];
gdjs.multiplayerCode.GDreloadObjects4= [];
gdjs.multiplayerCode.GDreload2Objects1= [];
gdjs.multiplayerCode.GDreload2Objects2= [];
gdjs.multiplayerCode.GDreload2Objects3= [];
gdjs.multiplayerCode.GDreload2Objects4= [];
gdjs.multiplayerCode.GDwaterObjects1= [];
gdjs.multiplayerCode.GDwaterObjects2= [];
gdjs.multiplayerCode.GDwaterObjects3= [];
gdjs.multiplayerCode.GDwaterObjects4= [];
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1= [];
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects2= [];
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects3= [];
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects4= [];
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects1= [];
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects2= [];
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects3= [];
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects4= [];
gdjs.multiplayerCode.GDwater_9595particleesObjects1= [];
gdjs.multiplayerCode.GDwater_9595particleesObjects2= [];
gdjs.multiplayerCode.GDwater_9595particleesObjects3= [];
gdjs.multiplayerCode.GDwater_9595particleesObjects4= [];
gdjs.multiplayerCode.GDwater_9595particlees2Objects1= [];
gdjs.multiplayerCode.GDwater_9595particlees2Objects2= [];
gdjs.multiplayerCode.GDwater_9595particlees2Objects3= [];
gdjs.multiplayerCode.GDwater_9595particlees2Objects4= [];
gdjs.multiplayerCode.GDlifeObjects1= [];
gdjs.multiplayerCode.GDlifeObjects2= [];
gdjs.multiplayerCode.GDlifeObjects3= [];
gdjs.multiplayerCode.GDlifeObjects4= [];
gdjs.multiplayerCode.GDbackgroundObjects1= [];
gdjs.multiplayerCode.GDbackgroundObjects2= [];
gdjs.multiplayerCode.GDbackgroundObjects3= [];
gdjs.multiplayerCode.GDbackgroundObjects4= [];
gdjs.multiplayerCode.GDwin_9595failObjects1= [];
gdjs.multiplayerCode.GDwin_9595failObjects2= [];
gdjs.multiplayerCode.GDwin_9595failObjects3= [];
gdjs.multiplayerCode.GDwin_9595failObjects4= [];
gdjs.multiplayerCode.GDstateObjects1= [];
gdjs.multiplayerCode.GDstateObjects2= [];
gdjs.multiplayerCode.GDstateObjects3= [];
gdjs.multiplayerCode.GDstateObjects4= [];
gdjs.multiplayerCode.GDlineObjects1= [];
gdjs.multiplayerCode.GDlineObjects2= [];
gdjs.multiplayerCode.GDlineObjects3= [];
gdjs.multiplayerCode.GDlineObjects4= [];
gdjs.multiplayerCode.GDsensorObjects1= [];
gdjs.multiplayerCode.GDsensorObjects2= [];
gdjs.multiplayerCode.GDsensorObjects3= [];
gdjs.multiplayerCode.GDsensorObjects4= [];
gdjs.multiplayerCode.GDblockerObjects1= [];
gdjs.multiplayerCode.GDblockerObjects2= [];
gdjs.multiplayerCode.GDblockerObjects3= [];
gdjs.multiplayerCode.GDblockerObjects4= [];
gdjs.multiplayerCode.GDsensor2Objects1= [];
gdjs.multiplayerCode.GDsensor2Objects2= [];
gdjs.multiplayerCode.GDsensor2Objects3= [];
gdjs.multiplayerCode.GDsensor2Objects4= [];
gdjs.multiplayerCode.GDsmasher_9595aObjects1= [];
gdjs.multiplayerCode.GDsmasher_9595aObjects2= [];
gdjs.multiplayerCode.GDsmasher_9595aObjects3= [];
gdjs.multiplayerCode.GDsmasher_9595aObjects4= [];
gdjs.multiplayerCode.GDblast_9595botObjects1= [];
gdjs.multiplayerCode.GDblast_9595botObjects2= [];
gdjs.multiplayerCode.GDblast_9595botObjects3= [];
gdjs.multiplayerCode.GDblast_9595botObjects4= [];
gdjs.multiplayerCode.GDwaveObjects1= [];
gdjs.multiplayerCode.GDwaveObjects2= [];
gdjs.multiplayerCode.GDwaveObjects3= [];
gdjs.multiplayerCode.GDwaveObjects4= [];
gdjs.multiplayerCode.GDdiverObjects1= [];
gdjs.multiplayerCode.GDdiverObjects2= [];
gdjs.multiplayerCode.GDdiverObjects3= [];
gdjs.multiplayerCode.GDdiverObjects4= [];
gdjs.multiplayerCode.GDlevelObjects1= [];
gdjs.multiplayerCode.GDlevelObjects2= [];
gdjs.multiplayerCode.GDlevelObjects3= [];
gdjs.multiplayerCode.GDlevelObjects4= [];
gdjs.multiplayerCode.GDbossObjects1= [];
gdjs.multiplayerCode.GDbossObjects2= [];
gdjs.multiplayerCode.GDbossObjects3= [];
gdjs.multiplayerCode.GDbossObjects4= [];
gdjs.multiplayerCode.GDbackObjects1= [];
gdjs.multiplayerCode.GDbackObjects2= [];
gdjs.multiplayerCode.GDbackObjects3= [];
gdjs.multiplayerCode.GDbackObjects4= [];
gdjs.multiplayerCode.GDShadedDarkJoystickObjects1= [];
gdjs.multiplayerCode.GDShadedDarkJoystickObjects2= [];
gdjs.multiplayerCode.GDShadedDarkJoystickObjects3= [];
gdjs.multiplayerCode.GDShadedDarkJoystickObjects4= [];
gdjs.multiplayerCode.GDshootObjects1= [];
gdjs.multiplayerCode.GDshootObjects2= [];
gdjs.multiplayerCode.GDshootObjects3= [];
gdjs.multiplayerCode.GDshootObjects4= [];
gdjs.multiplayerCode.GDNewBBTextObjects1= [];
gdjs.multiplayerCode.GDNewBBTextObjects2= [];
gdjs.multiplayerCode.GDNewBBTextObjects3= [];
gdjs.multiplayerCode.GDNewBBTextObjects4= [];
gdjs.multiplayerCode.GDidObjects1= [];
gdjs.multiplayerCode.GDidObjects2= [];
gdjs.multiplayerCode.GDidObjects3= [];
gdjs.multiplayerCode.GDidObjects4= [];
gdjs.multiplayerCode.GDidsObjects1= [];
gdjs.multiplayerCode.GDidsObjects2= [];
gdjs.multiplayerCode.GDidsObjects3= [];
gdjs.multiplayerCode.GDidsObjects4= [];


gdjs.multiplayerCode.mapOfEmptyGDplayer1Objects = Hashtable.newFrom({"player1": []});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsmasherObjects1Objects = Hashtable.newFrom({"smasher": gdjs.multiplayerCode.GDsmasherObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.multiplayerCode.GDbulletObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDclonObjects1Objects = Hashtable.newFrom({"clon": gdjs.multiplayerCode.GDclonObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.multiplayerCode.GDbulletObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.multiplayerCode.GDplayer1Objects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDhit_95959595boxObjects1Objects = Hashtable.newFrom({"hit_box": gdjs.multiplayerCode.GDhit_9595boxObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDhit_95959595boxObjects1Objects = Hashtable.newFrom({"hit_box": gdjs.multiplayerCode.GDhit_9595boxObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDblockerObjects1Objects = Hashtable.newFrom({"blocker": gdjs.multiplayerCode.GDblockerObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsmasherObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDclonObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDblast_95959595botObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDdiverObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDbossObjects1Objects = Hashtable.newFrom({"smasher": gdjs.multiplayerCode.GDsmasherObjects1, "clon": gdjs.multiplayerCode.GDclonObjects1, "blast_bot": gdjs.multiplayerCode.GDblast_9595botObjects1, "diver": gdjs.multiplayerCode.GDdiverObjects1, "boss": gdjs.multiplayerCode.GDbossObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.multiplayerCode.GDsensorObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.multiplayerCode.GDsensorObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.multiplayerCode.GDsensorObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.multiplayerCode.GDsensorObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.multiplayerCode.GDsensorObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.multiplayerCode.GDsensorObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects = Hashtable.newFrom({"cement_block_blue_side": gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects = Hashtable.newFrom({"cement_block_blue_side": gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects = Hashtable.newFrom({"cement_block_blue_side": gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects = Hashtable.newFrom({"cement_block_blue_side": gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects = Hashtable.newFrom({"cement_block_blue_side": gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwater_95959595particlees2Objects1Objects = Hashtable.newFrom({"water_particlees2": gdjs.multiplayerCode.GDwater_9595particlees2Objects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwater_95959595particlees2Objects1Objects = Hashtable.newFrom({"water_particlees2": gdjs.multiplayerCode.GDwater_9595particlees2Objects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwater_95959595particlees2Objects1Objects = Hashtable.newFrom({"water_particlees2": gdjs.multiplayerCode.GDwater_9595particlees2Objects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwater_95959595particlees2Objects1Objects = Hashtable.newFrom({"water_particlees2": gdjs.multiplayerCode.GDwater_9595particlees2Objects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwater_95959595particlees2Objects1Objects = Hashtable.newFrom({"water_particlees2": gdjs.multiplayerCode.GDwater_9595particlees2Objects1});
gdjs.multiplayerCode.eventsList0 = function(runtimeScene) {

{

/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
/* Reuse gdjs.multiplayerCode.GDrifleObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDrifleObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDrifleObjects1[i].getVariableString(gdjs.multiplayerCode.GDrifleObjects1[i].getVariables().getFromIndex(0).getChild("id")) == ((gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.multiplayerCode.GDplayer1Objects1[0].getVariables()).getFromIndex(2).getChild("id").getAsString() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDrifleObjects1[k] = gdjs.multiplayerCode.GDrifleObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDrifleObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
/* Reuse gdjs.multiplayerCode.GDrifleObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDrifleObjects1[i].setPosition((( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getPointX("hand2")) - 8,(( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getPointY("hand2")));
}
}}

}


};gdjs.multiplayerCode.eventsList1 = function(runtimeScene) {

{

/* Reuse gdjs.multiplayerCode.GDrifleObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDrifleObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDrifleObjects1[i].getVariableString(gdjs.multiplayerCode.GDrifleObjects1[i].getVariables().getFromIndex(0).getChild("id")) == gdjs.evtTools.p2p.getCurrentId() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDrifleObjects1[k] = gdjs.multiplayerCode.GDrifleObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDrifleObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
/* Reuse gdjs.multiplayerCode.GDrifleObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDrifleObjects1[i].setPosition((( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getPointX("hand")),(( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getPointY("hand")));
}
}}

}


};gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.multiplayerCode.GDbulletObjects1});
gdjs.multiplayerCode.eventsList2 = function(runtimeScene) {

{

/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.multiplayerCode.GDrifleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDrifleObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDrifleObjects1[i].getVariableString(gdjs.multiplayerCode.GDrifleObjects1[i].getVariables().getFromIndex(0).getChild("id")) == ((gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.multiplayerCode.GDplayer1Objects1[0].getVariables()).getFromIndex(2).getChild("id").getAsString() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDrifleObjects1[k] = gdjs.multiplayerCode.GDrifleObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDrifleObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
/* Reuse gdjs.multiplayerCode.GDrifleObjects1 */
gdjs.multiplayerCode.GDbulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects1Objects, (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getAABBCenterX()), (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getAABBCenterY()), "");
}{for(var i = 0, len = gdjs.multiplayerCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDbulletObjects1[i].addPolarForce((( gdjs.multiplayerCode.GDrifleObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDrifleObjects1[0].getAngle()), 1000, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 40, gdjs.randomInRange(0.8, 1.2));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.55, 0.33, 0.50, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.multiplayerCode.GDbulletObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects2Objects = Hashtable.newFrom({"bullet": gdjs.multiplayerCode.GDbulletObjects2});
gdjs.multiplayerCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1, gdjs.multiplayerCode.GDplayer1Objects2);

gdjs.copyArray(gdjs.multiplayerCode.GDrifleObjects1, gdjs.multiplayerCode.GDrifleObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDrifleObjects2.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDrifleObjects2[i].getVariableString(gdjs.multiplayerCode.GDrifleObjects2[i].getVariables().getFromIndex(0).getChild("id")) == ((gdjs.multiplayerCode.GDplayer1Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.multiplayerCode.GDplayer1Objects2[0].getVariables()).getFromIndex(2).getChild("id").getAsString() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDrifleObjects2[k] = gdjs.multiplayerCode.GDrifleObjects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDrifleObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects2 */
/* Reuse gdjs.multiplayerCode.GDrifleObjects2 */
gdjs.copyArray(gdjs.multiplayerCode.GDbulletObjects1, gdjs.multiplayerCode.GDbulletObjects2);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects2Objects, (( gdjs.multiplayerCode.GDplayer1Objects2.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects2[0].getAABBCenterX()), (( gdjs.multiplayerCode.GDplayer1Objects2.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects2[0].getAABBCenterY()), "");
}{for(var i = 0, len = gdjs.multiplayerCode.GDbulletObjects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDbulletObjects2[i].addPolarForce((( gdjs.multiplayerCode.GDrifleObjects2.length === 0 ) ? 0 :gdjs.multiplayerCode.GDrifleObjects2[0].getAngle()), 1000, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 40, gdjs.randomInRange(0.8, 1.2));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.55, 0.33, 0.50, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.multiplayerCode.mapOfEmptyGDrifleObjects = Hashtable.newFrom({"rifle": []});
gdjs.multiplayerCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1, gdjs.multiplayerCode.GDplayer1Objects2);

gdjs.copyArray(gdjs.multiplayerCode.GDrifleObjects1, gdjs.multiplayerCode.GDrifleObjects2);

{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].setZOrder(200);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDrifleObjects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDrifleObjects2[i].setZOrder(201);
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.multiplayerCode.GDplayer1Objects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwaterObjects1Objects = Hashtable.newFrom({"water": gdjs.multiplayerCode.GDwaterObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.multiplayerCode.GDplayer1Objects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDcement_95959595block_95959595blueObjects1Objects = Hashtable.newFrom({"cement_block_blue": gdjs.multiplayerCode.GDcement_9595block_9595blueObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.multiplayerCode.GDplayer1Objects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsmasherObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDclonObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDblast_95959595botObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDdiverObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDbossObjects1Objects = Hashtable.newFrom({"smasher": gdjs.multiplayerCode.GDsmasherObjects1, "clon": gdjs.multiplayerCode.GDclonObjects1, "blast_bot": gdjs.multiplayerCode.GDblast_9595botObjects1, "diver": gdjs.multiplayerCode.GDdiverObjects1, "boss": gdjs.multiplayerCode.GDbossObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.multiplayerCode.GDplayer1Objects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDblockerObjects1Objects = Hashtable.newFrom({"blocker": gdjs.multiplayerCode.GDblockerObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsensor2Objects1Objects = Hashtable.newFrom({"sensor2": gdjs.multiplayerCode.GDsensor2Objects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDblockerObjects1Objects = Hashtable.newFrom({"blocker": gdjs.multiplayerCode.GDblockerObjects1});
gdjs.multiplayerCode.mapOfEmptyGDbossObjects = Hashtable.newFrom({"boss": []});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDclonObjects1Objects = Hashtable.newFrom({"clon": gdjs.multiplayerCode.GDclonObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDclonObjects1Objects = Hashtable.newFrom({"clon": gdjs.multiplayerCode.GDclonObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDclonObjects1Objects = Hashtable.newFrom({"clon": gdjs.multiplayerCode.GDclonObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsmasherObjects1Objects = Hashtable.newFrom({"smasher": gdjs.multiplayerCode.GDsmasherObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDdiverObjects1Objects = Hashtable.newFrom({"diver": gdjs.multiplayerCode.GDdiverObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwaveObjects2Objects = Hashtable.newFrom({"wave": gdjs.multiplayerCode.GDwaveObjects2});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwater_95959595particlees2Objects2Objects = Hashtable.newFrom({"water_particlees2": gdjs.multiplayerCode.GDwater_9595particlees2Objects2});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwaveObjects2Objects = Hashtable.newFrom({"wave": gdjs.multiplayerCode.GDwaveObjects2});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwater_95959595particleesObjects2Objects = Hashtable.newFrom({"water_particlees": gdjs.multiplayerCode.GDwater_9595particleesObjects2});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwaveObjects2Objects = Hashtable.newFrom({"wave": gdjs.multiplayerCode.GDwaveObjects2});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects2Objects = Hashtable.newFrom({"player1": gdjs.multiplayerCode.GDplayer1Objects2});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwaveObjects1Objects = Hashtable.newFrom({"wave": gdjs.multiplayerCode.GDwaveObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.multiplayerCode.GDbulletObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDblast_95959595botObjects1Objects = Hashtable.newFrom({"blast_bot": gdjs.multiplayerCode.GDblast_9595botObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.multiplayerCode.GDbulletObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDdiverObjects1Objects = Hashtable.newFrom({"diver": gdjs.multiplayerCode.GDdiverObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.multiplayerCode.GDbulletObjects1});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbossObjects1Objects = Hashtable.newFrom({"boss": gdjs.multiplayerCode.GDbossObjects1});
gdjs.multiplayerCode.asyncCallback16191020 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.multiplayerCode.localVariables);
{.get("state").getChild("speed").setNumber(gdjs.random(1000));
}{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(false);
}gdjs.multiplayerCode.localVariables.length = 0;
}
gdjs.multiplayerCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.multiplayerCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.multiplayerCode.asyncCallback16191020(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects3Objects = Hashtable.newFrom({"player1": gdjs.multiplayerCode.GDplayer1Objects3});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDrifleObjects3Objects = Hashtable.newFrom({"rifle": gdjs.multiplayerCode.GDrifleObjects3});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects3Objects = Hashtable.newFrom({"player1": gdjs.multiplayerCode.GDplayer1Objects3});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDrifleObjects3Objects = Hashtable.newFrom({"rifle": gdjs.multiplayerCode.GDrifleObjects3});
gdjs.multiplayerCode.eventsList6 = function(runtimeScene) {

{

/* Reuse gdjs.multiplayerCode.GDplayer1Objects2 */
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.multiplayerCode.GDrifleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDrifleObjects2.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDrifleObjects2[i].getVariableString(gdjs.multiplayerCode.GDrifleObjects2[i].getVariables().getFromIndex(0).getChild("id")) == ((gdjs.multiplayerCode.GDplayer1Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.multiplayerCode.GDplayer1Objects2[0].getVariables()).getFromIndex(2).getChild("id").getAsString() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDrifleObjects2[k] = gdjs.multiplayerCode.GDrifleObjects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDrifleObjects2.length = k;
if (isConditionTrue_0) {
}

}


};gdjs.multiplayerCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__THNK__OnClientConnect.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16192420);
}
}
if (isConditionTrue_0) {
gdjs.multiplayerCode.GDplayer1Objects3.length = 0;

gdjs.multiplayerCode.GDrifleObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects3Objects, 500, 300, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDrifleObjects3Objects, 200, 200, "");
}{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects3.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects3[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects3[i].getVariables().getFromIndex(2).getChild("id")).setString(gdjs.evtsExt__THNK__PickedPlayer.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects3.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects3[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects3[i].getVariables().getFromIndex(1)).setString(gdjs.evtsExt__THNK__PickedPlayer.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDrifleObjects3.length ;i < len;++i) {
    gdjs.multiplayerCode.GDrifleObjects3[i].returnVariable(gdjs.multiplayerCode.GDrifleObjects3[i].getVariables().getFromIndex(0).getChild("id")).setString(gdjs.evtsExt__THNK__PickedPlayer.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{gdjs.evtsExt__THNK__LinkObjectToPlayer.func(runtimeScene, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__THNK__LinkObjectToPlayer.func(runtimeScene, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDrifleObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__THNK__OnClientDisconnect.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDplayer1Objects2.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDplayer1Objects2[i].getVariableString(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(1)) == gdjs.evtsExt__THNK__PickedPlayer.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDplayer1Objects2[k] = gdjs.multiplayerCode.GDplayer1Objects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDplayer1Objects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects2 */
{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.multiplayerCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.multiplayerCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDplayer1Objects2.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDplayer1Objects2[i].getVariableBoolean(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("down"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDplayer1Objects2[k] = gdjs.multiplayerCode.GDplayer1Objects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDplayer1Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects2 */
{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDplayer1Objects2.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDplayer1Objects2[i].getVariableBoolean(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("right"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDplayer1Objects2[k] = gdjs.multiplayerCode.GDplayer1Objects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDplayer1Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects2 */
{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDplayer1Objects2.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDplayer1Objects2[i].getVariableBoolean(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("left"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDplayer1Objects2[k] = gdjs.multiplayerCode.GDplayer1Objects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDplayer1Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects2 */
{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDplayer1Objects1[i].getVariableBoolean(gdjs.multiplayerCode.GDplayer1Objects1[i].getVariables().getFromIndex(2).getChild("up"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDplayer1Objects1[k] = gdjs.multiplayerCode.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDplayer1Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


};gdjs.multiplayerCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false, false);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(true);
}
{ //Subevents
gdjs.multiplayerCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.multiplayerCode.eventsList7(runtimeScene);
}


{


gdjs.multiplayerCode.eventsList8(runtimeScene);
}


};gdjs.multiplayerCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__THNK__StartServerCode.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {

{ //Subevents
gdjs.multiplayerCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects2Objects = Hashtable.newFrom({"player1": gdjs.multiplayerCode.GDplayer1Objects2});
gdjs.multiplayerCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1, gdjs.multiplayerCode.GDplayer1Objects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects2Objects);
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDNewBBTextObjects2 */
/* Reuse gdjs.multiplayerCode.GDplayer1Objects2 */
{for(var i = 0, len = gdjs.multiplayerCode.GDNewBBTextObjects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDNewBBTextObjects2[i].setBBText(gdjs.multiplayerCode.GDNewBBTextObjects2[i].getBBText() + (gdjs.evtTools.network.objectVariableStructureToJSON((gdjs.multiplayerCode.GDplayer1Objects2.length !== 0 ? gdjs.multiplayerCode.GDplayer1Objects2[0] : null), ((gdjs.multiplayerCode.GDplayer1Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.multiplayerCode.GDplayer1Objects2[0].getVariables()).getFromIndex(2)) + gdjs.evtTools.string.newLine() + "state json: " + gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().get("state"))));
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDNewBBTextObjects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDNewBBTextObjects2[i].setY(gdjs.evtTools.window.getWindowInnerHeight() - (gdjs.multiplayerCode.GDNewBBTextObjects2[i].getHeight()));
}
}}

}


};gdjs.multiplayerCode.eventsList12 = function(runtimeScene) {

{



}


{

gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.multiplayerCode.GDShadedDarkJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDShadedDarkJoystickObjects3.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[i].IsDirectionPushed4Way("Up", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[k] = gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDShadedDarkJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDShadedDarkJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final.indexOf(gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[j]) === -1 )
            gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final.push(gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final, gdjs.multiplayerCode.GDShadedDarkJoystickObjects2);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1, gdjs.multiplayerCode.GDplayer1Objects2);

{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("up")).setBoolean(true);
}
}}

}


{

gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.multiplayerCode.GDShadedDarkJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDShadedDarkJoystickObjects3.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[i].IsDirectionPushed8Way("Down", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[k] = gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDShadedDarkJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDShadedDarkJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final.indexOf(gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[j]) === -1 )
            gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final.push(gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final, gdjs.multiplayerCode.GDShadedDarkJoystickObjects2);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1, gdjs.multiplayerCode.GDplayer1Objects2);

{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("down")).setBoolean(true);
}
}}

}


{

gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.multiplayerCode.GDShadedDarkJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDShadedDarkJoystickObjects3.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[i].IsDirectionPushed8Way("Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[k] = gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDShadedDarkJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDShadedDarkJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final.indexOf(gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[j]) === -1 )
            gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final.push(gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final, gdjs.multiplayerCode.GDShadedDarkJoystickObjects2);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1, gdjs.multiplayerCode.GDplayer1Objects2);

{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("right")).setBoolean(true);
}
}}

}


{

gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.multiplayerCode.GDShadedDarkJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDShadedDarkJoystickObjects3.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[i].IsDirectionPushed8Way("Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[k] = gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDShadedDarkJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDShadedDarkJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final.indexOf(gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[j]) === -1 )
            gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final.push(gdjs.multiplayerCode.GDShadedDarkJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.multiplayerCode.GDShadedDarkJoystickObjects2_1final, gdjs.multiplayerCode.GDShadedDarkJoystickObjects2);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1, gdjs.multiplayerCode.GDplayer1Objects2);

{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("left")).setBoolean(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.multiplayerCode.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( !(gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("Up", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[k] = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "w"));
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1, gdjs.multiplayerCode.GDplayer1Objects2);

{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("up")).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.multiplayerCode.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( !(gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("Down", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[k] = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "s"));
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1, gdjs.multiplayerCode.GDplayer1Objects2);

{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("down")).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.multiplayerCode.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( !(gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[k] = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "d"));
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1, gdjs.multiplayerCode.GDplayer1Objects2);

{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("right")).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.multiplayerCode.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( !(gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[k] = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "a"));
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1, gdjs.multiplayerCode.GDplayer1Objects2);

{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("left")).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.multiplayerCode.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("UpLeft", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[k] = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1, gdjs.multiplayerCode.GDplayer1Objects2);

{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("up")).setBoolean(true);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("left")).setBoolean(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.multiplayerCode.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("UpRight", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[k] = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1, gdjs.multiplayerCode.GDplayer1Objects2);

{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("up")).setBoolean(true);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("right")).setBoolean(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.multiplayerCode.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("DownLeft", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[k] = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1, gdjs.multiplayerCode.GDplayer1Objects2);

{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("up")).setBoolean(true);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("left")).setBoolean(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.multiplayerCode.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("DownRight", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[k] = gdjs.multiplayerCode.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1, gdjs.multiplayerCode.GDplayer1Objects2);

{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("down")).setBoolean(true);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects2[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects2[i].getVariables().getFromIndex(2).getChild("right")).setBoolean(true);
}
}}

}


{



}


{



}


{



}


{



}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.multiplayerCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewBBText"), gdjs.multiplayerCode.GDNewBBTextObjects2);
{for(var i = 0, len = gdjs.multiplayerCode.GDNewBBTextObjects2.length ;i < len;++i) {
    gdjs.multiplayerCode.GDNewBBTextObjects2[i].setBBText("");
}
}
{ //Subevents
gdjs.multiplayerCode.eventsList11(runtimeScene);} //End of subevents
}

}


{


gdjs.multiplayerCode.eventsList12(runtimeScene);
}


};gdjs.multiplayerCode.mapOfEmptyGDplayer1Objects = Hashtable.newFrom({"player1": []});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwaveObjects2Objects = Hashtable.newFrom({"wave": gdjs.multiplayerCode.GDwaveObjects2});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects2Objects = Hashtable.newFrom({"player1": gdjs.multiplayerCode.GDplayer1Objects2});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDdiverObjects2Objects = Hashtable.newFrom({"diver": gdjs.multiplayerCode.GDdiverObjects2});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects2Objects = Hashtable.newFrom({"player1": gdjs.multiplayerCode.GDplayer1Objects2});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbackObjects2Objects = Hashtable.newFrom({"back": gdjs.multiplayerCode.GDbackObjects2});
gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDstateObjects2Objects = Hashtable.newFrom({"state": gdjs.multiplayerCode.GDstateObjects2});
gdjs.multiplayerCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.multiplayerCode.GDbackObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbackObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeNumberInJSONFile("sc", "sc", runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").getAsNumber());
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level select", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.multiplayerCode.GDstateObjects2);
gdjs.copyArray(runtimeScene.getObjects("win_fail"), gdjs.multiplayerCode.GDwin_9595failObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDwin_9595failObjects2.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDwin_9595failObjects2[i].getBehavior("Text").getText() == "you fail" ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDwin_9595failObjects2[k] = gdjs.multiplayerCode.GDwin_9595failObjects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDwin_9595failObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDstateObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "rogue", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("win_fail"), gdjs.multiplayerCode.GDwin_9595failObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDwin_9595failObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDwin_9595failObjects1[i].getBehavior("Text").getText() == "you fail" ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDwin_9595failObjects1[k] = gdjs.multiplayerCode.GDwin_9595failObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDwin_9595failObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.multiplayerCode.GDstateObjects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDstateObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDstateObjects1[i].getBehavior("Text").setText("restart");
}
}}

}


};gdjs.multiplayerCode.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.multiplayerCode.GDrifleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("touch"), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDrifleObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDrifleObjects1[i].getVariableString(gdjs.multiplayerCode.GDrifleObjects1[i].getVariables().getFromIndex(0).getChild("id")) == gdjs.evtTools.p2p.getCurrentId() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDrifleObjects1[k] = gdjs.multiplayerCode.GDrifleObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDrifleObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDrifleObjects1 */
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.multiplayerCode.GDshootObjects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDrifleObjects1[i].rotateTowardAngle((( gdjs.multiplayerCode.GDshootObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDshootObjects1[0].StickAngle((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), 0, runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.multiplayerCode.GDrifleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("touch"), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDrifleObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDrifleObjects1[i].getVariableString(gdjs.multiplayerCode.GDrifleObjects1[i].getVariables().getFromIndex(0).getChild("id")) == gdjs.evtTools.p2p.getCurrentId() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDrifleObjects1[k] = gdjs.multiplayerCode.GDrifleObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDrifleObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDrifleObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDrifleObjects1[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfEmptyGDplayer1Objects) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDplayer1Objects1[i].getVariableString(gdjs.multiplayerCode.GDplayer1Objects1[i].getVariables().getFromIndex(2).getChild("id")) == gdjs.evtTools.p2p.getCurrentId() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDplayer1Objects1[k] = gdjs.multiplayerCode.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDplayer1Objects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("life"), gdjs.multiplayerCode.GDlifeObjects1);
/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
gdjs.copyArray(runtimeScene.getObjects("reload2"), gdjs.multiplayerCode.GDreload2Objects1);
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.multiplayerCode.GDwaterObjects1);
gdjs.copyArray(runtimeScene.getObjects("water_particlees"), gdjs.multiplayerCode.GDwater_9595particleesObjects1);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "centre on player1", (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getCenterXInScene()), (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getCenterYInScene()), "", "linear", 0.1);
}{for(var i = 0, len = gdjs.multiplayerCode.GDreload2Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDreload2Objects1[i].getBehavior("Resizable").setWidth(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) * 128);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDwaterObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDwaterObjects1[i].setXOffset(gdjs.multiplayerCode.GDwaterObjects1[i].getXOffset() + (0.4));
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDwater_9595particleesObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDwater_9595particleesObjects1[i].setXOffset(gdjs.multiplayerCode.GDwater_9595particleesObjects1[i].getXOffset() + (0.4));
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDlifeObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDlifeObjects1[i].getBehavior("Resizable").setWidth(((gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.multiplayerCode.GDplayer1Objects1[0].getVariables()).getFromIndex(0).getAsNumber() / 10 * (32));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.multiplayerCode.GDbulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.multiplayerCode.GDsmasherObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsmasherObjects1Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDbulletObjects1 */
/* Reuse gdjs.multiplayerCode.GDsmasherObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDsmasherObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.multiplayerCode.GDbulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.multiplayerCode.GDclonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDclonObjects1Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDbulletObjects1 */
/* Reuse gdjs.multiplayerCode.GDclonObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDclonObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.multiplayerCode.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.multiplayerCode.GDsmasherObjects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDclonObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getPointX("")), (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDsmasherObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getPointX("")), (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getPointY("")));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) > 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("reload"), gdjs.multiplayerCode.GDreloadObjects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDreloadObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDreloadObjects1[i].getBehavior("Text").setText("ready");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) < 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("reload"), gdjs.multiplayerCode.GDreloadObjects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDreloadObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDreloadObjects1[i].getBehavior("Text").setText("reloading...");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hit_box"), gdjs.multiplayerCode.GDhit_9595boxObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects1Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDhit_95959595boxObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDhit_9595boxObjects1 */
/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDhit_95959595boxObjects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blocker"), gdjs.multiplayerCode.GDblockerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDblockerObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDblockerObjects1[i].getVariableBoolean(gdjs.multiplayerCode.GDblockerObjects1[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDblockerObjects1[k] = gdjs.multiplayerCode.GDblockerObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDblockerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDblockerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDblockerObjects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.multiplayerCode.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.multiplayerCode.GDbossObjects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.multiplayerCode.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.multiplayerCode.GDdiverObjects1);
gdjs.copyArray(runtimeScene.getObjects("sensor"), gdjs.multiplayerCode.GDsensorObjects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.multiplayerCode.GDsmasherObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsmasherObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDclonObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDblast_95959595botObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDdiverObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDbossObjects1Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsensorObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDblast_9595botObjects1 */
/* Reuse gdjs.multiplayerCode.GDbossObjects1 */
/* Reuse gdjs.multiplayerCode.GDclonObjects1 */
/* Reuse gdjs.multiplayerCode.GDdiverObjects1 */
/* Reuse gdjs.multiplayerCode.GDsensorObjects1 */
/* Reuse gdjs.multiplayerCode.GDsmasherObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDsmasherObjects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsensorObjects1Objects, false);
}
for(var i = 0, len = gdjs.multiplayerCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDclonObjects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsensorObjects1Objects, false);
}
for(var i = 0, len = gdjs.multiplayerCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDblast_9595botObjects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsensorObjects1Objects, false);
}
for(var i = 0, len = gdjs.multiplayerCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDdiverObjects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsensorObjects1Objects, false);
}
for(var i = 0, len = gdjs.multiplayerCode.GDbossObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDbossObjects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsensorObjects1Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.multiplayerCode.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.multiplayerCode.GDbossObjects1);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue_side"), gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.multiplayerCode.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.multiplayerCode.GDdiverObjects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.multiplayerCode.GDsmasherObjects1);
gdjs.copyArray(runtimeScene.getObjects("water_particlees2"), gdjs.multiplayerCode.GDwater_9595particlees2Objects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDsmasherObjects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects, false);
}
for(var i = 0, len = gdjs.multiplayerCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDclonObjects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects, false);
}
for(var i = 0, len = gdjs.multiplayerCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDblast_9595botObjects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects, false);
}
for(var i = 0, len = gdjs.multiplayerCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDdiverObjects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects, false);
}
for(var i = 0, len = gdjs.multiplayerCode.GDbossObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDbossObjects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects, false);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDsmasherObjects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwater_95959595particlees2Objects1Objects, false);
}
for(var i = 0, len = gdjs.multiplayerCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDclonObjects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwater_95959595particlees2Objects1Objects, false);
}
for(var i = 0, len = gdjs.multiplayerCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDblast_9595botObjects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwater_95959595particlees2Objects1Objects, false);
}
for(var i = 0, len = gdjs.multiplayerCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDdiverObjects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwater_95959595particlees2Objects1Objects, false);
}
for(var i = 0, len = gdjs.multiplayerCode.GDbossObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDbossObjects1[i].separateFromObjectsList(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwater_95959595particlees2Objects1Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("level"), gdjs.multiplayerCode.GDlevelObjects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDlevelObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDlevelObjects1[i].getBehavior("Text").setText("level: " + runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").getAsString());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) < (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getPointX(""));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDplayer1Objects1[i].getVariableString(gdjs.multiplayerCode.GDplayer1Objects1[i].getVariables().getFromIndex(2).getChild("id")) == gdjs.evtTools.p2p.getCurrentId() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDplayer1Objects1[k] = gdjs.multiplayerCode.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDplayer1Objects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.multiplayerCode.GDrifleObjects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDrifleObjects1[i].getBehavior("Flippable").flipY(true);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects1[i].getBehavior("Flippable").flipX(true);
}
}
{ //Subevents
gdjs.multiplayerCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) > (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getPointX(""));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDplayer1Objects1[i].getVariableString(gdjs.multiplayerCode.GDplayer1Objects1[i].getVariables().getFromIndex(2).getChild("id")) == gdjs.evtTools.p2p.getCurrentId() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDplayer1Objects1[k] = gdjs.multiplayerCode.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDplayer1Objects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.multiplayerCode.GDrifleObjects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDrifleObjects1[i].getBehavior("Flippable").flipY(false);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects1[i].getBehavior("Flippable").flipX(false);
}
}
{ //Subevents
gdjs.multiplayerCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) > 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "fail"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("touch"), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDplayer1Objects1[i].getVariableString(gdjs.multiplayerCode.GDplayer1Objects1[i].getVariables().getFromIndex(2).getChild("id")) == gdjs.evtTools.p2p.getCurrentId() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDplayer1Objects1[k] = gdjs.multiplayerCode.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDplayer1Objects1.length = k;
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.multiplayerCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);
gdjs.multiplayerCode.GDshootObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.multiplayerCode.GDshootObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.multiplayerCode.GDshootObjects2.length = 0;

{gdjs.multiplayerCode.GDshootObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.multiplayerCode.GDshootObjects3);
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDshootObjects3.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDshootObjects3[i].StickForceX((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) > 0.3 ) {
        isConditionTrue_2 = true;
        gdjs.multiplayerCode.GDshootObjects3[k] = gdjs.multiplayerCode.GDshootObjects3[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDshootObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDshootObjects3.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDshootObjects2_2final.indexOf(gdjs.multiplayerCode.GDshootObjects3[j]) === -1 )
            gdjs.multiplayerCode.GDshootObjects2_2final.push(gdjs.multiplayerCode.GDshootObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.multiplayerCode.GDshootObjects3);
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDshootObjects3.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDshootObjects3[i].StickForceY((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) > 0.3 ) {
        isConditionTrue_2 = true;
        gdjs.multiplayerCode.GDshootObjects3[k] = gdjs.multiplayerCode.GDshootObjects3[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDshootObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDshootObjects3.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDshootObjects2_2final.indexOf(gdjs.multiplayerCode.GDshootObjects3[j]) === -1 )
            gdjs.multiplayerCode.GDshootObjects2_2final.push(gdjs.multiplayerCode.GDshootObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.multiplayerCode.GDshootObjects2_2final, gdjs.multiplayerCode.GDshootObjects2);
}
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDshootObjects2.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDshootObjects1_1final.indexOf(gdjs.multiplayerCode.GDshootObjects2[j]) === -1 )
            gdjs.multiplayerCode.GDshootObjects1_1final.push(gdjs.multiplayerCode.GDshootObjects2[j]);
    }
}
}
{
gdjs.multiplayerCode.GDshootObjects2.length = 0;

{gdjs.multiplayerCode.GDshootObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.multiplayerCode.GDshootObjects3);
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDshootObjects3.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDshootObjects3[i].StickForceX((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) < -(0.3) ) {
        isConditionTrue_2 = true;
        gdjs.multiplayerCode.GDshootObjects3[k] = gdjs.multiplayerCode.GDshootObjects3[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDshootObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDshootObjects3.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDshootObjects2_2final.indexOf(gdjs.multiplayerCode.GDshootObjects3[j]) === -1 )
            gdjs.multiplayerCode.GDshootObjects2_2final.push(gdjs.multiplayerCode.GDshootObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.multiplayerCode.GDshootObjects3);
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDshootObjects3.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDshootObjects3[i].StickForceY((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) < -(0.3) ) {
        isConditionTrue_2 = true;
        gdjs.multiplayerCode.GDshootObjects3[k] = gdjs.multiplayerCode.GDshootObjects3[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDshootObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDshootObjects3.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDshootObjects2_2final.indexOf(gdjs.multiplayerCode.GDshootObjects3[j]) === -1 )
            gdjs.multiplayerCode.GDshootObjects2_2final.push(gdjs.multiplayerCode.GDshootObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.multiplayerCode.GDshootObjects2_2final, gdjs.multiplayerCode.GDshootObjects2);
}
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDshootObjects2.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDshootObjects1_1final.indexOf(gdjs.multiplayerCode.GDshootObjects2[j]) === -1 )
            gdjs.multiplayerCode.GDshootObjects1_1final.push(gdjs.multiplayerCode.GDshootObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.multiplayerCode.GDshootObjects1_1final, gdjs.multiplayerCode.GDshootObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) > 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "fail"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("touch"), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDplayer1Objects1[i].getVariableString(gdjs.multiplayerCode.GDplayer1Objects1[i].getVariables().getFromIndex(2).getChild("id")) == gdjs.evtTools.p2p.getCurrentId() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDplayer1Objects1[k] = gdjs.multiplayerCode.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDplayer1Objects1.length = k;
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.multiplayerCode.GDrifleObjects1);
gdjs.multiplayerCode.GDbulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects1Objects, (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getAABBCenterX()), (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getAABBCenterY()), "");
}{for(var i = 0, len = gdjs.multiplayerCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDbulletObjects1[i].addPolarForce((( gdjs.multiplayerCode.GDrifleObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDrifleObjects1[0].getAngle()), 1000, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 40, gdjs.randomInRange(0.8, 1.2));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.55, 0.33, 0.50, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.multiplayerCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.multiplayerCode.GDrifleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) < 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfEmptyGDrifleObjects) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDrifleObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDrifleObjects1[i].getVariableString(gdjs.multiplayerCode.GDrifleObjects1[i].getVariables().getFromIndex(0).getChild("id")) == gdjs.evtTools.p2p.getCurrentId() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDrifleObjects1[k] = gdjs.multiplayerCode.GDrifleObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDrifleObjects1.length = k;
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(0.05);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("cement_block_blue"), gdjs.multiplayerCode.GDcement_9595block_9595blueObjects1);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue2"), gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects1);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue_side"), gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue_side2"), gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.multiplayerCode.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("door"), gdjs.multiplayerCode.GDdoorObjects1);
gdjs.copyArray(runtimeScene.getObjects("hit_box"), gdjs.multiplayerCode.GDhit_9595boxObjects1);
gdjs.copyArray(runtimeScene.getObjects("pillar"), gdjs.multiplayerCode.GDpillarObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.multiplayerCode.GDrifleObjects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.multiplayerCode.GDsmasherObjects1);
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.multiplayerCode.GDwaterObjects1);
gdjs.copyArray(runtimeScene.getObjects("water_particlees"), gdjs.multiplayerCode.GDwater_9595particleesObjects1);
gdjs.copyArray(runtimeScene.getObjects("water_particlees2"), gdjs.multiplayerCode.GDwater_9595particlees2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDplayer1Objects1[i].getZOrder() > (gdjs.multiplayerCode.GDplayer1Objects1[i].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDplayer1Objects1[k] = gdjs.multiplayerCode.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDplayer1Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDpillarObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDpillarObjects1[i].getZOrder() > (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDpillarObjects1[k] = gdjs.multiplayerCode.GDpillarObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDpillarObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDcement_9595block_9595blueObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDcement_9595block_9595blueObjects1[i].getZOrder() > (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDcement_9595block_9595blueObjects1[k] = gdjs.multiplayerCode.GDcement_9595block_9595blueObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDcement_9595block_9595blueObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDclonObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDclonObjects1[i].getZOrder() > (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDclonObjects1[k] = gdjs.multiplayerCode.GDclonObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDclonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects1[i].getZOrder() > (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects1[k] = gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDsmasherObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDsmasherObjects1[i].getZOrder() > (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDsmasherObjects1[k] = gdjs.multiplayerCode.GDsmasherObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDsmasherObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDdoorObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDdoorObjects1[i].getZOrder() > (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDdoorObjects1[k] = gdjs.multiplayerCode.GDdoorObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDdoorObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDrifleObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDrifleObjects1[i].getZOrder() > (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDrifleObjects1[k] = gdjs.multiplayerCode.GDrifleObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDrifleObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDhit_9595boxObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDhit_9595boxObjects1[i].getZOrder() > (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDhit_9595boxObjects1[k] = gdjs.multiplayerCode.GDhit_9595boxObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDhit_9595boxObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDwaterObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDwaterObjects1[i].getZOrder() > (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDwaterObjects1[k] = gdjs.multiplayerCode.GDwaterObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDwaterObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1[i].getZOrder() > (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1[k] = gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects1[i].getZOrder() > (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects1[k] = gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDwater_9595particleesObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDwater_9595particleesObjects1[i].getZOrder() > (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDwater_9595particleesObjects1[k] = gdjs.multiplayerCode.GDwater_9595particleesObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDwater_9595particleesObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDwater_9595particlees2Objects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDwater_9595particlees2Objects1[i].getZOrder() > (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDwater_9595particlees2Objects1[k] = gdjs.multiplayerCode.GDwater_9595particlees2Objects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDwater_9595particlees2Objects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.multiplayerCode.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.multiplayerCode.GDbossObjects1);
/* Reuse gdjs.multiplayerCode.GDcement_9595block_9595blueObjects1 */
/* Reuse gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects1 */
/* Reuse gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1 */
/* Reuse gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects1 */
/* Reuse gdjs.multiplayerCode.GDclonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.multiplayerCode.GDdiverObjects1);
/* Reuse gdjs.multiplayerCode.GDdoorObjects1 */
/* Reuse gdjs.multiplayerCode.GDhit_9595boxObjects1 */
/* Reuse gdjs.multiplayerCode.GDpillarObjects1 */
/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
/* Reuse gdjs.multiplayerCode.GDrifleObjects1 */
/* Reuse gdjs.multiplayerCode.GDsmasherObjects1 */
/* Reuse gdjs.multiplayerCode.GDwaterObjects1 */
/* Reuse gdjs.multiplayerCode.GDwater_9595particleesObjects1 */
/* Reuse gdjs.multiplayerCode.GDwater_9595particlees2Objects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.multiplayerCode.GDpillarObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDpillarObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.multiplayerCode.GDcement_9595block_9595blueObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDcement_9595block_9595blueObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.multiplayerCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDclonObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.multiplayerCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDsmasherObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.multiplayerCode.GDdoorObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDdoorObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.multiplayerCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDrifleObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.multiplayerCode.GDhit_9595boxObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDhit_9595boxObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.multiplayerCode.GDwaterObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDwaterObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.multiplayerCode.GDwater_9595particleesObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDwater_9595particleesObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.multiplayerCode.GDwater_9595particlees2Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDwater_9595particlees2Objects1[i].setZOrder(7);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDsmasherObjects1[i].setZOrder(9);
}
for(var i = 0, len = gdjs.multiplayerCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDclonObjects1[i].setZOrder(9);
}
for(var i = 0, len = gdjs.multiplayerCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDblast_9595botObjects1[i].setZOrder(9);
}
for(var i = 0, len = gdjs.multiplayerCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDdiverObjects1[i].setZOrder(9);
}
for(var i = 0, len = gdjs.multiplayerCode.GDbossObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDbossObjects1[i].setZOrder(9);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects1[i].setZOrder(200);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDrifleObjects1[i].setZOrder(201);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.multiplayerCode.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("blocker"), gdjs.multiplayerCode.GDblockerObjects1);
gdjs.copyArray(runtimeScene.getObjects("hit_box"), gdjs.multiplayerCode.GDhit_9595boxObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.multiplayerCode.GDrifleObjects1);
gdjs.copyArray(runtimeScene.getObjects("sensor"), gdjs.multiplayerCode.GDsensorObjects1);
gdjs.copyArray(runtimeScene.getObjects("sensor2"), gdjs.multiplayerCode.GDsensor2Objects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}{for(var i = 0, len = gdjs.multiplayerCode.GDhit_9595boxObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDhit_9595boxObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDrifleObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDrifleObjects1[i].setZOrder(101);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDsensorObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDsensorObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDblockerObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDblockerObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDsensor2Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDsensor2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDblast_9595botObjects1[i].resetTimer("blast");
}
}
{ //Subevents
gdjs.multiplayerCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("sensor"), gdjs.multiplayerCode.GDsensorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDsensorObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDsensorObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDsensorObjects1[k] = gdjs.multiplayerCode.GDsensorObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDsensorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDsensorObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDsensorObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDsensorObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hit_box"), gdjs.multiplayerCode.GDhit_9595boxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDhit_9595boxObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDhit_9595boxObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDhit_9595boxObjects1[k] = gdjs.multiplayerCode.GDhit_9595boxObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDhit_9595boxObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDhit_9595boxObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDhit_9595boxObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDhit_9595boxObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDplayer1Objects1[i].getVariableNumber(gdjs.multiplayerCode.GDplayer1Objects1[i].getVariables().getFromIndex(0)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDplayer1Objects1[k] = gdjs.multiplayerCode.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDplayer1Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("cement_block_blue"), gdjs.multiplayerCode.GDcement_9595block_9595blueObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.multiplayerCode.GDwaterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects1Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwaterObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects1Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDcement_95959595block_95959595blueObjects1Objects, true, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.multiplayerCode.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.multiplayerCode.GDbossObjects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.multiplayerCode.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.multiplayerCode.GDdiverObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.multiplayerCode.GDsmasherObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects1Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsmasherObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDclonObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDblast_95959595botObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDdiverObjects1ObjectsGDgdjs_9546multiplayerCode_9546GDbossObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDsmasherObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDsmasherObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDsmasherObjects1[k] = gdjs.multiplayerCode.GDsmasherObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDsmasherObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDclonObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDclonObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDclonObjects1[k] = gdjs.multiplayerCode.GDclonObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDclonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDblast_9595botObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDblast_9595botObjects1[k] = gdjs.multiplayerCode.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDblast_9595botObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDdiverObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDdiverObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDdiverObjects1[k] = gdjs.multiplayerCode.GDdiverObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDdiverObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDbossObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDbossObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDbossObjects1[k] = gdjs.multiplayerCode.GDbossObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDbossObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16165060);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects1[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects1[i].getVariables().getFromIndex(0)).sub(16);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blocker"), gdjs.multiplayerCode.GDblockerObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("sensor2"), gdjs.multiplayerCode.GDsensor2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects1Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDblockerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsensor2Objects1Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDblockerObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDblockerObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDblockerObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDblockerObjects1[i].setVariableBoolean(gdjs.multiplayerCode.GDblockerObjects1[i].getVariables().getFromIndex(0), true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16166524);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.multiplayerCode.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.multiplayerCode.GDdiverObjects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDblast_9595botObjects1[i].resetTimer("blast");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "dive");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "spawn");
}{for(var i = 0, len = gdjs.multiplayerCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDdiverObjects1[i].setZOrder(300);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "dive") >= 4;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.multiplayerCode.GDdiverObjects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDdiverObjects1[i].getBehavior("Animation").setAnimationName("ready");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "dive") >= 6;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.multiplayerCode.GDdiverObjects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDdiverObjects1[i].getBehavior("Animation").setAnimationName("targeting");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "dive");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfEmptyGDbossObjects) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "spawn") >= 8;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16170316);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.multiplayerCode.GDbossObjects1);
gdjs.multiplayerCode.GDclonObjects1.length = 0;

gdjs.multiplayerCode.GDdiverObjects1.length = 0;

gdjs.multiplayerCode.GDsmasherObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDclonObjects1Objects, (( gdjs.multiplayerCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDbossObjects1[0].getPointX("")) + gdjs.randomInRange(100, 400), (( gdjs.multiplayerCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDbossObjects1[0].getPointY("")) + gdjs.randomInRange((( gdjs.multiplayerCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDbossObjects1[0].getPointY("")), 300), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDclonObjects1Objects, (( gdjs.multiplayerCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDbossObjects1[0].getPointX("")) + gdjs.randomInRange(100, 400), (( gdjs.multiplayerCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDbossObjects1[0].getPointY("")) + gdjs.randomInRange((( gdjs.multiplayerCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDbossObjects1[0].getPointY("")), 300), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDclonObjects1Objects, (( gdjs.multiplayerCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDbossObjects1[0].getPointX("")) + gdjs.randomInRange(100, 400), (( gdjs.multiplayerCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDbossObjects1[0].getPointY("")) + gdjs.randomInRange((( gdjs.multiplayerCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDbossObjects1[0].getPointY("")), 300), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDsmasherObjects1Objects, (( gdjs.multiplayerCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDbossObjects1[0].getPointX("")) + gdjs.randomInRange(100, 400), (( gdjs.multiplayerCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDbossObjects1[0].getPointY("")) + gdjs.randomInRange((( gdjs.multiplayerCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDbossObjects1[0].getPointY("")), 300), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDdiverObjects1Objects, (( gdjs.multiplayerCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDbossObjects1[0].getPointX("")) + gdjs.randomInRange(100, 400), (( gdjs.multiplayerCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDbossObjects1[0].getPointY("")) + gdjs.randomInRange((( gdjs.multiplayerCode.GDbossObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDbossObjects1[0].getPointY("")), 300), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "spawn");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.multiplayerCode.GDdiverObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDdiverObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDdiverObjects1[i].getBehavior("Animation").getAnimationName() == "ready" ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDdiverObjects1[k] = gdjs.multiplayerCode.GDdiverObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDdiverObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16175164);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDdiverObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDdiverObjects1[i].rotateTowardPosition((( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getCenterXInScene()), (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getCenterYInScene()), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDdiverObjects1[i].addPolarForce((gdjs.multiplayerCode.GDdiverObjects1[i].getAngle()), 450, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.multiplayerCode.GDdiverObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDdiverObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDdiverObjects1[i].getBehavior("Animation").getAnimationName() == "targeting" ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDdiverObjects1[k] = gdjs.multiplayerCode.GDdiverObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDdiverObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDdiverObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDdiverObjects1[i].clearForces();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.multiplayerCode.GDblast_9595botObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDblast_9595botObjects1[i].getTimerElapsedTimeInSecondsOrNaN("blast") >= 3 ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDblast_9595botObjects1[k] = gdjs.multiplayerCode.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDblast_9595botObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDblast_9595botObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDblast_9595botObjects1[i].getBehavior("Animation").setAnimationName("bot_jump");
}
}}

}


{

gdjs.multiplayerCode.GDplayer1Objects1.length = 0;

gdjs.multiplayerCode.GDwater_9595particleesObjects1.length = 0;

gdjs.multiplayerCode.GDwater_9595particlees2Objects1.length = 0;

gdjs.multiplayerCode.GDwaveObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.multiplayerCode.GDplayer1Objects1_1final.length = 0;
gdjs.multiplayerCode.GDwater_9595particleesObjects1_1final.length = 0;
gdjs.multiplayerCode.GDwater_9595particlees2Objects1_1final.length = 0;
gdjs.multiplayerCode.GDwaveObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("water_particlees2"), gdjs.multiplayerCode.GDwater_9595particlees2Objects2);
gdjs.copyArray(runtimeScene.getObjects("wave"), gdjs.multiplayerCode.GDwaveObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwaveObjects2Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwater_95959595particlees2Objects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDwater_9595particlees2Objects2.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDwater_9595particlees2Objects1_1final.indexOf(gdjs.multiplayerCode.GDwater_9595particlees2Objects2[j]) === -1 )
            gdjs.multiplayerCode.GDwater_9595particlees2Objects1_1final.push(gdjs.multiplayerCode.GDwater_9595particlees2Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.multiplayerCode.GDwaveObjects2.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDwaveObjects1_1final.indexOf(gdjs.multiplayerCode.GDwaveObjects2[j]) === -1 )
            gdjs.multiplayerCode.GDwaveObjects1_1final.push(gdjs.multiplayerCode.GDwaveObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("water_particlees"), gdjs.multiplayerCode.GDwater_9595particleesObjects2);
gdjs.copyArray(runtimeScene.getObjects("wave"), gdjs.multiplayerCode.GDwaveObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwaveObjects2Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwater_95959595particleesObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDwater_9595particleesObjects2.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDwater_9595particleesObjects1_1final.indexOf(gdjs.multiplayerCode.GDwater_9595particleesObjects2[j]) === -1 )
            gdjs.multiplayerCode.GDwater_9595particleesObjects1_1final.push(gdjs.multiplayerCode.GDwater_9595particleesObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.multiplayerCode.GDwaveObjects2.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDwaveObjects1_1final.indexOf(gdjs.multiplayerCode.GDwaveObjects2[j]) === -1 )
            gdjs.multiplayerCode.GDwaveObjects1_1final.push(gdjs.multiplayerCode.GDwaveObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects2);
gdjs.copyArray(runtimeScene.getObjects("wave"), gdjs.multiplayerCode.GDwaveObjects2);
isConditionTrue_1 = gdjs.evtTools.object.distanceTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwaveObjects2Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects2Objects, 4000, true);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDplayer1Objects2.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDplayer1Objects1_1final.indexOf(gdjs.multiplayerCode.GDplayer1Objects2[j]) === -1 )
            gdjs.multiplayerCode.GDplayer1Objects1_1final.push(gdjs.multiplayerCode.GDplayer1Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.multiplayerCode.GDwaveObjects2.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDwaveObjects1_1final.indexOf(gdjs.multiplayerCode.GDwaveObjects2[j]) === -1 )
            gdjs.multiplayerCode.GDwaveObjects1_1final.push(gdjs.multiplayerCode.GDwaveObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1_1final, gdjs.multiplayerCode.GDplayer1Objects1);
gdjs.copyArray(gdjs.multiplayerCode.GDwater_9595particleesObjects1_1final, gdjs.multiplayerCode.GDwater_9595particleesObjects1);
gdjs.copyArray(gdjs.multiplayerCode.GDwater_9595particlees2Objects1_1final, gdjs.multiplayerCode.GDwater_9595particlees2Objects1);
gdjs.copyArray(gdjs.multiplayerCode.GDwaveObjects1_1final, gdjs.multiplayerCode.GDwaveObjects1);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDwaveObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDwaveObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDwaveObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.multiplayerCode.GDblast_9595botObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDblast_9595botObjects1[i].getBehavior("Animation").getAnimationName() == "bot_jump" ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDblast_9595botObjects1[k] = gdjs.multiplayerCode.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDblast_9595botObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDblast_9595botObjects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDblast_9595botObjects1[k] = gdjs.multiplayerCode.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDblast_9595botObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDblast_9595botObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);
gdjs.multiplayerCode.GDwaveObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwaveObjects1Objects, (( gdjs.multiplayerCode.GDblast_9595botObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDblast_9595botObjects1[0].getCenterXInScene()), (( gdjs.multiplayerCode.GDblast_9595botObjects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDblast_9595botObjects1[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.multiplayerCode.GDwaveObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDwaveObjects1[i].rotateTowardPosition((( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getCenterXInScene()), (( gdjs.multiplayerCode.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.multiplayerCode.GDplayer1Objects1[0].getCenterYInScene()), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDblast_9595botObjects1[i].getBehavior("Animation").setAnimationName("bot_idle");
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDblast_9595botObjects1[i].resetTimer("blast");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.multiplayerCode.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.multiplayerCode.GDbulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects1Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDblast_95959595botObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDblast_9595botObjects1 */
/* Reuse gdjs.multiplayerCode.GDbulletObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDblast_9595botObjects1[i].returnVariable(gdjs.multiplayerCode.GDblast_9595botObjects1[i].getVariables().getFromIndex(0)).sub(25);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 40, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.multiplayerCode.GDbulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.multiplayerCode.GDdiverObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects1Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDdiverObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDbulletObjects1 */
/* Reuse gdjs.multiplayerCode.GDdiverObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDdiverObjects1[i].returnVariable(gdjs.multiplayerCode.GDdiverObjects1[i].getVariables().getFromIndex(0)).sub(25);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 40, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.multiplayerCode.GDbossObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.multiplayerCode.GDbulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbulletObjects1Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDbossObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDbossObjects1 */
/* Reuse gdjs.multiplayerCode.GDbulletObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDbossObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDbossObjects1[i].returnVariable(gdjs.multiplayerCode.GDbossObjects1[i].getVariables().getFromIndex(0)).sub(10);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDbulletObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 40, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.multiplayerCode.GDblast_9595botObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDblast_9595botObjects1[i].getVariableNumber(gdjs.multiplayerCode.GDblast_9595botObjects1[i].getVariables().getFromIndex(0)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDblast_9595botObjects1[k] = gdjs.multiplayerCode.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDblast_9595botObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDblast_9595botObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDblast_9595botObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.multiplayerCode.GDdiverObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDdiverObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDdiverObjects1[i].getVariableNumber(gdjs.multiplayerCode.GDdiverObjects1[i].getVariables().getFromIndex(0)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDdiverObjects1[k] = gdjs.multiplayerCode.GDdiverObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDdiverObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDdiverObjects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDdiverObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.multiplayerCode.GDbossObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDbossObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDbossObjects1[i].getVariableNumber(gdjs.multiplayerCode.GDbossObjects1[i].getVariables().getFromIndex(0)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDbossObjects1[k] = gdjs.multiplayerCode.GDbossObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDbossObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.multiplayerCode.GDblast_9595botObjects1);
/* Reuse gdjs.multiplayerCode.GDbossObjects1 */
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.multiplayerCode.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.multiplayerCode.GDdiverObjects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.multiplayerCode.GDsmasherObjects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDbossObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDbossObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.multiplayerCode.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDsmasherObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.multiplayerCode.GDclonObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDclonObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.multiplayerCode.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDblast_9595botObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.multiplayerCode.GDdiverObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDdiverObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.multiplayerCode.GDbossObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDbossObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.multiplayerCode.eventsList10(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDplayer1Objects1[i].getVariableString(gdjs.multiplayerCode.GDplayer1Objects1[i].getVariables().getFromIndex(2).getChild("id")) == gdjs.evtTools.p2p.getCurrentId() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDplayer1Objects1[k] = gdjs.multiplayerCode.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDplayer1Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__THNK__StartClientCode.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.multiplayerCode.eventsList13(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDplayer1Objects1[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDplayer1Objects1[k] = gdjs.multiplayerCode.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDplayer1Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16233196);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "walk", 3, true, 40, 0.3);
}}

}


{

gdjs.multiplayerCode.GDplayer1Objects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.multiplayerCode.GDplayer1Objects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects2);
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDplayer1Objects2.length;i<l;++i) {
    if ( !(gdjs.multiplayerCode.GDplayer1Objects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_1 = true;
        gdjs.multiplayerCode.GDplayer1Objects2[k] = gdjs.multiplayerCode.GDplayer1Objects2[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDplayer1Objects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDplayer1Objects2.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDplayer1Objects1_1final.indexOf(gdjs.multiplayerCode.GDplayer1Objects2[j]) === -1 )
            gdjs.multiplayerCode.GDplayer1Objects1_1final.push(gdjs.multiplayerCode.GDplayer1Objects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.multiplayerCode.mapOfEmptyGDplayer1Objects) < 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1_1final, gdjs.multiplayerCode.GDplayer1Objects1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 3);
}}

}


{

gdjs.multiplayerCode.GDdiverObjects1.length = 0;

gdjs.multiplayerCode.GDplayer1Objects1.length = 0;

gdjs.multiplayerCode.GDwaveObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.multiplayerCode.GDdiverObjects1_1final.length = 0;
gdjs.multiplayerCode.GDplayer1Objects1_1final.length = 0;
gdjs.multiplayerCode.GDwaveObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects2);
gdjs.copyArray(runtimeScene.getObjects("wave"), gdjs.multiplayerCode.GDwaveObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDwaveObjects2Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDplayer1Objects2.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDplayer1Objects1_1final.indexOf(gdjs.multiplayerCode.GDplayer1Objects2[j]) === -1 )
            gdjs.multiplayerCode.GDplayer1Objects1_1final.push(gdjs.multiplayerCode.GDplayer1Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.multiplayerCode.GDwaveObjects2.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDwaveObjects1_1final.indexOf(gdjs.multiplayerCode.GDwaveObjects2[j]) === -1 )
            gdjs.multiplayerCode.GDwaveObjects1_1final.push(gdjs.multiplayerCode.GDwaveObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.multiplayerCode.GDdiverObjects2);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.multiplayerCode.GDplayer1Objects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDdiverObjects2Objects, gdjs.multiplayerCode.mapOfGDgdjs_9546multiplayerCode_9546GDplayer1Objects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.multiplayerCode.GDdiverObjects2.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDdiverObjects1_1final.indexOf(gdjs.multiplayerCode.GDdiverObjects2[j]) === -1 )
            gdjs.multiplayerCode.GDdiverObjects1_1final.push(gdjs.multiplayerCode.GDdiverObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.multiplayerCode.GDplayer1Objects2.length; j < jLen ; ++j) {
        if ( gdjs.multiplayerCode.GDplayer1Objects1_1final.indexOf(gdjs.multiplayerCode.GDplayer1Objects2[j]) === -1 )
            gdjs.multiplayerCode.GDplayer1Objects1_1final.push(gdjs.multiplayerCode.GDplayer1Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.multiplayerCode.GDdiverObjects1_1final, gdjs.multiplayerCode.GDdiverObjects1);
gdjs.copyArray(gdjs.multiplayerCode.GDplayer1Objects1_1final, gdjs.multiplayerCode.GDplayer1Objects1);
gdjs.copyArray(gdjs.multiplayerCode.GDwaveObjects1_1final, gdjs.multiplayerCode.GDwaveObjects1);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.multiplayerCode.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.multiplayerCode.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDplayer1Objects1[i].returnVariable(gdjs.multiplayerCode.GDplayer1Objects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ids"), gdjs.multiplayerCode.GDidsObjects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDidsObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDidsObjects1[i].getBehavior("Text").setText(gdjs.evtTools.p2p.getCurrentId());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.multiplayerCode.GDblast_9595botObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.multiplayerCode.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.multiplayerCode.GDblast_9595botObjects1[i].getBehavior("Animation").getAnimationName() == "bot_idle" ) {
        isConditionTrue_0 = true;
        gdjs.multiplayerCode.GDblast_9595botObjects1[k] = gdjs.multiplayerCode.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.multiplayerCode.GDblast_9595botObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("wave"), gdjs.multiplayerCode.GDwaveObjects1);
{for(var i = 0, len = gdjs.multiplayerCode.GDwaveObjects1.length ;i < len;++i) {
    gdjs.multiplayerCode.GDwaveObjects1[i].addPolarForce((gdjs.multiplayerCode.GDwaveObjects1[i].getAngle()), 300, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "fail");
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 3);
}
{ //Subevents
gdjs.multiplayerCode.eventsList14(runtimeScene);} //End of subevents
}

}


};

gdjs.multiplayerCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.multiplayerCode.GDplayer1Objects1.length = 0;
gdjs.multiplayerCode.GDplayer1Objects2.length = 0;
gdjs.multiplayerCode.GDplayer1Objects3.length = 0;
gdjs.multiplayerCode.GDplayer1Objects4.length = 0;
gdjs.multiplayerCode.GDpillarObjects1.length = 0;
gdjs.multiplayerCode.GDpillarObjects2.length = 0;
gdjs.multiplayerCode.GDpillarObjects3.length = 0;
gdjs.multiplayerCode.GDpillarObjects4.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blueObjects1.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blueObjects2.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blueObjects3.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blueObjects4.length = 0;
gdjs.multiplayerCode.GDclonObjects1.length = 0;
gdjs.multiplayerCode.GDclonObjects2.length = 0;
gdjs.multiplayerCode.GDclonObjects3.length = 0;
gdjs.multiplayerCode.GDclonObjects4.length = 0;
gdjs.multiplayerCode.GDsmasherObjects1.length = 0;
gdjs.multiplayerCode.GDsmasherObjects2.length = 0;
gdjs.multiplayerCode.GDsmasherObjects3.length = 0;
gdjs.multiplayerCode.GDsmasherObjects4.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects1.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects2.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects3.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects4.length = 0;
gdjs.multiplayerCode.GDdoorObjects1.length = 0;
gdjs.multiplayerCode.GDdoorObjects2.length = 0;
gdjs.multiplayerCode.GDdoorObjects3.length = 0;
gdjs.multiplayerCode.GDdoorObjects4.length = 0;
gdjs.multiplayerCode.GDrifleObjects1.length = 0;
gdjs.multiplayerCode.GDrifleObjects2.length = 0;
gdjs.multiplayerCode.GDrifleObjects3.length = 0;
gdjs.multiplayerCode.GDrifleObjects4.length = 0;
gdjs.multiplayerCode.GDhit_9595boxObjects1.length = 0;
gdjs.multiplayerCode.GDhit_9595boxObjects2.length = 0;
gdjs.multiplayerCode.GDhit_9595boxObjects3.length = 0;
gdjs.multiplayerCode.GDhit_9595boxObjects4.length = 0;
gdjs.multiplayerCode.GDbulletObjects1.length = 0;
gdjs.multiplayerCode.GDbulletObjects2.length = 0;
gdjs.multiplayerCode.GDbulletObjects3.length = 0;
gdjs.multiplayerCode.GDbulletObjects4.length = 0;
gdjs.multiplayerCode.GDreloadObjects1.length = 0;
gdjs.multiplayerCode.GDreloadObjects2.length = 0;
gdjs.multiplayerCode.GDreloadObjects3.length = 0;
gdjs.multiplayerCode.GDreloadObjects4.length = 0;
gdjs.multiplayerCode.GDreload2Objects1.length = 0;
gdjs.multiplayerCode.GDreload2Objects2.length = 0;
gdjs.multiplayerCode.GDreload2Objects3.length = 0;
gdjs.multiplayerCode.GDreload2Objects4.length = 0;
gdjs.multiplayerCode.GDwaterObjects1.length = 0;
gdjs.multiplayerCode.GDwaterObjects2.length = 0;
gdjs.multiplayerCode.GDwaterObjects3.length = 0;
gdjs.multiplayerCode.GDwaterObjects4.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects2.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects3.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects4.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects1.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects2.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects3.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects4.length = 0;
gdjs.multiplayerCode.GDwater_9595particleesObjects1.length = 0;
gdjs.multiplayerCode.GDwater_9595particleesObjects2.length = 0;
gdjs.multiplayerCode.GDwater_9595particleesObjects3.length = 0;
gdjs.multiplayerCode.GDwater_9595particleesObjects4.length = 0;
gdjs.multiplayerCode.GDwater_9595particlees2Objects1.length = 0;
gdjs.multiplayerCode.GDwater_9595particlees2Objects2.length = 0;
gdjs.multiplayerCode.GDwater_9595particlees2Objects3.length = 0;
gdjs.multiplayerCode.GDwater_9595particlees2Objects4.length = 0;
gdjs.multiplayerCode.GDlifeObjects1.length = 0;
gdjs.multiplayerCode.GDlifeObjects2.length = 0;
gdjs.multiplayerCode.GDlifeObjects3.length = 0;
gdjs.multiplayerCode.GDlifeObjects4.length = 0;
gdjs.multiplayerCode.GDbackgroundObjects1.length = 0;
gdjs.multiplayerCode.GDbackgroundObjects2.length = 0;
gdjs.multiplayerCode.GDbackgroundObjects3.length = 0;
gdjs.multiplayerCode.GDbackgroundObjects4.length = 0;
gdjs.multiplayerCode.GDwin_9595failObjects1.length = 0;
gdjs.multiplayerCode.GDwin_9595failObjects2.length = 0;
gdjs.multiplayerCode.GDwin_9595failObjects3.length = 0;
gdjs.multiplayerCode.GDwin_9595failObjects4.length = 0;
gdjs.multiplayerCode.GDstateObjects1.length = 0;
gdjs.multiplayerCode.GDstateObjects2.length = 0;
gdjs.multiplayerCode.GDstateObjects3.length = 0;
gdjs.multiplayerCode.GDstateObjects4.length = 0;
gdjs.multiplayerCode.GDlineObjects1.length = 0;
gdjs.multiplayerCode.GDlineObjects2.length = 0;
gdjs.multiplayerCode.GDlineObjects3.length = 0;
gdjs.multiplayerCode.GDlineObjects4.length = 0;
gdjs.multiplayerCode.GDsensorObjects1.length = 0;
gdjs.multiplayerCode.GDsensorObjects2.length = 0;
gdjs.multiplayerCode.GDsensorObjects3.length = 0;
gdjs.multiplayerCode.GDsensorObjects4.length = 0;
gdjs.multiplayerCode.GDblockerObjects1.length = 0;
gdjs.multiplayerCode.GDblockerObjects2.length = 0;
gdjs.multiplayerCode.GDblockerObjects3.length = 0;
gdjs.multiplayerCode.GDblockerObjects4.length = 0;
gdjs.multiplayerCode.GDsensor2Objects1.length = 0;
gdjs.multiplayerCode.GDsensor2Objects2.length = 0;
gdjs.multiplayerCode.GDsensor2Objects3.length = 0;
gdjs.multiplayerCode.GDsensor2Objects4.length = 0;
gdjs.multiplayerCode.GDsmasher_9595aObjects1.length = 0;
gdjs.multiplayerCode.GDsmasher_9595aObjects2.length = 0;
gdjs.multiplayerCode.GDsmasher_9595aObjects3.length = 0;
gdjs.multiplayerCode.GDsmasher_9595aObjects4.length = 0;
gdjs.multiplayerCode.GDblast_9595botObjects1.length = 0;
gdjs.multiplayerCode.GDblast_9595botObjects2.length = 0;
gdjs.multiplayerCode.GDblast_9595botObjects3.length = 0;
gdjs.multiplayerCode.GDblast_9595botObjects4.length = 0;
gdjs.multiplayerCode.GDwaveObjects1.length = 0;
gdjs.multiplayerCode.GDwaveObjects2.length = 0;
gdjs.multiplayerCode.GDwaveObjects3.length = 0;
gdjs.multiplayerCode.GDwaveObjects4.length = 0;
gdjs.multiplayerCode.GDdiverObjects1.length = 0;
gdjs.multiplayerCode.GDdiverObjects2.length = 0;
gdjs.multiplayerCode.GDdiverObjects3.length = 0;
gdjs.multiplayerCode.GDdiverObjects4.length = 0;
gdjs.multiplayerCode.GDlevelObjects1.length = 0;
gdjs.multiplayerCode.GDlevelObjects2.length = 0;
gdjs.multiplayerCode.GDlevelObjects3.length = 0;
gdjs.multiplayerCode.GDlevelObjects4.length = 0;
gdjs.multiplayerCode.GDbossObjects1.length = 0;
gdjs.multiplayerCode.GDbossObjects2.length = 0;
gdjs.multiplayerCode.GDbossObjects3.length = 0;
gdjs.multiplayerCode.GDbossObjects4.length = 0;
gdjs.multiplayerCode.GDbackObjects1.length = 0;
gdjs.multiplayerCode.GDbackObjects2.length = 0;
gdjs.multiplayerCode.GDbackObjects3.length = 0;
gdjs.multiplayerCode.GDbackObjects4.length = 0;
gdjs.multiplayerCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.multiplayerCode.GDShadedDarkJoystickObjects3.length = 0;
gdjs.multiplayerCode.GDShadedDarkJoystickObjects4.length = 0;
gdjs.multiplayerCode.GDshootObjects1.length = 0;
gdjs.multiplayerCode.GDshootObjects2.length = 0;
gdjs.multiplayerCode.GDshootObjects3.length = 0;
gdjs.multiplayerCode.GDshootObjects4.length = 0;
gdjs.multiplayerCode.GDNewBBTextObjects1.length = 0;
gdjs.multiplayerCode.GDNewBBTextObjects2.length = 0;
gdjs.multiplayerCode.GDNewBBTextObjects3.length = 0;
gdjs.multiplayerCode.GDNewBBTextObjects4.length = 0;
gdjs.multiplayerCode.GDidObjects1.length = 0;
gdjs.multiplayerCode.GDidObjects2.length = 0;
gdjs.multiplayerCode.GDidObjects3.length = 0;
gdjs.multiplayerCode.GDidObjects4.length = 0;
gdjs.multiplayerCode.GDidsObjects1.length = 0;
gdjs.multiplayerCode.GDidsObjects2.length = 0;
gdjs.multiplayerCode.GDidsObjects3.length = 0;
gdjs.multiplayerCode.GDidsObjects4.length = 0;

gdjs.multiplayerCode.eventsList15(runtimeScene);
gdjs.multiplayerCode.GDplayer1Objects1.length = 0;
gdjs.multiplayerCode.GDplayer1Objects2.length = 0;
gdjs.multiplayerCode.GDplayer1Objects3.length = 0;
gdjs.multiplayerCode.GDplayer1Objects4.length = 0;
gdjs.multiplayerCode.GDpillarObjects1.length = 0;
gdjs.multiplayerCode.GDpillarObjects2.length = 0;
gdjs.multiplayerCode.GDpillarObjects3.length = 0;
gdjs.multiplayerCode.GDpillarObjects4.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blueObjects1.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blueObjects2.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blueObjects3.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blueObjects4.length = 0;
gdjs.multiplayerCode.GDclonObjects1.length = 0;
gdjs.multiplayerCode.GDclonObjects2.length = 0;
gdjs.multiplayerCode.GDclonObjects3.length = 0;
gdjs.multiplayerCode.GDclonObjects4.length = 0;
gdjs.multiplayerCode.GDsmasherObjects1.length = 0;
gdjs.multiplayerCode.GDsmasherObjects2.length = 0;
gdjs.multiplayerCode.GDsmasherObjects3.length = 0;
gdjs.multiplayerCode.GDsmasherObjects4.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects1.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects2.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects3.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue2Objects4.length = 0;
gdjs.multiplayerCode.GDdoorObjects1.length = 0;
gdjs.multiplayerCode.GDdoorObjects2.length = 0;
gdjs.multiplayerCode.GDdoorObjects3.length = 0;
gdjs.multiplayerCode.GDdoorObjects4.length = 0;
gdjs.multiplayerCode.GDrifleObjects1.length = 0;
gdjs.multiplayerCode.GDrifleObjects2.length = 0;
gdjs.multiplayerCode.GDrifleObjects3.length = 0;
gdjs.multiplayerCode.GDrifleObjects4.length = 0;
gdjs.multiplayerCode.GDhit_9595boxObjects1.length = 0;
gdjs.multiplayerCode.GDhit_9595boxObjects2.length = 0;
gdjs.multiplayerCode.GDhit_9595boxObjects3.length = 0;
gdjs.multiplayerCode.GDhit_9595boxObjects4.length = 0;
gdjs.multiplayerCode.GDbulletObjects1.length = 0;
gdjs.multiplayerCode.GDbulletObjects2.length = 0;
gdjs.multiplayerCode.GDbulletObjects3.length = 0;
gdjs.multiplayerCode.GDbulletObjects4.length = 0;
gdjs.multiplayerCode.GDreloadObjects1.length = 0;
gdjs.multiplayerCode.GDreloadObjects2.length = 0;
gdjs.multiplayerCode.GDreloadObjects3.length = 0;
gdjs.multiplayerCode.GDreloadObjects4.length = 0;
gdjs.multiplayerCode.GDreload2Objects1.length = 0;
gdjs.multiplayerCode.GDreload2Objects2.length = 0;
gdjs.multiplayerCode.GDreload2Objects3.length = 0;
gdjs.multiplayerCode.GDreload2Objects4.length = 0;
gdjs.multiplayerCode.GDwaterObjects1.length = 0;
gdjs.multiplayerCode.GDwaterObjects2.length = 0;
gdjs.multiplayerCode.GDwaterObjects3.length = 0;
gdjs.multiplayerCode.GDwaterObjects4.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects1.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects2.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects3.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595sideObjects4.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects1.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects2.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects3.length = 0;
gdjs.multiplayerCode.GDcement_9595block_9595blue_9595side2Objects4.length = 0;
gdjs.multiplayerCode.GDwater_9595particleesObjects1.length = 0;
gdjs.multiplayerCode.GDwater_9595particleesObjects2.length = 0;
gdjs.multiplayerCode.GDwater_9595particleesObjects3.length = 0;
gdjs.multiplayerCode.GDwater_9595particleesObjects4.length = 0;
gdjs.multiplayerCode.GDwater_9595particlees2Objects1.length = 0;
gdjs.multiplayerCode.GDwater_9595particlees2Objects2.length = 0;
gdjs.multiplayerCode.GDwater_9595particlees2Objects3.length = 0;
gdjs.multiplayerCode.GDwater_9595particlees2Objects4.length = 0;
gdjs.multiplayerCode.GDlifeObjects1.length = 0;
gdjs.multiplayerCode.GDlifeObjects2.length = 0;
gdjs.multiplayerCode.GDlifeObjects3.length = 0;
gdjs.multiplayerCode.GDlifeObjects4.length = 0;
gdjs.multiplayerCode.GDbackgroundObjects1.length = 0;
gdjs.multiplayerCode.GDbackgroundObjects2.length = 0;
gdjs.multiplayerCode.GDbackgroundObjects3.length = 0;
gdjs.multiplayerCode.GDbackgroundObjects4.length = 0;
gdjs.multiplayerCode.GDwin_9595failObjects1.length = 0;
gdjs.multiplayerCode.GDwin_9595failObjects2.length = 0;
gdjs.multiplayerCode.GDwin_9595failObjects3.length = 0;
gdjs.multiplayerCode.GDwin_9595failObjects4.length = 0;
gdjs.multiplayerCode.GDstateObjects1.length = 0;
gdjs.multiplayerCode.GDstateObjects2.length = 0;
gdjs.multiplayerCode.GDstateObjects3.length = 0;
gdjs.multiplayerCode.GDstateObjects4.length = 0;
gdjs.multiplayerCode.GDlineObjects1.length = 0;
gdjs.multiplayerCode.GDlineObjects2.length = 0;
gdjs.multiplayerCode.GDlineObjects3.length = 0;
gdjs.multiplayerCode.GDlineObjects4.length = 0;
gdjs.multiplayerCode.GDsensorObjects1.length = 0;
gdjs.multiplayerCode.GDsensorObjects2.length = 0;
gdjs.multiplayerCode.GDsensorObjects3.length = 0;
gdjs.multiplayerCode.GDsensorObjects4.length = 0;
gdjs.multiplayerCode.GDblockerObjects1.length = 0;
gdjs.multiplayerCode.GDblockerObjects2.length = 0;
gdjs.multiplayerCode.GDblockerObjects3.length = 0;
gdjs.multiplayerCode.GDblockerObjects4.length = 0;
gdjs.multiplayerCode.GDsensor2Objects1.length = 0;
gdjs.multiplayerCode.GDsensor2Objects2.length = 0;
gdjs.multiplayerCode.GDsensor2Objects3.length = 0;
gdjs.multiplayerCode.GDsensor2Objects4.length = 0;
gdjs.multiplayerCode.GDsmasher_9595aObjects1.length = 0;
gdjs.multiplayerCode.GDsmasher_9595aObjects2.length = 0;
gdjs.multiplayerCode.GDsmasher_9595aObjects3.length = 0;
gdjs.multiplayerCode.GDsmasher_9595aObjects4.length = 0;
gdjs.multiplayerCode.GDblast_9595botObjects1.length = 0;
gdjs.multiplayerCode.GDblast_9595botObjects2.length = 0;
gdjs.multiplayerCode.GDblast_9595botObjects3.length = 0;
gdjs.multiplayerCode.GDblast_9595botObjects4.length = 0;
gdjs.multiplayerCode.GDwaveObjects1.length = 0;
gdjs.multiplayerCode.GDwaveObjects2.length = 0;
gdjs.multiplayerCode.GDwaveObjects3.length = 0;
gdjs.multiplayerCode.GDwaveObjects4.length = 0;
gdjs.multiplayerCode.GDdiverObjects1.length = 0;
gdjs.multiplayerCode.GDdiverObjects2.length = 0;
gdjs.multiplayerCode.GDdiverObjects3.length = 0;
gdjs.multiplayerCode.GDdiverObjects4.length = 0;
gdjs.multiplayerCode.GDlevelObjects1.length = 0;
gdjs.multiplayerCode.GDlevelObjects2.length = 0;
gdjs.multiplayerCode.GDlevelObjects3.length = 0;
gdjs.multiplayerCode.GDlevelObjects4.length = 0;
gdjs.multiplayerCode.GDbossObjects1.length = 0;
gdjs.multiplayerCode.GDbossObjects2.length = 0;
gdjs.multiplayerCode.GDbossObjects3.length = 0;
gdjs.multiplayerCode.GDbossObjects4.length = 0;
gdjs.multiplayerCode.GDbackObjects1.length = 0;
gdjs.multiplayerCode.GDbackObjects2.length = 0;
gdjs.multiplayerCode.GDbackObjects3.length = 0;
gdjs.multiplayerCode.GDbackObjects4.length = 0;
gdjs.multiplayerCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.multiplayerCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.multiplayerCode.GDShadedDarkJoystickObjects3.length = 0;
gdjs.multiplayerCode.GDShadedDarkJoystickObjects4.length = 0;
gdjs.multiplayerCode.GDshootObjects1.length = 0;
gdjs.multiplayerCode.GDshootObjects2.length = 0;
gdjs.multiplayerCode.GDshootObjects3.length = 0;
gdjs.multiplayerCode.GDshootObjects4.length = 0;
gdjs.multiplayerCode.GDNewBBTextObjects1.length = 0;
gdjs.multiplayerCode.GDNewBBTextObjects2.length = 0;
gdjs.multiplayerCode.GDNewBBTextObjects3.length = 0;
gdjs.multiplayerCode.GDNewBBTextObjects4.length = 0;
gdjs.multiplayerCode.GDidObjects1.length = 0;
gdjs.multiplayerCode.GDidObjects2.length = 0;
gdjs.multiplayerCode.GDidObjects3.length = 0;
gdjs.multiplayerCode.GDidObjects4.length = 0;
gdjs.multiplayerCode.GDidsObjects1.length = 0;
gdjs.multiplayerCode.GDidsObjects2.length = 0;
gdjs.multiplayerCode.GDidsObjects3.length = 0;
gdjs.multiplayerCode.GDidsObjects4.length = 0;


return;

}

gdjs['multiplayerCode'] = gdjs.multiplayerCode;
