gdjs.carCode = {};
gdjs.carCode.localVariables = [];
gdjs.carCode.GDmobObjects1= [];
gdjs.carCode.GDmobObjects2= [];
gdjs.carCode.GDmobObjects3= [];
gdjs.carCode.GDtickObjects1= [];
gdjs.carCode.GDtickObjects2= [];
gdjs.carCode.GDtickObjects3= [];
gdjs.carCode.GDpingObjects1= [];
gdjs.carCode.GDpingObjects2= [];
gdjs.carCode.GDpingObjects3= [];


gdjs.carCode.asyncCallback15676284 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.carCode.localVariables);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "loop_ping");
}gdjs.carCode.localVariables.length = 0;
}
gdjs.carCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.carCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.carCode.asyncCallback15676284(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.carCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15673852);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "loop_ping");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15674564);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("mob"), gdjs.carCode.GDmobObjects2);
{for(var i = 0, len = gdjs.carCode.GDmobObjects2.length ;i < len;++i) {
    gdjs.carCode.GDmobObjects2[i].activateBehavior("TopDownMovement", true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "loop_ping") <= 0.01;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15675668);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).getChild("ping").setNumber(gdjs.randomInRange(100, 1000));
}
{ //Subevents
gdjs.carCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.carCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "delay_ping") < 1.2;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ping"), gdjs.carCode.GDpingObjects2);
{for(var i = 0, len = gdjs.carCode.GDpingObjects2.length ;i < len;++i) {
    gdjs.carCode.GDpingObjects2[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "delay_ping") < 1.4;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "delay_ping") >= 1.2;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ping"), gdjs.carCode.GDpingObjects2);
{for(var i = 0, len = gdjs.carCode.GDpingObjects2.length ;i < len;++i) {
    gdjs.carCode.GDpingObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "delay_ping") < 1.6;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "delay_ping") >= 1.4;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ping"), gdjs.carCode.GDpingObjects2);
{for(var i = 0, len = gdjs.carCode.GDpingObjects2.length ;i < len;++i) {
    gdjs.carCode.GDpingObjects2[i].getBehavior("Animation").setAnimationIndex(2);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "delay_ping") < 1.8;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "delay_ping") >= 1.6;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ping"), gdjs.carCode.GDpingObjects2);
{for(var i = 0, len = gdjs.carCode.GDpingObjects2.length ;i < len;++i) {
    gdjs.carCode.GDpingObjects2[i].getBehavior("Animation").setAnimationIndex(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "delay_ping") < 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "delay_ping") >= 1.8;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ping"), gdjs.carCode.GDpingObjects1);
{for(var i = 0, len = gdjs.carCode.GDpingObjects1.length ;i < len;++i) {
    gdjs.carCode.GDpingObjects1[i].getBehavior("Animation").setAnimationIndex(4);
}
}}

}


};gdjs.carCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15633620);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("mob"), gdjs.carCode.GDmobObjects1);
{for(var i = 0, len = gdjs.carCode.GDmobObjects1.length ;i < len;++i) {
    gdjs.carCode.GDmobObjects1[i].activateBehavior("TopDownMovement", false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__THNK__StartServerCode.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {

{ //Subevents
gdjs.carCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("ping")) != runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber();
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "delay_ping");
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("ping").getAsNumber());
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("tick"), gdjs.carCode.GDtickObjects1);
{for(var i = 0, len = gdjs.carCode.GDtickObjects1.length ;i < len;++i) {
    gdjs.carCode.GDtickObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("ping").getAsString() + gdjs.evtTools.string.newLine() + "delay" + gdjs.evtTools.common.toString(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "delay_ping")));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "delay_ping") > 2;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ping"), gdjs.carCode.GDpingObjects1);
{for(var i = 0, len = gdjs.carCode.GDpingObjects1.length ;i < len;++i) {
    gdjs.carCode.GDpingObjects1[i].getBehavior("Animation").setAnimationIndex(4);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "delay_ping") > 2.5;
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.carCode.eventsList2(runtimeScene);} //End of subevents
}

}


};

gdjs.carCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.carCode.GDmobObjects1.length = 0;
gdjs.carCode.GDmobObjects2.length = 0;
gdjs.carCode.GDmobObjects3.length = 0;
gdjs.carCode.GDtickObjects1.length = 0;
gdjs.carCode.GDtickObjects2.length = 0;
gdjs.carCode.GDtickObjects3.length = 0;
gdjs.carCode.GDpingObjects1.length = 0;
gdjs.carCode.GDpingObjects2.length = 0;
gdjs.carCode.GDpingObjects3.length = 0;

gdjs.carCode.eventsList3(runtimeScene);
gdjs.carCode.GDmobObjects1.length = 0;
gdjs.carCode.GDmobObjects2.length = 0;
gdjs.carCode.GDmobObjects3.length = 0;
gdjs.carCode.GDtickObjects1.length = 0;
gdjs.carCode.GDtickObjects2.length = 0;
gdjs.carCode.GDtickObjects3.length = 0;
gdjs.carCode.GDpingObjects1.length = 0;
gdjs.carCode.GDpingObjects2.length = 0;
gdjs.carCode.GDpingObjects3.length = 0;


return;

}

gdjs['carCode'] = gdjs.carCode;
