gdjs.rogue2Code = {};
gdjs.rogue2Code.localVariables = [];
gdjs.rogue2Code.GDdiverObjects1_1final = [];

gdjs.rogue2Code.GDplayer1Objects1_1final = [];

gdjs.rogue2Code.GDshootObjects1_1final = [];

gdjs.rogue2Code.GDshootObjects2_2final = [];

gdjs.rogue2Code.GDwater_9595particlees2Objects1_1final = [];

gdjs.rogue2Code.GDwater_9595particleesObjects1_1final = [];

gdjs.rogue2Code.GDwaveObjects1_1final = [];

gdjs.rogue2Code.GDplayer1Objects1= [];
gdjs.rogue2Code.GDplayer1Objects2= [];
gdjs.rogue2Code.GDplayer1Objects3= [];
gdjs.rogue2Code.GDpillarObjects1= [];
gdjs.rogue2Code.GDpillarObjects2= [];
gdjs.rogue2Code.GDpillarObjects3= [];
gdjs.rogue2Code.GDcement_9595block_9595blueObjects1= [];
gdjs.rogue2Code.GDcement_9595block_9595blueObjects2= [];
gdjs.rogue2Code.GDcement_9595block_9595blueObjects3= [];
gdjs.rogue2Code.GDclonObjects1= [];
gdjs.rogue2Code.GDclonObjects2= [];
gdjs.rogue2Code.GDclonObjects3= [];
gdjs.rogue2Code.GDsmasherObjects1= [];
gdjs.rogue2Code.GDsmasherObjects2= [];
gdjs.rogue2Code.GDsmasherObjects3= [];
gdjs.rogue2Code.GDcement_9595block_9595blue2Objects1= [];
gdjs.rogue2Code.GDcement_9595block_9595blue2Objects2= [];
gdjs.rogue2Code.GDcement_9595block_9595blue2Objects3= [];
gdjs.rogue2Code.GDdoorObjects1= [];
gdjs.rogue2Code.GDdoorObjects2= [];
gdjs.rogue2Code.GDdoorObjects3= [];
gdjs.rogue2Code.GDrifleObjects1= [];
gdjs.rogue2Code.GDrifleObjects2= [];
gdjs.rogue2Code.GDrifleObjects3= [];
gdjs.rogue2Code.GDhit_9595boxObjects1= [];
gdjs.rogue2Code.GDhit_9595boxObjects2= [];
gdjs.rogue2Code.GDhit_9595boxObjects3= [];
gdjs.rogue2Code.GDbulletObjects1= [];
gdjs.rogue2Code.GDbulletObjects2= [];
gdjs.rogue2Code.GDbulletObjects3= [];
gdjs.rogue2Code.GDreloadObjects1= [];
gdjs.rogue2Code.GDreloadObjects2= [];
gdjs.rogue2Code.GDreloadObjects3= [];
gdjs.rogue2Code.GDreload2Objects1= [];
gdjs.rogue2Code.GDreload2Objects2= [];
gdjs.rogue2Code.GDreload2Objects3= [];
gdjs.rogue2Code.GDwaterObjects1= [];
gdjs.rogue2Code.GDwaterObjects2= [];
gdjs.rogue2Code.GDwaterObjects3= [];
gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1= [];
gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects2= [];
gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects3= [];
gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects1= [];
gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects2= [];
gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects3= [];
gdjs.rogue2Code.GDwater_9595particleesObjects1= [];
gdjs.rogue2Code.GDwater_9595particleesObjects2= [];
gdjs.rogue2Code.GDwater_9595particleesObjects3= [];
gdjs.rogue2Code.GDwater_9595particlees2Objects1= [];
gdjs.rogue2Code.GDwater_9595particlees2Objects2= [];
gdjs.rogue2Code.GDwater_9595particlees2Objects3= [];
gdjs.rogue2Code.GDlifeObjects1= [];
gdjs.rogue2Code.GDlifeObjects2= [];
gdjs.rogue2Code.GDlifeObjects3= [];
gdjs.rogue2Code.GDbackgroundObjects1= [];
gdjs.rogue2Code.GDbackgroundObjects2= [];
gdjs.rogue2Code.GDbackgroundObjects3= [];
gdjs.rogue2Code.GDwin_9595failObjects1= [];
gdjs.rogue2Code.GDwin_9595failObjects2= [];
gdjs.rogue2Code.GDwin_9595failObjects3= [];
gdjs.rogue2Code.GDstateObjects1= [];
gdjs.rogue2Code.GDstateObjects2= [];
gdjs.rogue2Code.GDstateObjects3= [];
gdjs.rogue2Code.GDlineObjects1= [];
gdjs.rogue2Code.GDlineObjects2= [];
gdjs.rogue2Code.GDlineObjects3= [];
gdjs.rogue2Code.GDsensorObjects1= [];
gdjs.rogue2Code.GDsensorObjects2= [];
gdjs.rogue2Code.GDsensorObjects3= [];
gdjs.rogue2Code.GDblockerObjects1= [];
gdjs.rogue2Code.GDblockerObjects2= [];
gdjs.rogue2Code.GDblockerObjects3= [];
gdjs.rogue2Code.GDsensor2Objects1= [];
gdjs.rogue2Code.GDsensor2Objects2= [];
gdjs.rogue2Code.GDsensor2Objects3= [];
gdjs.rogue2Code.GDsmasher_9595aObjects1= [];
gdjs.rogue2Code.GDsmasher_9595aObjects2= [];
gdjs.rogue2Code.GDsmasher_9595aObjects3= [];
gdjs.rogue2Code.GDblast_9595botObjects1= [];
gdjs.rogue2Code.GDblast_9595botObjects2= [];
gdjs.rogue2Code.GDblast_9595botObjects3= [];
gdjs.rogue2Code.GDwaveObjects1= [];
gdjs.rogue2Code.GDwaveObjects2= [];
gdjs.rogue2Code.GDwaveObjects3= [];
gdjs.rogue2Code.GDdiverObjects1= [];
gdjs.rogue2Code.GDdiverObjects2= [];
gdjs.rogue2Code.GDdiverObjects3= [];
gdjs.rogue2Code.GDlevelObjects1= [];
gdjs.rogue2Code.GDlevelObjects2= [];
gdjs.rogue2Code.GDlevelObjects3= [];
gdjs.rogue2Code.GDbossObjects1= [];
gdjs.rogue2Code.GDbossObjects2= [];
gdjs.rogue2Code.GDbossObjects3= [];
gdjs.rogue2Code.GDbackObjects1= [];
gdjs.rogue2Code.GDbackObjects2= [];
gdjs.rogue2Code.GDbackObjects3= [];
gdjs.rogue2Code.GDShadedDarkJoystickObjects1= [];
gdjs.rogue2Code.GDShadedDarkJoystickObjects2= [];
gdjs.rogue2Code.GDShadedDarkJoystickObjects3= [];
gdjs.rogue2Code.GDshootObjects1= [];
gdjs.rogue2Code.GDshootObjects2= [];
gdjs.rogue2Code.GDshootObjects3= [];


gdjs.rogue2Code.mapOfEmptyGDplayer1Objects = Hashtable.newFrom({"player1": []});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsmasherObjects1Objects = Hashtable.newFrom({"smasher": gdjs.rogue2Code.GDsmasherObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.rogue2Code.GDbulletObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDclonObjects1Objects = Hashtable.newFrom({"clon": gdjs.rogue2Code.GDclonObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.rogue2Code.GDbulletObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.rogue2Code.GDplayer1Objects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDhit_95959595boxObjects1Objects = Hashtable.newFrom({"hit_box": gdjs.rogue2Code.GDhit_9595boxObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDhit_95959595boxObjects1Objects = Hashtable.newFrom({"hit_box": gdjs.rogue2Code.GDhit_9595boxObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDblockerObjects1Objects = Hashtable.newFrom({"blocker": gdjs.rogue2Code.GDblockerObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsmasherObjects1ObjectsGDgdjs_9546rogue2Code_9546GDclonObjects1ObjectsGDgdjs_9546rogue2Code_9546GDblast_95959595botObjects1ObjectsGDgdjs_9546rogue2Code_9546GDdiverObjects1ObjectsGDgdjs_9546rogue2Code_9546GDbossObjects1Objects = Hashtable.newFrom({"smasher": gdjs.rogue2Code.GDsmasherObjects1, "clon": gdjs.rogue2Code.GDclonObjects1, "blast_bot": gdjs.rogue2Code.GDblast_9595botObjects1, "diver": gdjs.rogue2Code.GDdiverObjects1, "boss": gdjs.rogue2Code.GDbossObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.rogue2Code.GDsensorObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.rogue2Code.GDsensorObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.rogue2Code.GDsensorObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.rogue2Code.GDsensorObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.rogue2Code.GDsensorObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsensorObjects1Objects = Hashtable.newFrom({"sensor": gdjs.rogue2Code.GDsensorObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects = Hashtable.newFrom({"cement_block_blue_side": gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects = Hashtable.newFrom({"cement_block_blue_side": gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects = Hashtable.newFrom({"cement_block_blue_side": gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects = Hashtable.newFrom({"cement_block_blue_side": gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects = Hashtable.newFrom({"cement_block_blue_side": gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwater_95959595particlees2Objects1Objects = Hashtable.newFrom({"water_particlees2": gdjs.rogue2Code.GDwater_9595particlees2Objects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwater_95959595particlees2Objects1Objects = Hashtable.newFrom({"water_particlees2": gdjs.rogue2Code.GDwater_9595particlees2Objects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwater_95959595particlees2Objects1Objects = Hashtable.newFrom({"water_particlees2": gdjs.rogue2Code.GDwater_9595particlees2Objects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwater_95959595particlees2Objects1Objects = Hashtable.newFrom({"water_particlees2": gdjs.rogue2Code.GDwater_9595particlees2Objects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwater_95959595particlees2Objects1Objects = Hashtable.newFrom({"water_particlees2": gdjs.rogue2Code.GDwater_9595particlees2Objects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.rogue2Code.GDbulletObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.rogue2Code.GDbulletObjects1});
gdjs.rogue2Code.mapOfEmptyGDrifleObjects = Hashtable.newFrom({"rifle": []});
gdjs.rogue2Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level")) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level")) < 11;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue"), gdjs.rogue2Code.GDcement_9595block_9595blueObjects2);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue2"), gdjs.rogue2Code.GDcement_9595block_9595blue2Objects2);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue_side"), gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects2);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue_side2"), gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects2);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogue2Code.GDclonObjects2);
gdjs.copyArray(runtimeScene.getObjects("door"), gdjs.rogue2Code.GDdoorObjects2);
gdjs.copyArray(gdjs.rogue2Code.GDhit_9595boxObjects1, gdjs.rogue2Code.GDhit_9595boxObjects2);

gdjs.copyArray(runtimeScene.getObjects("pillar"), gdjs.rogue2Code.GDpillarObjects2);
gdjs.copyArray(gdjs.rogue2Code.GDplayer1Objects1, gdjs.rogue2Code.GDplayer1Objects2);

gdjs.copyArray(gdjs.rogue2Code.GDrifleObjects1, gdjs.rogue2Code.GDrifleObjects2);

gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogue2Code.GDsmasherObjects2);
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.rogue2Code.GDwaterObjects2);
gdjs.copyArray(runtimeScene.getObjects("water_particlees"), gdjs.rogue2Code.GDwater_9595particleesObjects2);
gdjs.copyArray(runtimeScene.getObjects("water_particlees2"), gdjs.rogue2Code.GDwater_9595particlees2Objects2);
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDpillarObjects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDpillarObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDcement_9595block_9595blueObjects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDcement_9595block_9595blueObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDclonObjects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDclonObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDcement_9595block_9595blue2Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDcement_9595block_9595blue2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDsmasherObjects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDsmasherObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDdoorObjects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDdoorObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDrifleObjects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDrifleObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDhit_9595boxObjects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDhit_9595boxObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDwaterObjects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDwaterObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDwater_9595particleesObjects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDwater_9595particleesObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDwater_9595particlees2Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDwater_9595particlees2Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").getAsString(), 0, 0, 10);
}{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects2[i].setZOrder(200);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDrifleObjects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDrifleObjects2[i].setZOrder(201);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level")) > 10;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.rogue2Code.GDplayer1Objects1, gdjs.rogue2Code.GDplayer1Objects2);

gdjs.copyArray(gdjs.rogue2Code.GDrifleObjects1, gdjs.rogue2Code.GDrifleObjects2);

{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects2[i].setZOrder(200);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDrifleObjects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDrifleObjects2[i].setZOrder(201);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").setNumber(0);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.rogue2Code.GDplayer1Objects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwaterObjects1Objects = Hashtable.newFrom({"water": gdjs.rogue2Code.GDwaterObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.rogue2Code.GDplayer1Objects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDcement_95959595block_95959595blueObjects1Objects = Hashtable.newFrom({"cement_block_blue": gdjs.rogue2Code.GDcement_9595block_9595blueObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.rogue2Code.GDplayer1Objects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsmasherObjects1ObjectsGDgdjs_9546rogue2Code_9546GDclonObjects1ObjectsGDgdjs_9546rogue2Code_9546GDblast_95959595botObjects1ObjectsGDgdjs_9546rogue2Code_9546GDdiverObjects1ObjectsGDgdjs_9546rogue2Code_9546GDbossObjects1Objects = Hashtable.newFrom({"smasher": gdjs.rogue2Code.GDsmasherObjects1, "clon": gdjs.rogue2Code.GDclonObjects1, "blast_bot": gdjs.rogue2Code.GDblast_9595botObjects1, "diver": gdjs.rogue2Code.GDdiverObjects1, "boss": gdjs.rogue2Code.GDbossObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects1Objects = Hashtable.newFrom({"player1": gdjs.rogue2Code.GDplayer1Objects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDblockerObjects1Objects = Hashtable.newFrom({"blocker": gdjs.rogue2Code.GDblockerObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsensor2Objects1Objects = Hashtable.newFrom({"sensor2": gdjs.rogue2Code.GDsensor2Objects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDblockerObjects1Objects = Hashtable.newFrom({"blocker": gdjs.rogue2Code.GDblockerObjects1});
gdjs.rogue2Code.mapOfEmptyGDplayer1Objects = Hashtable.newFrom({"player1": []});
gdjs.rogue2Code.mapOfEmptyGDsmasherObjectsEmptyGDclonObjectsEmptyGDblast_9595botObjectsEmptyGDdiverObjectsEmptyGDbossObjects = Hashtable.newFrom({"smasher": [], "clon": [], "blast_bot": [], "diver": [], "boss": []});
gdjs.rogue2Code.mapOfEmptyGDsmasherObjectsEmptyGDclonObjectsEmptyGDblast_9595botObjectsEmptyGDdiverObjectsEmptyGDbossObjects = Hashtable.newFrom({"smasher": [], "clon": [], "blast_bot": [], "diver": [], "boss": []});
gdjs.rogue2Code.mapOfEmptyGDbossObjects = Hashtable.newFrom({"boss": []});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDclonObjects1Objects = Hashtable.newFrom({"clon": gdjs.rogue2Code.GDclonObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDclonObjects1Objects = Hashtable.newFrom({"clon": gdjs.rogue2Code.GDclonObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDclonObjects1Objects = Hashtable.newFrom({"clon": gdjs.rogue2Code.GDclonObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsmasherObjects1Objects = Hashtable.newFrom({"smasher": gdjs.rogue2Code.GDsmasherObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDdiverObjects1Objects = Hashtable.newFrom({"diver": gdjs.rogue2Code.GDdiverObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwaveObjects2Objects = Hashtable.newFrom({"wave": gdjs.rogue2Code.GDwaveObjects2});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwater_95959595particlees2Objects2Objects = Hashtable.newFrom({"water_particlees2": gdjs.rogue2Code.GDwater_9595particlees2Objects2});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwaveObjects2Objects = Hashtable.newFrom({"wave": gdjs.rogue2Code.GDwaveObjects2});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwater_95959595particleesObjects2Objects = Hashtable.newFrom({"water_particlees": gdjs.rogue2Code.GDwater_9595particleesObjects2});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwaveObjects2Objects = Hashtable.newFrom({"wave": gdjs.rogue2Code.GDwaveObjects2});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects2Objects = Hashtable.newFrom({"player1": gdjs.rogue2Code.GDplayer1Objects2});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwaveObjects1Objects = Hashtable.newFrom({"wave": gdjs.rogue2Code.GDwaveObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.rogue2Code.GDbulletObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDblast_95959595botObjects1Objects = Hashtable.newFrom({"blast_bot": gdjs.rogue2Code.GDblast_9595botObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.rogue2Code.GDbulletObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDdiverObjects1Objects = Hashtable.newFrom({"diver": gdjs.rogue2Code.GDdiverObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbulletObjects1Objects = Hashtable.newFrom({"bullet": gdjs.rogue2Code.GDbulletObjects1});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbossObjects1Objects = Hashtable.newFrom({"boss": gdjs.rogue2Code.GDbossObjects1});
gdjs.rogue2Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogue2Code.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("Up", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDShadedDarkJoystickObjects2[k] = gdjs.rogue2Code.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects2);
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogue2Code.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("Down", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDShadedDarkJoystickObjects2[k] = gdjs.rogue2Code.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects2);
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogue2Code.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDShadedDarkJoystickObjects2[k] = gdjs.rogue2Code.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects2);
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogue2Code.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDShadedDarkJoystickObjects2[k] = gdjs.rogue2Code.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects2);
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogue2Code.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("UpLeft", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDShadedDarkJoystickObjects2[k] = gdjs.rogue2Code.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects2);
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogue2Code.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("UpRight", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDShadedDarkJoystickObjects2[k] = gdjs.rogue2Code.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects2);
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogue2Code.GDShadedDarkJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDShadedDarkJoystickObjects2[i].IsDirectionPushed8Way("DownLeft", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDShadedDarkJoystickObjects2[k] = gdjs.rogue2Code.GDShadedDarkJoystickObjects2[i];
        ++k;
    }
}
gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects2);
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects2.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects2[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.rogue2Code.GDShadedDarkJoystickObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDShadedDarkJoystickObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDShadedDarkJoystickObjects1[i].IsDirectionPushed8Way("DownRight", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDShadedDarkJoystickObjects1[k] = gdjs.rogue2Code.GDShadedDarkJoystickObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDShadedDarkJoystickObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


};gdjs.rogue2Code.mapOfEmptyGDplayer1Objects = Hashtable.newFrom({"player1": []});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwaveObjects2Objects = Hashtable.newFrom({"wave": gdjs.rogue2Code.GDwaveObjects2});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects2Objects = Hashtable.newFrom({"player1": gdjs.rogue2Code.GDplayer1Objects2});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDdiverObjects2Objects = Hashtable.newFrom({"diver": gdjs.rogue2Code.GDdiverObjects2});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects2Objects = Hashtable.newFrom({"player1": gdjs.rogue2Code.GDplayer1Objects2});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDstateObjects2Objects = Hashtable.newFrom({"state": gdjs.rogue2Code.GDstateObjects2});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbackObjects2Objects = Hashtable.newFrom({"back": gdjs.rogue2Code.GDbackObjects2});
gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDstateObjects2Objects = Hashtable.newFrom({"state": gdjs.rogue2Code.GDstateObjects2});
gdjs.rogue2Code.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.rogue2Code.GDstateObjects2);
gdjs.copyArray(runtimeScene.getObjects("win_fail"), gdjs.rogue2Code.GDwin_9595failObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDwin_9595failObjects2.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDwin_9595failObjects2[i].getBehavior("Text").getText() == "you win" ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDwin_9595failObjects2[k] = gdjs.rogue2Code.GDwin_9595failObjects2[i];
        ++k;
    }
}
gdjs.rogue2Code.GDwin_9595failObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDstateObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").add(1);
}{gdjs.evtTools.storage.writeNumberInJSONFile("sc", "sc", runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").getAsNumber());
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "rogue", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.rogue2Code.GDbackObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbackObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeNumberInJSONFile("sc", "sc", runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").getAsNumber());
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level select", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.rogue2Code.GDstateObjects2);
gdjs.copyArray(runtimeScene.getObjects("win_fail"), gdjs.rogue2Code.GDwin_9595failObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDwin_9595failObjects2.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDwin_9595failObjects2[i].getBehavior("Text").getText() == "you fail" ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDwin_9595failObjects2[k] = gdjs.rogue2Code.GDwin_9595failObjects2[i];
        ++k;
    }
}
gdjs.rogue2Code.GDwin_9595failObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDstateObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "rogue", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("win_fail"), gdjs.rogue2Code.GDwin_9595failObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDwin_9595failObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDwin_9595failObjects1[i].getBehavior("Text").getText() == "you fail" ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDwin_9595failObjects1[k] = gdjs.rogue2Code.GDwin_9595failObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDwin_9595failObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.rogue2Code.GDstateObjects1);
{for(var i = 0, len = gdjs.rogue2Code.GDstateObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDstateObjects1[i].getBehavior("Text").setText("restart");
}
}}

}


};gdjs.rogue2Code.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("touch"), false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogue2Code.GDrifleObjects1);
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.rogue2Code.GDshootObjects1);
{for(var i = 0, len = gdjs.rogue2Code.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDrifleObjects1[i].rotateTowardAngle((( gdjs.rogue2Code.GDshootObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDshootObjects1[0].StickAngle((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), 0, runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("touch"), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogue2Code.GDrifleObjects1);
{for(var i = 0, len = gdjs.rogue2Code.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDrifleObjects1[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogue2Code.mapOfEmptyGDplayer1Objects) > 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("life"), gdjs.rogue2Code.GDlifeObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("reload2"), gdjs.rogue2Code.GDreload2Objects1);
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.rogue2Code.GDwaterObjects1);
gdjs.copyArray(runtimeScene.getObjects("water_particlees"), gdjs.rogue2Code.GDwater_9595particleesObjects1);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "centre on player", (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getCenterXInScene()), (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getCenterYInScene()), "", "linear", 0.1);
}{for(var i = 0, len = gdjs.rogue2Code.GDreload2Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDreload2Objects1[i].getBehavior("Resizable").setWidth(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) * 128);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDwaterObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDwaterObjects1[i].setXOffset(gdjs.rogue2Code.GDwaterObjects1[i].getXOffset() + (0.4));
}
}{for(var i = 0, len = gdjs.rogue2Code.GDwater_9595particleesObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDwater_9595particleesObjects1[i].setXOffset(gdjs.rogue2Code.GDwater_9595particleesObjects1[i].getXOffset() + (0.4));
}
}{for(var i = 0, len = gdjs.rogue2Code.GDlifeObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDlifeObjects1[i].getBehavior("Resizable").setWidth(((gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.rogue2Code.GDplayer1Objects1[0].getVariables()).getFromIndex(0).getAsNumber() / 10 * (32));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.rogue2Code.GDbulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogue2Code.GDsmasherObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsmasherObjects1Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbulletObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDbulletObjects1 */
/* Reuse gdjs.rogue2Code.GDsmasherObjects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDsmasherObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDbulletObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.rogue2Code.GDbulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogue2Code.GDclonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDclonObjects1Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbulletObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDbulletObjects1 */
/* Reuse gdjs.rogue2Code.GDclonObjects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDclonObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDbulletObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogue2Code.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogue2Code.GDsmasherObjects1);
{for(var i = 0, len = gdjs.rogue2Code.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDclonObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getPointX("")), (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.rogue2Code.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDsmasherObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getPointX("")), (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getPointY("")));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) > 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("reload"), gdjs.rogue2Code.GDreloadObjects1);
{for(var i = 0, len = gdjs.rogue2Code.GDreloadObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDreloadObjects1[i].getBehavior("Text").setText("ready");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) < 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("reload"), gdjs.rogue2Code.GDreloadObjects1);
{for(var i = 0, len = gdjs.rogue2Code.GDreloadObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDreloadObjects1[i].getBehavior("Text").setText("reloading...");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hit_box"), gdjs.rogue2Code.GDhit_9595boxObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects1Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDhit_95959595boxObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDhit_9595boxObjects1 */
/* Reuse gdjs.rogue2Code.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDhit_95959595boxObjects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blocker"), gdjs.rogue2Code.GDblockerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDblockerObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDblockerObjects1[i].getVariableBoolean(gdjs.rogue2Code.GDblockerObjects1[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDblockerObjects1[k] = gdjs.rogue2Code.GDblockerObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDblockerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDblockerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDblockerObjects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogue2Code.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.rogue2Code.GDbossObjects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogue2Code.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogue2Code.GDdiverObjects1);
gdjs.copyArray(runtimeScene.getObjects("sensor"), gdjs.rogue2Code.GDsensorObjects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogue2Code.GDsmasherObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsmasherObjects1ObjectsGDgdjs_9546rogue2Code_9546GDclonObjects1ObjectsGDgdjs_9546rogue2Code_9546GDblast_95959595botObjects1ObjectsGDgdjs_9546rogue2Code_9546GDdiverObjects1ObjectsGDgdjs_9546rogue2Code_9546GDbossObjects1Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsensorObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDblast_9595botObjects1 */
/* Reuse gdjs.rogue2Code.GDbossObjects1 */
/* Reuse gdjs.rogue2Code.GDclonObjects1 */
/* Reuse gdjs.rogue2Code.GDdiverObjects1 */
/* Reuse gdjs.rogue2Code.GDsensorObjects1 */
/* Reuse gdjs.rogue2Code.GDsmasherObjects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDsmasherObjects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsensorObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogue2Code.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDclonObjects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsensorObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogue2Code.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDblast_9595botObjects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsensorObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogue2Code.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDdiverObjects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsensorObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogue2Code.GDbossObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDbossObjects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsensorObjects1Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogue2Code.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.rogue2Code.GDbossObjects1);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue_side"), gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogue2Code.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogue2Code.GDdiverObjects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogue2Code.GDsmasherObjects1);
gdjs.copyArray(runtimeScene.getObjects("water_particlees2"), gdjs.rogue2Code.GDwater_9595particlees2Objects1);
{for(var i = 0, len = gdjs.rogue2Code.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDsmasherObjects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogue2Code.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDclonObjects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogue2Code.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDblast_9595botObjects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogue2Code.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDdiverObjects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects, false);
}
for(var i = 0, len = gdjs.rogue2Code.GDbossObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDbossObjects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDcement_95959595block_95959595blue_95959595sideObjects1Objects, false);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDsmasherObjects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwater_95959595particlees2Objects1Objects, false);
}
for(var i = 0, len = gdjs.rogue2Code.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDclonObjects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwater_95959595particlees2Objects1Objects, false);
}
for(var i = 0, len = gdjs.rogue2Code.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDblast_9595botObjects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwater_95959595particlees2Objects1Objects, false);
}
for(var i = 0, len = gdjs.rogue2Code.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDdiverObjects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwater_95959595particlees2Objects1Objects, false);
}
for(var i = 0, len = gdjs.rogue2Code.GDbossObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDbossObjects1[i].separateFromObjectsList(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwater_95959595particlees2Objects1Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("level"), gdjs.rogue2Code.GDlevelObjects1);
{for(var i = 0, len = gdjs.rogue2Code.GDlevelObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDlevelObjects1[i].getBehavior("Text").setText("level: " + runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").getAsString());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) < (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getPointX(""));
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDplayer1Objects1 */
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogue2Code.GDrifleObjects1);
{for(var i = 0, len = gdjs.rogue2Code.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDrifleObjects1[i].getBehavior("Flippable").flipY(true);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects1[i].getBehavior("Flippable").flipX(true);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDrifleObjects1[i].setPosition((( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getPointX("hand2")) - 8,(( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getPointY("hand2")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) > (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getPointX(""));
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDplayer1Objects1 */
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogue2Code.GDrifleObjects1);
{for(var i = 0, len = gdjs.rogue2Code.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDrifleObjects1[i].getBehavior("Flippable").flipY(false);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects1[i].getBehavior("Flippable").flipX(false);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDrifleObjects1[i].setPosition((( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getPointX("hand")),(( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getPointY("hand")));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) > 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "fail"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("touch"), true);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogue2Code.GDrifleObjects1);
gdjs.rogue2Code.GDbulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbulletObjects1Objects, (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getAABBCenterX()), (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getAABBCenterY()), "");
}{for(var i = 0, len = gdjs.rogue2Code.GDbulletObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDbulletObjects1[i].addPolarForce((( gdjs.rogue2Code.GDrifleObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDrifleObjects1[0].getAngle()), 1000, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 40, gdjs.randomInRange(0.8, 1.2));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.55, 0.33, 0.50, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.rogue2Code.GDshootObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.rogue2Code.GDshootObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.rogue2Code.GDshootObjects2.length = 0;

{gdjs.rogue2Code.GDshootObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.rogue2Code.GDshootObjects3);
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDshootObjects3.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDshootObjects3[i].StickForceX((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) > 0.3 ) {
        isConditionTrue_2 = true;
        gdjs.rogue2Code.GDshootObjects3[k] = gdjs.rogue2Code.GDshootObjects3[i];
        ++k;
    }
}
gdjs.rogue2Code.GDshootObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.rogue2Code.GDshootObjects3.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDshootObjects2_2final.indexOf(gdjs.rogue2Code.GDshootObjects3[j]) === -1 )
            gdjs.rogue2Code.GDshootObjects2_2final.push(gdjs.rogue2Code.GDshootObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.rogue2Code.GDshootObjects3);
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDshootObjects3.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDshootObjects3[i].StickForceY((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) > 0.3 ) {
        isConditionTrue_2 = true;
        gdjs.rogue2Code.GDshootObjects3[k] = gdjs.rogue2Code.GDshootObjects3[i];
        ++k;
    }
}
gdjs.rogue2Code.GDshootObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.rogue2Code.GDshootObjects3.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDshootObjects2_2final.indexOf(gdjs.rogue2Code.GDshootObjects3[j]) === -1 )
            gdjs.rogue2Code.GDshootObjects2_2final.push(gdjs.rogue2Code.GDshootObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.rogue2Code.GDshootObjects2_2final, gdjs.rogue2Code.GDshootObjects2);
}
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogue2Code.GDshootObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDshootObjects1_1final.indexOf(gdjs.rogue2Code.GDshootObjects2[j]) === -1 )
            gdjs.rogue2Code.GDshootObjects1_1final.push(gdjs.rogue2Code.GDshootObjects2[j]);
    }
}
}
{
gdjs.rogue2Code.GDshootObjects2.length = 0;

{gdjs.rogue2Code.GDshootObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.rogue2Code.GDshootObjects3);
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDshootObjects3.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDshootObjects3[i].StickForceX((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) < -(0.3) ) {
        isConditionTrue_2 = true;
        gdjs.rogue2Code.GDshootObjects3[k] = gdjs.rogue2Code.GDshootObjects3[i];
        ++k;
    }
}
gdjs.rogue2Code.GDshootObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.rogue2Code.GDshootObjects3.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDshootObjects2_2final.indexOf(gdjs.rogue2Code.GDshootObjects3[j]) === -1 )
            gdjs.rogue2Code.GDshootObjects2_2final.push(gdjs.rogue2Code.GDshootObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("shoot"), gdjs.rogue2Code.GDshootObjects3);
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDshootObjects3.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDshootObjects3[i].StickForceY((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) < -(0.3) ) {
        isConditionTrue_2 = true;
        gdjs.rogue2Code.GDshootObjects3[k] = gdjs.rogue2Code.GDshootObjects3[i];
        ++k;
    }
}
gdjs.rogue2Code.GDshootObjects3.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.rogue2Code.GDshootObjects3.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDshootObjects2_2final.indexOf(gdjs.rogue2Code.GDshootObjects3[j]) === -1 )
            gdjs.rogue2Code.GDshootObjects2_2final.push(gdjs.rogue2Code.GDshootObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.rogue2Code.GDshootObjects2_2final, gdjs.rogue2Code.GDshootObjects2);
}
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogue2Code.GDshootObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDshootObjects1_1final.indexOf(gdjs.rogue2Code.GDshootObjects2[j]) === -1 )
            gdjs.rogue2Code.GDshootObjects1_1final.push(gdjs.rogue2Code.GDshootObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.rogue2Code.GDshootObjects1_1final, gdjs.rogue2Code.GDshootObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) > 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "fail"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("touch"), false);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogue2Code.GDrifleObjects1);
gdjs.rogue2Code.GDbulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbulletObjects1Objects, (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getAABBCenterX()), (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getAABBCenterY()), "");
}{for(var i = 0, len = gdjs.rogue2Code.GDbulletObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDbulletObjects1[i].addPolarForce((( gdjs.rogue2Code.GDrifleObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDrifleObjects1[0].getAngle()), 1000, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 40, gdjs.randomInRange(0.8, 1.2));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.55, 0.33, 0.50, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) < 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogue2Code.mapOfEmptyGDrifleObjects) > 0;
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(0.05);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("cement_block_blue"), gdjs.rogue2Code.GDcement_9595block_9595blueObjects1);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue2"), gdjs.rogue2Code.GDcement_9595block_9595blue2Objects1);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue_side"), gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1);
gdjs.copyArray(runtimeScene.getObjects("cement_block_blue_side2"), gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogue2Code.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("door"), gdjs.rogue2Code.GDdoorObjects1);
gdjs.copyArray(runtimeScene.getObjects("hit_box"), gdjs.rogue2Code.GDhit_9595boxObjects1);
gdjs.copyArray(runtimeScene.getObjects("pillar"), gdjs.rogue2Code.GDpillarObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogue2Code.GDrifleObjects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogue2Code.GDsmasherObjects1);
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.rogue2Code.GDwaterObjects1);
gdjs.copyArray(runtimeScene.getObjects("water_particlees"), gdjs.rogue2Code.GDwater_9595particleesObjects1);
gdjs.copyArray(runtimeScene.getObjects("water_particlees2"), gdjs.rogue2Code.GDwater_9595particlees2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDplayer1Objects1[i].getZOrder() > (gdjs.rogue2Code.GDplayer1Objects1[i].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDplayer1Objects1[k] = gdjs.rogue2Code.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDplayer1Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDpillarObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDpillarObjects1[i].getZOrder() > (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDpillarObjects1[k] = gdjs.rogue2Code.GDpillarObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDpillarObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDcement_9595block_9595blueObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDcement_9595block_9595blueObjects1[i].getZOrder() > (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDcement_9595block_9595blueObjects1[k] = gdjs.rogue2Code.GDcement_9595block_9595blueObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDcement_9595block_9595blueObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDclonObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDclonObjects1[i].getZOrder() > (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDclonObjects1[k] = gdjs.rogue2Code.GDclonObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDclonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDcement_9595block_9595blue2Objects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDcement_9595block_9595blue2Objects1[i].getZOrder() > (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDcement_9595block_9595blue2Objects1[k] = gdjs.rogue2Code.GDcement_9595block_9595blue2Objects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDcement_9595block_9595blue2Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDsmasherObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDsmasherObjects1[i].getZOrder() > (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDsmasherObjects1[k] = gdjs.rogue2Code.GDsmasherObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDsmasherObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDdoorObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDdoorObjects1[i].getZOrder() > (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDdoorObjects1[k] = gdjs.rogue2Code.GDdoorObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDdoorObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDrifleObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDrifleObjects1[i].getZOrder() > (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDrifleObjects1[k] = gdjs.rogue2Code.GDrifleObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDrifleObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDhit_9595boxObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDhit_9595boxObjects1[i].getZOrder() > (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDhit_9595boxObjects1[k] = gdjs.rogue2Code.GDhit_9595boxObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDhit_9595boxObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDwaterObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDwaterObjects1[i].getZOrder() > (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDwaterObjects1[k] = gdjs.rogue2Code.GDwaterObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDwaterObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1[i].getZOrder() > (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1[k] = gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects1[i].getZOrder() > (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects1[k] = gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDwater_9595particleesObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDwater_9595particleesObjects1[i].getZOrder() > (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDwater_9595particleesObjects1[k] = gdjs.rogue2Code.GDwater_9595particleesObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDwater_9595particleesObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDwater_9595particlees2Objects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDwater_9595particlees2Objects1[i].getZOrder() > (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getZOrder()) ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDwater_9595particlees2Objects1[k] = gdjs.rogue2Code.GDwater_9595particlees2Objects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDwater_9595particlees2Objects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogue2Code.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.rogue2Code.GDbossObjects1);
/* Reuse gdjs.rogue2Code.GDcement_9595block_9595blueObjects1 */
/* Reuse gdjs.rogue2Code.GDcement_9595block_9595blue2Objects1 */
/* Reuse gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1 */
/* Reuse gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects1 */
/* Reuse gdjs.rogue2Code.GDclonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogue2Code.GDdiverObjects1);
/* Reuse gdjs.rogue2Code.GDdoorObjects1 */
/* Reuse gdjs.rogue2Code.GDhit_9595boxObjects1 */
/* Reuse gdjs.rogue2Code.GDpillarObjects1 */
/* Reuse gdjs.rogue2Code.GDplayer1Objects1 */
/* Reuse gdjs.rogue2Code.GDrifleObjects1 */
/* Reuse gdjs.rogue2Code.GDsmasherObjects1 */
/* Reuse gdjs.rogue2Code.GDwaterObjects1 */
/* Reuse gdjs.rogue2Code.GDwater_9595particleesObjects1 */
/* Reuse gdjs.rogue2Code.GDwater_9595particlees2Objects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogue2Code.GDpillarObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDpillarObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogue2Code.GDcement_9595block_9595blueObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDcement_9595block_9595blueObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogue2Code.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDclonObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogue2Code.GDcement_9595block_9595blue2Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDcement_9595block_9595blue2Objects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogue2Code.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDsmasherObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogue2Code.GDdoorObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDdoorObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogue2Code.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDrifleObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogue2Code.GDhit_9595boxObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDhit_9595boxObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogue2Code.GDwaterObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDwaterObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogue2Code.GDwater_9595particleesObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDwater_9595particleesObjects1[i].setZOrder(7);
}
for(var i = 0, len = gdjs.rogue2Code.GDwater_9595particlees2Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDwater_9595particlees2Objects1[i].setZOrder(7);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDsmasherObjects1[i].setZOrder(9);
}
for(var i = 0, len = gdjs.rogue2Code.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDclonObjects1[i].setZOrder(9);
}
for(var i = 0, len = gdjs.rogue2Code.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDblast_9595botObjects1[i].setZOrder(9);
}
for(var i = 0, len = gdjs.rogue2Code.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDdiverObjects1[i].setZOrder(9);
}
for(var i = 0, len = gdjs.rogue2Code.GDbossObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDbossObjects1[i].setZOrder(9);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects1[i].setZOrder(200);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDrifleObjects1[i].setZOrder(201);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogue2Code.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("blocker"), gdjs.rogue2Code.GDblockerObjects1);
gdjs.copyArray(runtimeScene.getObjects("hit_box"), gdjs.rogue2Code.GDhit_9595boxObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("rifle"), gdjs.rogue2Code.GDrifleObjects1);
gdjs.copyArray(runtimeScene.getObjects("sensor"), gdjs.rogue2Code.GDsensorObjects1);
gdjs.copyArray(runtimeScene.getObjects("sensor2"), gdjs.rogue2Code.GDsensor2Objects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}{for(var i = 0, len = gdjs.rogue2Code.GDhit_9595boxObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDhit_9595boxObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDrifleObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDrifleObjects1[i].setZOrder(101);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDsensorObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDsensorObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.rogue2Code.GDblockerObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDblockerObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.rogue2Code.GDsensor2Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDsensor2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.rogue2Code.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDblast_9595botObjects1[i].resetTimer("blast");
}
}{gdjs.evtTools.storage.readNumberFromJSONFile("sc", "sc", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(1));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level").setNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber());
}
{ //Subevents
gdjs.rogue2Code.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("sensor"), gdjs.rogue2Code.GDsensorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDsensorObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDsensorObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDsensorObjects1[k] = gdjs.rogue2Code.GDsensorObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDsensorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDsensorObjects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDsensorObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDsensorObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hit_box"), gdjs.rogue2Code.GDhit_9595boxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDhit_9595boxObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDhit_9595boxObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDhit_9595boxObjects1[k] = gdjs.rogue2Code.GDhit_9595boxObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDhit_9595boxObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDhit_9595boxObjects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDhit_9595boxObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDhit_9595boxObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDplayer1Objects1[i].getVariableNumber(gdjs.rogue2Code.GDplayer1Objects1[i].getVariables().getFromIndex(0)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDplayer1Objects1[k] = gdjs.rogue2Code.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDplayer1Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("cement_block_blue"), gdjs.rogue2Code.GDcement_9595block_9595blueObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("water"), gdjs.rogue2Code.GDwaterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects1Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwaterObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects1Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDcement_95959595block_95959595blueObjects1Objects, true, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogue2Code.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.rogue2Code.GDbossObjects1);
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogue2Code.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogue2Code.GDdiverObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogue2Code.GDsmasherObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects1Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsmasherObjects1ObjectsGDgdjs_9546rogue2Code_9546GDclonObjects1ObjectsGDgdjs_9546rogue2Code_9546GDblast_95959595botObjects1ObjectsGDgdjs_9546rogue2Code_9546GDdiverObjects1ObjectsGDgdjs_9546rogue2Code_9546GDbossObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDsmasherObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDsmasherObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDsmasherObjects1[k] = gdjs.rogue2Code.GDsmasherObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDsmasherObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDclonObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDclonObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDclonObjects1[k] = gdjs.rogue2Code.GDclonObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDclonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDblast_9595botObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDblast_9595botObjects1[k] = gdjs.rogue2Code.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDblast_9595botObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDdiverObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDdiverObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDdiverObjects1[k] = gdjs.rogue2Code.GDdiverObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDdiverObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDbossObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDbossObjects1[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDbossObjects1[k] = gdjs.rogue2Code.GDbossObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDbossObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16408060);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects1[i].returnVariable(gdjs.rogue2Code.GDplayer1Objects1[i].getVariables().getFromIndex(0)).sub(16);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blocker"), gdjs.rogue2Code.GDblockerObjects1);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("sensor2"), gdjs.rogue2Code.GDsensor2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects1Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDblockerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsensor2Objects1Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDblockerObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDblockerObjects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDblockerObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDblockerObjects1[i].setVariableBoolean(gdjs.rogue2Code.GDblockerObjects1[i].getVariables().getFromIndex(0), true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogue2Code.mapOfEmptyGDplayer1Objects) < 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.rogue2Code.GDstateObjects1);
gdjs.copyArray(runtimeScene.getObjects("win_fail"), gdjs.rogue2Code.GDwin_9595failObjects1);
{gdjs.evtTools.camera.showLayer(runtimeScene, "fail");
}{for(var i = 0, len = gdjs.rogue2Code.GDwin_9595failObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDwin_9595failObjects1[i].getBehavior("Text").setText("you fail");
}
}{for(var i = 0, len = gdjs.rogue2Code.GDstateObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDstateObjects1[i].getBehavior("Text").setText("restart");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogue2Code.mapOfEmptyGDsmasherObjectsEmptyGDclonObjectsEmptyGDblast_9595botObjectsEmptyGDdiverObjectsEmptyGDbossObjects) < 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level")) <= 9;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.rogue2Code.GDstateObjects1);
gdjs.copyArray(runtimeScene.getObjects("win_fail"), gdjs.rogue2Code.GDwin_9595failObjects1);
{gdjs.evtTools.camera.showLayer(runtimeScene, "fail");
}{for(var i = 0, len = gdjs.rogue2Code.GDwin_9595failObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDwin_9595failObjects1[i].getBehavior("Text").setText("you win");
}
}{for(var i = 0, len = gdjs.rogue2Code.GDstateObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDstateObjects1[i].getBehavior("Text").setText("next");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getChild("level")) > 9;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogue2Code.mapOfEmptyGDsmasherObjectsEmptyGDclonObjectsEmptyGDblast_9595botObjectsEmptyGDdiverObjectsEmptyGDbossObjects) < 1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("state"), gdjs.rogue2Code.GDstateObjects1);
gdjs.copyArray(runtimeScene.getObjects("win_fail"), gdjs.rogue2Code.GDwin_9595failObjects1);
{gdjs.evtTools.camera.showLayer(runtimeScene, "fail");
}{for(var i = 0, len = gdjs.rogue2Code.GDwin_9595failObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDwin_9595failObjects1[i].getBehavior("Text").setText("you win");
}
}{for(var i = 0, len = gdjs.rogue2Code.GDstateObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDstateObjects1[i].getBehavior("Text").setText("level complete");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16415236);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogue2Code.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogue2Code.GDdiverObjects1);
{for(var i = 0, len = gdjs.rogue2Code.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDblast_9595botObjects1[i].resetTimer("blast");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "dive");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "spawn");
}{for(var i = 0, len = gdjs.rogue2Code.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDdiverObjects1[i].setZOrder(300);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "dive") >= 4;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogue2Code.GDdiverObjects1);
{for(var i = 0, len = gdjs.rogue2Code.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDdiverObjects1[i].getBehavior("Animation").setAnimationName("ready");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "dive") >= 6;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogue2Code.GDdiverObjects1);
{for(var i = 0, len = gdjs.rogue2Code.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDdiverObjects1[i].getBehavior("Animation").setAnimationName("targeting");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "dive");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogue2Code.mapOfEmptyGDbossObjects) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "spawn") >= 8;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16419100);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.rogue2Code.GDbossObjects1);
gdjs.rogue2Code.GDclonObjects1.length = 0;

gdjs.rogue2Code.GDdiverObjects1.length = 0;

gdjs.rogue2Code.GDsmasherObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDclonObjects1Objects, (( gdjs.rogue2Code.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDbossObjects1[0].getPointX("")) + gdjs.randomInRange(100, 400), (( gdjs.rogue2Code.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDbossObjects1[0].getPointY("")) + gdjs.randomInRange((( gdjs.rogue2Code.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDbossObjects1[0].getPointY("")), 300), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDclonObjects1Objects, (( gdjs.rogue2Code.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDbossObjects1[0].getPointX("")) + gdjs.randomInRange(100, 400), (( gdjs.rogue2Code.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDbossObjects1[0].getPointY("")) + gdjs.randomInRange((( gdjs.rogue2Code.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDbossObjects1[0].getPointY("")), 300), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDclonObjects1Objects, (( gdjs.rogue2Code.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDbossObjects1[0].getPointX("")) + gdjs.randomInRange(100, 400), (( gdjs.rogue2Code.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDbossObjects1[0].getPointY("")) + gdjs.randomInRange((( gdjs.rogue2Code.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDbossObjects1[0].getPointY("")), 300), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDsmasherObjects1Objects, (( gdjs.rogue2Code.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDbossObjects1[0].getPointX("")) + gdjs.randomInRange(100, 400), (( gdjs.rogue2Code.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDbossObjects1[0].getPointY("")) + gdjs.randomInRange((( gdjs.rogue2Code.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDbossObjects1[0].getPointY("")), 300), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDdiverObjects1Objects, (( gdjs.rogue2Code.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDbossObjects1[0].getPointX("")) + gdjs.randomInRange(100, 400), (( gdjs.rogue2Code.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDbossObjects1[0].getPointY("")) + gdjs.randomInRange((( gdjs.rogue2Code.GDbossObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDbossObjects1[0].getPointY("")), 300), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "spawn");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogue2Code.GDdiverObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDdiverObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDdiverObjects1[i].getBehavior("Animation").getAnimationName() == "ready" ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDdiverObjects1[k] = gdjs.rogue2Code.GDdiverObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDdiverObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16410932);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDdiverObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);
{for(var i = 0, len = gdjs.rogue2Code.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDdiverObjects1[i].rotateTowardPosition((( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getCenterXInScene()), (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getCenterYInScene()), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDdiverObjects1[i].addPolarForce((gdjs.rogue2Code.GDdiverObjects1[i].getAngle()), 450, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogue2Code.GDdiverObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDdiverObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDdiverObjects1[i].getBehavior("Animation").getAnimationName() == "targeting" ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDdiverObjects1[k] = gdjs.rogue2Code.GDdiverObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDdiverObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDdiverObjects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDdiverObjects1[i].clearForces();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogue2Code.GDblast_9595botObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDblast_9595botObjects1[i].getTimerElapsedTimeInSecondsOrNaN("blast") >= 3 ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDblast_9595botObjects1[k] = gdjs.rogue2Code.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDblast_9595botObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDblast_9595botObjects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDblast_9595botObjects1[i].getBehavior("Animation").setAnimationName("bot_jump");
}
}}

}


{

gdjs.rogue2Code.GDplayer1Objects1.length = 0;

gdjs.rogue2Code.GDwater_9595particleesObjects1.length = 0;

gdjs.rogue2Code.GDwater_9595particlees2Objects1.length = 0;

gdjs.rogue2Code.GDwaveObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.rogue2Code.GDplayer1Objects1_1final.length = 0;
gdjs.rogue2Code.GDwater_9595particleesObjects1_1final.length = 0;
gdjs.rogue2Code.GDwater_9595particlees2Objects1_1final.length = 0;
gdjs.rogue2Code.GDwaveObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("water_particlees2"), gdjs.rogue2Code.GDwater_9595particlees2Objects2);
gdjs.copyArray(runtimeScene.getObjects("wave"), gdjs.rogue2Code.GDwaveObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwaveObjects2Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwater_95959595particlees2Objects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogue2Code.GDwater_9595particlees2Objects2.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDwater_9595particlees2Objects1_1final.indexOf(gdjs.rogue2Code.GDwater_9595particlees2Objects2[j]) === -1 )
            gdjs.rogue2Code.GDwater_9595particlees2Objects1_1final.push(gdjs.rogue2Code.GDwater_9595particlees2Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.rogue2Code.GDwaveObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDwaveObjects1_1final.indexOf(gdjs.rogue2Code.GDwaveObjects2[j]) === -1 )
            gdjs.rogue2Code.GDwaveObjects1_1final.push(gdjs.rogue2Code.GDwaveObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("water_particlees"), gdjs.rogue2Code.GDwater_9595particleesObjects2);
gdjs.copyArray(runtimeScene.getObjects("wave"), gdjs.rogue2Code.GDwaveObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwaveObjects2Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwater_95959595particleesObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogue2Code.GDwater_9595particleesObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDwater_9595particleesObjects1_1final.indexOf(gdjs.rogue2Code.GDwater_9595particleesObjects2[j]) === -1 )
            gdjs.rogue2Code.GDwater_9595particleesObjects1_1final.push(gdjs.rogue2Code.GDwater_9595particleesObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.rogue2Code.GDwaveObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDwaveObjects1_1final.indexOf(gdjs.rogue2Code.GDwaveObjects2[j]) === -1 )
            gdjs.rogue2Code.GDwaveObjects1_1final.push(gdjs.rogue2Code.GDwaveObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects2);
gdjs.copyArray(runtimeScene.getObjects("wave"), gdjs.rogue2Code.GDwaveObjects2);
isConditionTrue_1 = gdjs.evtTools.object.distanceTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwaveObjects2Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects2Objects, 4000, true);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogue2Code.GDplayer1Objects2.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDplayer1Objects1_1final.indexOf(gdjs.rogue2Code.GDplayer1Objects2[j]) === -1 )
            gdjs.rogue2Code.GDplayer1Objects1_1final.push(gdjs.rogue2Code.GDplayer1Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.rogue2Code.GDwaveObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDwaveObjects1_1final.indexOf(gdjs.rogue2Code.GDwaveObjects2[j]) === -1 )
            gdjs.rogue2Code.GDwaveObjects1_1final.push(gdjs.rogue2Code.GDwaveObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.rogue2Code.GDplayer1Objects1_1final, gdjs.rogue2Code.GDplayer1Objects1);
gdjs.copyArray(gdjs.rogue2Code.GDwater_9595particleesObjects1_1final, gdjs.rogue2Code.GDwater_9595particleesObjects1);
gdjs.copyArray(gdjs.rogue2Code.GDwater_9595particlees2Objects1_1final, gdjs.rogue2Code.GDwater_9595particlees2Objects1);
gdjs.copyArray(gdjs.rogue2Code.GDwaveObjects1_1final, gdjs.rogue2Code.GDwaveObjects1);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDwaveObjects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDwaveObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDwaveObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogue2Code.GDblast_9595botObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDblast_9595botObjects1[i].getBehavior("Animation").getAnimationName() == "bot_jump" ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDblast_9595botObjects1[k] = gdjs.rogue2Code.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDblast_9595botObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDblast_9595botObjects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDblast_9595botObjects1[k] = gdjs.rogue2Code.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDblast_9595botObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDblast_9595botObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);
gdjs.rogue2Code.GDwaveObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwaveObjects1Objects, (( gdjs.rogue2Code.GDblast_9595botObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDblast_9595botObjects1[0].getCenterXInScene()), (( gdjs.rogue2Code.GDblast_9595botObjects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDblast_9595botObjects1[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.rogue2Code.GDwaveObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDwaveObjects1[i].rotateTowardPosition((( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getCenterXInScene()), (( gdjs.rogue2Code.GDplayer1Objects1.length === 0 ) ? 0 :gdjs.rogue2Code.GDplayer1Objects1[0].getCenterYInScene()), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDblast_9595botObjects1[i].getBehavior("Animation").setAnimationName("bot_idle");
}
}{for(var i = 0, len = gdjs.rogue2Code.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDblast_9595botObjects1[i].resetTimer("blast");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogue2Code.GDblast_9595botObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.rogue2Code.GDbulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbulletObjects1Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDblast_95959595botObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDblast_9595botObjects1 */
/* Reuse gdjs.rogue2Code.GDbulletObjects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDblast_9595botObjects1[i].returnVariable(gdjs.rogue2Code.GDblast_9595botObjects1[i].getVariables().getFromIndex(0)).sub(25);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDbulletObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 40, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.rogue2Code.GDbulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogue2Code.GDdiverObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbulletObjects1Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDdiverObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDbulletObjects1 */
/* Reuse gdjs.rogue2Code.GDdiverObjects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDdiverObjects1[i].returnVariable(gdjs.rogue2Code.GDdiverObjects1[i].getVariables().getFromIndex(0)).sub(25);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDbulletObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 40, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.rogue2Code.GDbossObjects1);
gdjs.copyArray(runtimeScene.getObjects("bullet"), gdjs.rogue2Code.GDbulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbulletObjects1Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDbossObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDbossObjects1 */
/* Reuse gdjs.rogue2Code.GDbulletObjects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDbossObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDbossObjects1[i].returnVariable(gdjs.rogue2Code.GDbossObjects1[i].getVariables().getFromIndex(0)).sub(10);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDbulletObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDbulletObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 40, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogue2Code.GDblast_9595botObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDblast_9595botObjects1[i].getVariableNumber(gdjs.rogue2Code.GDblast_9595botObjects1[i].getVariables().getFromIndex(0)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDblast_9595botObjects1[k] = gdjs.rogue2Code.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDblast_9595botObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDblast_9595botObjects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDblast_9595botObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogue2Code.GDdiverObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDdiverObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDdiverObjects1[i].getVariableNumber(gdjs.rogue2Code.GDdiverObjects1[i].getVariables().getFromIndex(0)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDdiverObjects1[k] = gdjs.rogue2Code.GDdiverObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDdiverObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDdiverObjects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDdiverObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("boss"), gdjs.rogue2Code.GDbossObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDbossObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDbossObjects1[i].getVariableNumber(gdjs.rogue2Code.GDbossObjects1[i].getVariables().getFromIndex(0)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDbossObjects1[k] = gdjs.rogue2Code.GDbossObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDbossObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogue2Code.GDblast_9595botObjects1);
/* Reuse gdjs.rogue2Code.GDbossObjects1 */
gdjs.copyArray(runtimeScene.getObjects("clon"), gdjs.rogue2Code.GDclonObjects1);
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogue2Code.GDdiverObjects1);
gdjs.copyArray(runtimeScene.getObjects("smasher"), gdjs.rogue2Code.GDsmasherObjects1);
{for(var i = 0, len = gdjs.rogue2Code.GDbossObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDbossObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.rogue2Code.GDsmasherObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDsmasherObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDclonObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDclonObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDblast_9595botObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDblast_9595botObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDdiverObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDdiverObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.rogue2Code.GDbossObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDbossObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.rogue2Code.eventsList1(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDplayer1Objects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDplayer1Objects1[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDplayer1Objects1[k] = gdjs.rogue2Code.GDplayer1Objects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDplayer1Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15922012);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "walk", 3, true, 40, 0.3);
}}

}


{

gdjs.rogue2Code.GDplayer1Objects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.rogue2Code.GDplayer1Objects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects2);
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDplayer1Objects2.length;i<l;++i) {
    if ( !(gdjs.rogue2Code.GDplayer1Objects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_1 = true;
        gdjs.rogue2Code.GDplayer1Objects2[k] = gdjs.rogue2Code.GDplayer1Objects2[i];
        ++k;
    }
}
gdjs.rogue2Code.GDplayer1Objects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogue2Code.GDplayer1Objects2.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDplayer1Objects1_1final.indexOf(gdjs.rogue2Code.GDplayer1Objects2[j]) === -1 )
            gdjs.rogue2Code.GDplayer1Objects1_1final.push(gdjs.rogue2Code.GDplayer1Objects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.rogue2Code.mapOfEmptyGDplayer1Objects) < 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.rogue2Code.GDplayer1Objects1_1final, gdjs.rogue2Code.GDplayer1Objects1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 3);
}}

}


{

gdjs.rogue2Code.GDdiverObjects1.length = 0;

gdjs.rogue2Code.GDplayer1Objects1.length = 0;

gdjs.rogue2Code.GDwaveObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.rogue2Code.GDdiverObjects1_1final.length = 0;
gdjs.rogue2Code.GDplayer1Objects1_1final.length = 0;
gdjs.rogue2Code.GDwaveObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects2);
gdjs.copyArray(runtimeScene.getObjects("wave"), gdjs.rogue2Code.GDwaveObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDwaveObjects2Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogue2Code.GDplayer1Objects2.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDplayer1Objects1_1final.indexOf(gdjs.rogue2Code.GDplayer1Objects2[j]) === -1 )
            gdjs.rogue2Code.GDplayer1Objects1_1final.push(gdjs.rogue2Code.GDplayer1Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.rogue2Code.GDwaveObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDwaveObjects1_1final.indexOf(gdjs.rogue2Code.GDwaveObjects2[j]) === -1 )
            gdjs.rogue2Code.GDwaveObjects1_1final.push(gdjs.rogue2Code.GDwaveObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("diver"), gdjs.rogue2Code.GDdiverObjects2);
gdjs.copyArray(runtimeScene.getObjects("player1"), gdjs.rogue2Code.GDplayer1Objects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDdiverObjects2Objects, gdjs.rogue2Code.mapOfGDgdjs_9546rogue2Code_9546GDplayer1Objects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.rogue2Code.GDdiverObjects2.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDdiverObjects1_1final.indexOf(gdjs.rogue2Code.GDdiverObjects2[j]) === -1 )
            gdjs.rogue2Code.GDdiverObjects1_1final.push(gdjs.rogue2Code.GDdiverObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.rogue2Code.GDplayer1Objects2.length; j < jLen ; ++j) {
        if ( gdjs.rogue2Code.GDplayer1Objects1_1final.indexOf(gdjs.rogue2Code.GDplayer1Objects2[j]) === -1 )
            gdjs.rogue2Code.GDplayer1Objects1_1final.push(gdjs.rogue2Code.GDplayer1Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.rogue2Code.GDdiverObjects1_1final, gdjs.rogue2Code.GDdiverObjects1);
gdjs.copyArray(gdjs.rogue2Code.GDplayer1Objects1_1final, gdjs.rogue2Code.GDplayer1Objects1);
gdjs.copyArray(gdjs.rogue2Code.GDwaveObjects1_1final, gdjs.rogue2Code.GDwaveObjects1);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.rogue2Code.GDplayer1Objects1 */
{for(var i = 0, len = gdjs.rogue2Code.GDplayer1Objects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDplayer1Objects1[i].returnVariable(gdjs.rogue2Code.GDplayer1Objects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("blast_bot"), gdjs.rogue2Code.GDblast_9595botObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.rogue2Code.GDblast_9595botObjects1.length;i<l;++i) {
    if ( gdjs.rogue2Code.GDblast_9595botObjects1[i].getBehavior("Animation").getAnimationName() == "bot_idle" ) {
        isConditionTrue_0 = true;
        gdjs.rogue2Code.GDblast_9595botObjects1[k] = gdjs.rogue2Code.GDblast_9595botObjects1[i];
        ++k;
    }
}
gdjs.rogue2Code.GDblast_9595botObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("wave"), gdjs.rogue2Code.GDwaveObjects1);
{for(var i = 0, len = gdjs.rogue2Code.GDwaveObjects1.length ;i < len;++i) {
    gdjs.rogue2Code.GDwaveObjects1[i].addPolarForce((gdjs.rogue2Code.GDwaveObjects1[i].getAngle()), 300, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "fail");
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 3);
}
{ //Subevents
gdjs.rogue2Code.eventsList2(runtimeScene);} //End of subevents
}

}


};

gdjs.rogue2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.rogue2Code.GDplayer1Objects1.length = 0;
gdjs.rogue2Code.GDplayer1Objects2.length = 0;
gdjs.rogue2Code.GDplayer1Objects3.length = 0;
gdjs.rogue2Code.GDpillarObjects1.length = 0;
gdjs.rogue2Code.GDpillarObjects2.length = 0;
gdjs.rogue2Code.GDpillarObjects3.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blueObjects1.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blueObjects2.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blueObjects3.length = 0;
gdjs.rogue2Code.GDclonObjects1.length = 0;
gdjs.rogue2Code.GDclonObjects2.length = 0;
gdjs.rogue2Code.GDclonObjects3.length = 0;
gdjs.rogue2Code.GDsmasherObjects1.length = 0;
gdjs.rogue2Code.GDsmasherObjects2.length = 0;
gdjs.rogue2Code.GDsmasherObjects3.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue2Objects1.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue2Objects2.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue2Objects3.length = 0;
gdjs.rogue2Code.GDdoorObjects1.length = 0;
gdjs.rogue2Code.GDdoorObjects2.length = 0;
gdjs.rogue2Code.GDdoorObjects3.length = 0;
gdjs.rogue2Code.GDrifleObjects1.length = 0;
gdjs.rogue2Code.GDrifleObjects2.length = 0;
gdjs.rogue2Code.GDrifleObjects3.length = 0;
gdjs.rogue2Code.GDhit_9595boxObjects1.length = 0;
gdjs.rogue2Code.GDhit_9595boxObjects2.length = 0;
gdjs.rogue2Code.GDhit_9595boxObjects3.length = 0;
gdjs.rogue2Code.GDbulletObjects1.length = 0;
gdjs.rogue2Code.GDbulletObjects2.length = 0;
gdjs.rogue2Code.GDbulletObjects3.length = 0;
gdjs.rogue2Code.GDreloadObjects1.length = 0;
gdjs.rogue2Code.GDreloadObjects2.length = 0;
gdjs.rogue2Code.GDreloadObjects3.length = 0;
gdjs.rogue2Code.GDreload2Objects1.length = 0;
gdjs.rogue2Code.GDreload2Objects2.length = 0;
gdjs.rogue2Code.GDreload2Objects3.length = 0;
gdjs.rogue2Code.GDwaterObjects1.length = 0;
gdjs.rogue2Code.GDwaterObjects2.length = 0;
gdjs.rogue2Code.GDwaterObjects3.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects2.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects3.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects1.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects2.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects3.length = 0;
gdjs.rogue2Code.GDwater_9595particleesObjects1.length = 0;
gdjs.rogue2Code.GDwater_9595particleesObjects2.length = 0;
gdjs.rogue2Code.GDwater_9595particleesObjects3.length = 0;
gdjs.rogue2Code.GDwater_9595particlees2Objects1.length = 0;
gdjs.rogue2Code.GDwater_9595particlees2Objects2.length = 0;
gdjs.rogue2Code.GDwater_9595particlees2Objects3.length = 0;
gdjs.rogue2Code.GDlifeObjects1.length = 0;
gdjs.rogue2Code.GDlifeObjects2.length = 0;
gdjs.rogue2Code.GDlifeObjects3.length = 0;
gdjs.rogue2Code.GDbackgroundObjects1.length = 0;
gdjs.rogue2Code.GDbackgroundObjects2.length = 0;
gdjs.rogue2Code.GDbackgroundObjects3.length = 0;
gdjs.rogue2Code.GDwin_9595failObjects1.length = 0;
gdjs.rogue2Code.GDwin_9595failObjects2.length = 0;
gdjs.rogue2Code.GDwin_9595failObjects3.length = 0;
gdjs.rogue2Code.GDstateObjects1.length = 0;
gdjs.rogue2Code.GDstateObjects2.length = 0;
gdjs.rogue2Code.GDstateObjects3.length = 0;
gdjs.rogue2Code.GDlineObjects1.length = 0;
gdjs.rogue2Code.GDlineObjects2.length = 0;
gdjs.rogue2Code.GDlineObjects3.length = 0;
gdjs.rogue2Code.GDsensorObjects1.length = 0;
gdjs.rogue2Code.GDsensorObjects2.length = 0;
gdjs.rogue2Code.GDsensorObjects3.length = 0;
gdjs.rogue2Code.GDblockerObjects1.length = 0;
gdjs.rogue2Code.GDblockerObjects2.length = 0;
gdjs.rogue2Code.GDblockerObjects3.length = 0;
gdjs.rogue2Code.GDsensor2Objects1.length = 0;
gdjs.rogue2Code.GDsensor2Objects2.length = 0;
gdjs.rogue2Code.GDsensor2Objects3.length = 0;
gdjs.rogue2Code.GDsmasher_9595aObjects1.length = 0;
gdjs.rogue2Code.GDsmasher_9595aObjects2.length = 0;
gdjs.rogue2Code.GDsmasher_9595aObjects3.length = 0;
gdjs.rogue2Code.GDblast_9595botObjects1.length = 0;
gdjs.rogue2Code.GDblast_9595botObjects2.length = 0;
gdjs.rogue2Code.GDblast_9595botObjects3.length = 0;
gdjs.rogue2Code.GDwaveObjects1.length = 0;
gdjs.rogue2Code.GDwaveObjects2.length = 0;
gdjs.rogue2Code.GDwaveObjects3.length = 0;
gdjs.rogue2Code.GDdiverObjects1.length = 0;
gdjs.rogue2Code.GDdiverObjects2.length = 0;
gdjs.rogue2Code.GDdiverObjects3.length = 0;
gdjs.rogue2Code.GDlevelObjects1.length = 0;
gdjs.rogue2Code.GDlevelObjects2.length = 0;
gdjs.rogue2Code.GDlevelObjects3.length = 0;
gdjs.rogue2Code.GDbossObjects1.length = 0;
gdjs.rogue2Code.GDbossObjects2.length = 0;
gdjs.rogue2Code.GDbossObjects3.length = 0;
gdjs.rogue2Code.GDbackObjects1.length = 0;
gdjs.rogue2Code.GDbackObjects2.length = 0;
gdjs.rogue2Code.GDbackObjects3.length = 0;
gdjs.rogue2Code.GDShadedDarkJoystickObjects1.length = 0;
gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length = 0;
gdjs.rogue2Code.GDShadedDarkJoystickObjects3.length = 0;
gdjs.rogue2Code.GDshootObjects1.length = 0;
gdjs.rogue2Code.GDshootObjects2.length = 0;
gdjs.rogue2Code.GDshootObjects3.length = 0;

gdjs.rogue2Code.eventsList3(runtimeScene);
gdjs.rogue2Code.GDplayer1Objects1.length = 0;
gdjs.rogue2Code.GDplayer1Objects2.length = 0;
gdjs.rogue2Code.GDplayer1Objects3.length = 0;
gdjs.rogue2Code.GDpillarObjects1.length = 0;
gdjs.rogue2Code.GDpillarObjects2.length = 0;
gdjs.rogue2Code.GDpillarObjects3.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blueObjects1.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blueObjects2.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blueObjects3.length = 0;
gdjs.rogue2Code.GDclonObjects1.length = 0;
gdjs.rogue2Code.GDclonObjects2.length = 0;
gdjs.rogue2Code.GDclonObjects3.length = 0;
gdjs.rogue2Code.GDsmasherObjects1.length = 0;
gdjs.rogue2Code.GDsmasherObjects2.length = 0;
gdjs.rogue2Code.GDsmasherObjects3.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue2Objects1.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue2Objects2.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue2Objects3.length = 0;
gdjs.rogue2Code.GDdoorObjects1.length = 0;
gdjs.rogue2Code.GDdoorObjects2.length = 0;
gdjs.rogue2Code.GDdoorObjects3.length = 0;
gdjs.rogue2Code.GDrifleObjects1.length = 0;
gdjs.rogue2Code.GDrifleObjects2.length = 0;
gdjs.rogue2Code.GDrifleObjects3.length = 0;
gdjs.rogue2Code.GDhit_9595boxObjects1.length = 0;
gdjs.rogue2Code.GDhit_9595boxObjects2.length = 0;
gdjs.rogue2Code.GDhit_9595boxObjects3.length = 0;
gdjs.rogue2Code.GDbulletObjects1.length = 0;
gdjs.rogue2Code.GDbulletObjects2.length = 0;
gdjs.rogue2Code.GDbulletObjects3.length = 0;
gdjs.rogue2Code.GDreloadObjects1.length = 0;
gdjs.rogue2Code.GDreloadObjects2.length = 0;
gdjs.rogue2Code.GDreloadObjects3.length = 0;
gdjs.rogue2Code.GDreload2Objects1.length = 0;
gdjs.rogue2Code.GDreload2Objects2.length = 0;
gdjs.rogue2Code.GDreload2Objects3.length = 0;
gdjs.rogue2Code.GDwaterObjects1.length = 0;
gdjs.rogue2Code.GDwaterObjects2.length = 0;
gdjs.rogue2Code.GDwaterObjects3.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects1.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects2.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue_9595sideObjects3.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects1.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects2.length = 0;
gdjs.rogue2Code.GDcement_9595block_9595blue_9595side2Objects3.length = 0;
gdjs.rogue2Code.GDwater_9595particleesObjects1.length = 0;
gdjs.rogue2Code.GDwater_9595particleesObjects2.length = 0;
gdjs.rogue2Code.GDwater_9595particleesObjects3.length = 0;
gdjs.rogue2Code.GDwater_9595particlees2Objects1.length = 0;
gdjs.rogue2Code.GDwater_9595particlees2Objects2.length = 0;
gdjs.rogue2Code.GDwater_9595particlees2Objects3.length = 0;
gdjs.rogue2Code.GDlifeObjects1.length = 0;
gdjs.rogue2Code.GDlifeObjects2.length = 0;
gdjs.rogue2Code.GDlifeObjects3.length = 0;
gdjs.rogue2Code.GDbackgroundObjects1.length = 0;
gdjs.rogue2Code.GDbackgroundObjects2.length = 0;
gdjs.rogue2Code.GDbackgroundObjects3.length = 0;
gdjs.rogue2Code.GDwin_9595failObjects1.length = 0;
gdjs.rogue2Code.GDwin_9595failObjects2.length = 0;
gdjs.rogue2Code.GDwin_9595failObjects3.length = 0;
gdjs.rogue2Code.GDstateObjects1.length = 0;
gdjs.rogue2Code.GDstateObjects2.length = 0;
gdjs.rogue2Code.GDstateObjects3.length = 0;
gdjs.rogue2Code.GDlineObjects1.length = 0;
gdjs.rogue2Code.GDlineObjects2.length = 0;
gdjs.rogue2Code.GDlineObjects3.length = 0;
gdjs.rogue2Code.GDsensorObjects1.length = 0;
gdjs.rogue2Code.GDsensorObjects2.length = 0;
gdjs.rogue2Code.GDsensorObjects3.length = 0;
gdjs.rogue2Code.GDblockerObjects1.length = 0;
gdjs.rogue2Code.GDblockerObjects2.length = 0;
gdjs.rogue2Code.GDblockerObjects3.length = 0;
gdjs.rogue2Code.GDsensor2Objects1.length = 0;
gdjs.rogue2Code.GDsensor2Objects2.length = 0;
gdjs.rogue2Code.GDsensor2Objects3.length = 0;
gdjs.rogue2Code.GDsmasher_9595aObjects1.length = 0;
gdjs.rogue2Code.GDsmasher_9595aObjects2.length = 0;
gdjs.rogue2Code.GDsmasher_9595aObjects3.length = 0;
gdjs.rogue2Code.GDblast_9595botObjects1.length = 0;
gdjs.rogue2Code.GDblast_9595botObjects2.length = 0;
gdjs.rogue2Code.GDblast_9595botObjects3.length = 0;
gdjs.rogue2Code.GDwaveObjects1.length = 0;
gdjs.rogue2Code.GDwaveObjects2.length = 0;
gdjs.rogue2Code.GDwaveObjects3.length = 0;
gdjs.rogue2Code.GDdiverObjects1.length = 0;
gdjs.rogue2Code.GDdiverObjects2.length = 0;
gdjs.rogue2Code.GDdiverObjects3.length = 0;
gdjs.rogue2Code.GDlevelObjects1.length = 0;
gdjs.rogue2Code.GDlevelObjects2.length = 0;
gdjs.rogue2Code.GDlevelObjects3.length = 0;
gdjs.rogue2Code.GDbossObjects1.length = 0;
gdjs.rogue2Code.GDbossObjects2.length = 0;
gdjs.rogue2Code.GDbossObjects3.length = 0;
gdjs.rogue2Code.GDbackObjects1.length = 0;
gdjs.rogue2Code.GDbackObjects2.length = 0;
gdjs.rogue2Code.GDbackObjects3.length = 0;
gdjs.rogue2Code.GDShadedDarkJoystickObjects1.length = 0;
gdjs.rogue2Code.GDShadedDarkJoystickObjects2.length = 0;
gdjs.rogue2Code.GDShadedDarkJoystickObjects3.length = 0;
gdjs.rogue2Code.GDshootObjects1.length = 0;
gdjs.rogue2Code.GDshootObjects2.length = 0;
gdjs.rogue2Code.GDshootObjects3.length = 0;


return;

}

gdjs['rogue2Code'] = gdjs.rogue2Code;
