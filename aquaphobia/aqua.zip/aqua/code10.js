gdjs.activCode = {};
gdjs.activCode.localVariables = [];
gdjs.activCode.GDinfoObjects1= [];
gdjs.activCode.GDinfoObjects2= [];
gdjs.activCode.GDcodeObjects1= [];
gdjs.activCode.GDcodeObjects2= [];
gdjs.activCode.GDrifle2Objects1= [];
gdjs.activCode.GDrifle2Objects2= [];
gdjs.activCode.GDinfo2Objects1= [];
gdjs.activCode.GDinfo2Objects2= [];
gdjs.activCode.GDmonryObjects1= [];
gdjs.activCode.GDmonryObjects2= [];
gdjs.activCode.GDbdObjects1= [];
gdjs.activCode.GDbdObjects2= [];


gdjs.activCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("code"), gdjs.activCode.GDcodeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.activCode.GDcodeObjects1.length;i<l;++i) {
    if ( gdjs.activCode.GDcodeObjects1[i].getBehavior("Text").getText() == "105p69999" ) {
        isConditionTrue_0 = true;
        gdjs.activCode.GDcodeObjects1[k] = gdjs.activCode.GDcodeObjects1[i];
        ++k;
    }
}
gdjs.activCode.GDcodeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.storage.elementExistsInJSONFile("activ", "activ"));
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeStringInJSONFile("activ", "activ", "true");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("activ", "activ");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("code"), gdjs.activCode.GDcodeObjects1);
gdjs.copyArray(runtimeScene.getObjects("info"), gdjs.activCode.GDinfoObjects1);
{for(var i = 0, len = gdjs.activCode.GDcodeObjects1.length ;i < len;++i) {
    gdjs.activCode.GDcodeObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.activCode.GDinfoObjects1.length ;i < len;++i) {
    gdjs.activCode.GDinfoObjects1[i].getBehavior("Text").setText("thanks for subscribing ");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "F1");
if (isConditionTrue_0) {
{gdjs.evtTools.storage.deleteElementFromJSONFile("activ", "activ");
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "activ", true);
}}

}


};

gdjs.activCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.activCode.GDinfoObjects1.length = 0;
gdjs.activCode.GDinfoObjects2.length = 0;
gdjs.activCode.GDcodeObjects1.length = 0;
gdjs.activCode.GDcodeObjects2.length = 0;
gdjs.activCode.GDrifle2Objects1.length = 0;
gdjs.activCode.GDrifle2Objects2.length = 0;
gdjs.activCode.GDinfo2Objects1.length = 0;
gdjs.activCode.GDinfo2Objects2.length = 0;
gdjs.activCode.GDmonryObjects1.length = 0;
gdjs.activCode.GDmonryObjects2.length = 0;
gdjs.activCode.GDbdObjects1.length = 0;
gdjs.activCode.GDbdObjects2.length = 0;

gdjs.activCode.eventsList0(runtimeScene);
gdjs.activCode.GDinfoObjects1.length = 0;
gdjs.activCode.GDinfoObjects2.length = 0;
gdjs.activCode.GDcodeObjects1.length = 0;
gdjs.activCode.GDcodeObjects2.length = 0;
gdjs.activCode.GDrifle2Objects1.length = 0;
gdjs.activCode.GDrifle2Objects2.length = 0;
gdjs.activCode.GDinfo2Objects1.length = 0;
gdjs.activCode.GDinfo2Objects2.length = 0;
gdjs.activCode.GDmonryObjects1.length = 0;
gdjs.activCode.GDmonryObjects2.length = 0;
gdjs.activCode.GDbdObjects1.length = 0;
gdjs.activCode.GDbdObjects2.length = 0;


return;

}

gdjs['activCode'] = gdjs.activCode;
